<?php

declare(strict_types=1);

// Sham portal front controller. The application lives outside the web root: either next to this folder (app/) or in
// ~/sham-portal/app when this folder is public_html. The setup wizard writes the place into .sham-app next to this
// file (never served: .htaccess refuses dot files); SHAM_APP_DIR in .htaccess (SetEnv) also works.
$pin = is_file(__DIR__.'/.sham-app') ? trim((string) file_get_contents(__DIR__.'/.sham-app')) : '';
$candidates = array_filter([getenv('SHAM_APP_DIR') ?: null, $pin !== '' ? $pin : null, dirname(__DIR__).'/app', dirname(__DIR__).'/sham-portal/app']);
foreach ($candidates as $dir) {
    if (is_file($dir.'/bootstrap.php')) {
        define('SHAM_PUBLIC', __DIR__);
        require $dir.'/bootstrap.php';
        $res = Sham\App::handle(Sham\Http\Request::fromGlobals());
        $res->send(Sham\View::$nonce);
        Sham\App::afterResponse();
        exit;
    }
}
http_response_code(500);
header('Content-Type: text/plain; charset=utf-8');
echo "The Sham portal application folder was not found. Upload the app folder next to this one (see INSTALL.md).\n";
