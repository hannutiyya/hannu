(function () {
  'use strict';
  document.querySelectorAll('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var t = document.getElementById(b.getAttribute('data-copy'));
      if (!t) return;
      t.select();
      (navigator.clipboard ? navigator.clipboard.writeText(t.value) : Promise.reject()).catch(function () { document.execCommand('copy'); });
      var old = b.textContent; b.textContent = 'Copied'; setTimeout(function () { b.textContent = old; }, 1600);
    });
  });
  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (ev) { if (!window.confirm(f.getAttribute('data-confirm'))) ev.preventDefault(); });
  });
  document.querySelectorAll('[data-print]').forEach(function (b) { b.addEventListener('click', function () { window.print(); }); });
  var qr = document.querySelector('[data-qr]');
  if (qr) {
    var s = document.createElement('script');
    s.src = '/assets/qr.js';
    s.onload = function () { try { qr.innerHTML = window.ShamQR.svg(qr.getAttribute('data-qr'), 4); } catch (e) { qr.hidden = true; } };
    document.head.appendChild(s);
  }
})();
