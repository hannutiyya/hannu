(function () {
  'use strict';
  var form = document.getElementById('buy');
  if (!form) return;
  var cur = document.getElementById('currency');
  function radio(name) { var r = form.querySelector('input[name="' + name + '"]:checked'); return r ? r.value : (form.querySelector('input[type=hidden][name="' + name + '"]') || {}).value; }
  function update() {
    var c = cur ? cur.value : '';
    form.querySelectorAll('#rails [data-currency]').forEach(function (l) {
      var on = l.getAttribute('data-currency') === c;
      l.hidden = !on;
      var i = l.querySelector('input'); if (!on && i.checked) i.checked = false;
    });
    var visible = form.querySelectorAll('#rails [data-currency]:not([hidden]) input');
    if (visible.length === 1) visible[0].checked = true;
    var ed = radio('edition'), term = radio('term');
    form.querySelectorAll('#summary tr[data-edition]').forEach(function (tr) {
      tr.classList.toggle('picked', tr.getAttribute('data-edition') === ed && tr.getAttribute('data-term') === term);
    });
  }
  form.addEventListener('change', update);
  update();
  form.addEventListener('submit', function () { var b = form.querySelector('button[type=submit]'); if (b) { setTimeout(function () { b.disabled = true; b.textContent = 'Please wait…'; }, 0); } });
})();
