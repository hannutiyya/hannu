(function () {
  'use strict';
  document.querySelectorAll('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var t = document.getElementById(b.getAttribute('data-copy')); if (!t) return;
      t.select();
      (navigator.clipboard ? navigator.clipboard.writeText(t.value) : Promise.reject()).catch(function () { document.execCommand('copy'); });
      b.textContent = 'Copied';
    });
  });
  // While a payment is pending, look again every 15 seconds for up to 5 minutes.
  if (document.querySelector('form[action$="/check"]')) {
    var n = 0, t = setInterval(function () { if (++n > 20) { clearInterval(t); return; } if (!document.hidden) window.location.reload(); }, 15000);
  }
})();
