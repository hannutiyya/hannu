/* Minimal QR Code encoder (byte mode, error correction M, versions 1–40), after the QR Code specification (ISO/IEC 18004).
   Used only to show the authenticator set-up code; nothing leaves the page. */
(function (global) {
  'use strict';
  // Error correction codewords per block and number of blocks, level M, index = version.
  var ECC_M = [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28];
  var BLOCKS_M = [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49];

  function rawModules(ver) {
    var r = (16 * ver + 128) * ver + 64;
    if (ver >= 2) { var n = Math.floor(ver / 7) + 2; r -= (25 * n - 10) * n - 55; if (ver >= 7) r -= 36; }
    return r;
  }
  function dataCodewords(ver) { return Math.floor(rawModules(ver) / 8) - ECC_M[ver] * BLOCKS_M[ver]; }

  function gfMul(x, y) {
    var z = 0;
    for (var i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; }
    return z & 0xFF;
  }
  function rsDivisor(degree) {
    var res = []; for (var i = 0; i < degree - 1; i++) res.push(0); res.push(1);
    var root = 1;
    for (var i2 = 0; i2 < degree; i2++) {
      for (var j = 0; j < res.length; j++) { res[j] = gfMul(res[j], root); if (j + 1 < res.length) res[j] ^= res[j + 1]; }
      root = gfMul(root, 0x02);
    }
    return res;
  }
  function rsRemainder(data, div) {
    var res = div.map(function () { return 0; });
    data.forEach(function (b) {
      var f = b ^ res.shift(); res.push(0);
      div.forEach(function (c, i) { res[i] ^= gfMul(c, f); });
    });
    return res;
  }

  function encode(text) {
    var bytes = Array.prototype.slice.call(new TextEncoder().encode(text));
    var ver, cap;
    for (ver = 1; ver <= 40; ver++) {
      cap = dataCodewords(ver) * 8;
      var need = 4 + (ver < 10 ? 8 : 16) + bytes.length * 8;
      if (need <= cap) break;
    }
    if (ver > 40) throw new Error('Text too long for a QR code');
    var bits = [];
    function put(val, len) { for (var i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); }
    put(4, 4); put(bytes.length, ver < 10 ? 8 : 16);
    bytes.forEach(function (b) { put(b, 8); });
    put(0, Math.min(4, cap - bits.length));
    put(0, (8 - bits.length % 8) % 8);
    for (var pad = 0xEC; bits.length < cap; pad ^= 0xEC ^ 0x11) put(pad, 8);
    var data = [];
    for (var k = 0; k < bits.length; k += 8) { var v = 0; for (var q = 0; q < 8; q++) v = (v << 1) | bits[k + q]; data.push(v); }

    // Split into blocks, add error correction, interleave.
    var nb = BLOCKS_M[ver], ecl = ECC_M[ver], raw = Math.floor(rawModules(ver) / 8);
    var shortN = nb - raw % nb, shortLen = Math.floor(raw / nb);
    var div = rsDivisor(ecl), blocks = [], off = 0;
    for (var bi = 0; bi < nb; bi++) {
      var dl = shortLen - ecl + (bi < shortN ? 0 : 1);
      var dat = data.slice(off, off + dl); off += dl;
      var ec = rsRemainder(dat, div);
      if (bi < shortN) dat.push(0);
      blocks.push(dat.concat(ec));
    }
    var all = [];
    for (var i = 0; i < blocks[0].length; i++) {
      blocks.forEach(function (b, j) { if (i !== shortLen - ecl || j >= shortN) all.push(b[i]); });
    }

    var size = ver * 4 + 17;
    var mod = [], fn = [];
    for (var y = 0; y < size; y++) { mod.push(new Array(size).fill(false)); fn.push(new Array(size).fill(false)); }
    function set(x, y2, d) { mod[y2][x] = d; fn[y2][x] = true; }
    for (var t = 0; t < size; t++) { set(6, t, t % 2 === 0); set(t, 6, t % 2 === 0); }
    function finder(cx, cy) {
      for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) {
        var d = Math.max(Math.abs(dx), Math.abs(dy)), xx = cx + dx, yy = cy + dy;
        if (xx >= 0 && xx < size && yy >= 0 && yy < size) set(xx, yy, d !== 2 && d !== 4);
      }
    }
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    var pos = [];
    if (ver > 1) {
      var n = Math.floor(ver / 7) + 2, step = ver === 32 ? 26 : Math.ceil((ver * 4 + 4) / (n * 2 - 2)) * 2;
      pos = [6]; for (var pp = size - 7; pos.length < n; pp -= step) pos.splice(1, 0, pp);
    }
    pos.forEach(function (ax, ai) {
      pos.forEach(function (ay, aj) {
        if ((ai === 0 && aj === 0) || (ai === 0 && aj === pos.length - 1) || (ai === pos.length - 1 && aj === 0)) return;
        for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) set(ax + dx, ay + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
      });
    });
    function format(mask) {
      var d = (0 << 3) | mask; // level M = 00
      var rem = d; for (var i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
      var b = ((d << 10) | rem) ^ 0x5412;
      for (var i1 = 0; i1 <= 5; i1++) set(8, i1, ((b >>> i1) & 1) !== 0);
      set(8, 7, ((b >>> 6) & 1) !== 0); set(8, 8, ((b >>> 7) & 1) !== 0); set(7, 8, ((b >>> 8) & 1) !== 0);
      for (var i2 = 9; i2 < 15; i2++) set(14 - i2, 8, ((b >>> i2) & 1) !== 0);
      for (var i3 = 0; i3 < 8; i3++) set(size - 1 - i3, 8, ((b >>> i3) & 1) !== 0);
      for (var i4 = 8; i4 < 15; i4++) set(8, size - 15 + i4, ((b >>> i4) & 1) !== 0);
      set(8, size - 8, true);
    }
    format(0);
    if (ver >= 7) {
      var rem = ver; for (var i5 = 0; i5 < 12; i5++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
      var vb = (ver << 12) | rem;
      for (var i6 = 0; i6 < 18; i6++) {
        var bit = ((vb >>> i6) & 1) !== 0, a = size - 11 + i6 % 3, b2 = Math.floor(i6 / 3);
        set(a, b2, bit); set(b2, a, bit);
      }
    }
    // Place data in the zigzag order.
    var idx = 0;
    for (var right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (var vert = 0; vert < size; vert++) for (var j2 = 0; j2 < 2; j2++) {
        var x2 = right - j2, up = ((right + 1) & 2) === 0, y3 = up ? size - 1 - vert : vert;
        if (!fn[y3][x2] && idx < all.length * 8) { mod[y3][x2] = ((all[idx >>> 3] >>> (7 - (idx & 7))) & 1) !== 0; idx++; }
      }
    }
    function applyMask(m) {
      for (var yy = 0; yy < size; yy++) for (var xx = 0; xx < size; xx++) {
        var inv;
        switch (m) {
          case 0: inv = (xx + yy) % 2 === 0; break; case 1: inv = yy % 2 === 0; break; case 2: inv = xx % 3 === 0; break;
          case 3: inv = (xx + yy) % 3 === 0; break; case 4: inv = (Math.floor(xx / 3) + Math.floor(yy / 2)) % 2 === 0; break;
          case 5: inv = xx * yy % 2 + xx * yy % 3 === 0; break; case 6: inv = (xx * yy % 2 + xx * yy % 3) % 2 === 0; break;
          default: inv = ((xx + yy) % 2 + xx * yy % 3) % 2 === 0;
        }
        if (!fn[yy][xx] && inv) mod[yy][xx] = !mod[yy][xx];
      }
    }
    function penalty() {
      var p = 0, dark = 0;
      for (var yy = 0; yy < size; yy++) {
        for (var xx = 0; xx < size; xx++) {
          if (mod[yy][xx]) dark++;
          if (xx < size - 1 && yy < size - 1) { var c = mod[yy][xx]; if (c === mod[yy][xx + 1] && c === mod[yy + 1][xx] && c === mod[yy + 1][xx + 1]) p += 3; }
        }
      }
      for (var pass = 0; pass < 2; pass++) for (var a2 = 0; a2 < size; a2++) {
        var run = 1, line = [];
        for (var b3 = 0; b3 < size; b3++) line.push(pass ? mod[b3][a2] : mod[a2][b3]);
        for (var b4 = 1; b4 <= size; b4++) {
          if (b4 < size && line[b4] === line[b4 - 1]) { run++; } else { if (run >= 5) p += run - 2; run = 1; }
        }
        var s = line.map(function (z) { return z ? '1' : '0'; }).join('');
        var re = /(?=(10111010000|00001011101))/g; while (re.exec(s)) { p += 40; re.lastIndex++; }
      }
      var total = size * size, k2 = Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1;
      return p + Math.max(0, k2) * 10;
    }
    var best = 0, bestP = Infinity;
    for (var m = 0; m < 8; m++) { applyMask(m); format(m); var pn = penalty(); if (pn < bestP) { bestP = pn; best = m; } applyMask(m); }
    applyMask(best); format(best);
    return mod;
  }

  function svg(text, scale) {
    var m = encode(text), n = m.length, q = 4, path = '';
    for (var y = 0; y < n; y++) for (var x = 0; x < n; x++) if (m[y][x]) path += 'M' + (x + q) + ',' + (y + q) + 'h1v1h-1z';
    var dim = n + q * 2;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + dim + ' ' + dim + '" width="' + dim * (scale || 5) + '" height="' + dim * (scale || 5)
      + '" shape-rendering="crispEdges" role="img" aria-label="QR code"><rect width="100%" height="100%" fill="#fff"/><path d="' + path + '" fill="#000"/></svg>';
  }
  global.ShamQR = { encode: encode, svg: svg };
})(window);
