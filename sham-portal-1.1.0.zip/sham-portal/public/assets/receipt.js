(function () { var b = document.getElementById('print'); if (b) b.addEventListener('click', function () { window.print(); }); })();
