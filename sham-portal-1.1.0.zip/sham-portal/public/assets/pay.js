(function () {
  'use strict';
  var go = document.getElementById('go');
  if (go) setTimeout(function () { window.location.assign(go.href); }, 1200);
})();
