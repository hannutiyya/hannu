# Sham portal 1.0.0–1.1.0 and MediaOS SAML: security test report

Date: 7 November 2026. Tester: Claude (AI), working on the source code with the owner's authorisation.
Scope: the Sham portal (sham.et company site, product sites, store.sham.et store and admin, licensing.sham.et licence
server) running on PHP 8.3 + MariaDB 10.11, and the new SAML 2.0 staff sign-on in Sham MediaOS 2.2.0.

This is a white-box test by the same party that wrote the code. It is not a substitute for an independent
penetration test by an accredited firm, which banks, payment providers or large customers may ask for.

## Method

1. Code review of every request path: routing by host, sessions, CSRF, authentication and two-step sign-in, owner-only
   areas, every SQL statement, every template output, file and header handling, payments and webhooks, licence signing
   and check-in, the installer and the cron job.
2. Live probes against a local installation (54 automated checks, script kept with the test notes), covering security
   headers, cookie flags, reflected and stored XSS, CSRF, authentication bypass, host-header abuse, path traversal and
   file exposure, SQL injection, enumeration of orders and receipts, check-in fuzzing (malformed JSON, 2 MB bodies,
   wrong types), forged and replayed payment webhooks, and login brute force.
3. End-to-end abuse of the payment flow with a stand-in Stripe API: webhook with a wrong signature, webhook before
   payment, replayed webhook, and an underpayment.
4. A real Sham MediaOS 2.1.0 installation checking in against the portal: valid, revoked, licence bound to another
   installation, and released.
5. Line-by-line review of the SAML XML-signature verifier and service provider.

## Results

53 of 54 automated checks passed. The one "failure" is a design choice (below). Six weaknesses found in review were
fixed before release; none remains open at high or medium severity.

### Fixed during the test

| # | Severity | Finding | Fix |
|---|---|---|---|
| 1 | Medium | Payment API addresses (ArifPay, telebirr base URLs) could be changed by a signed-in owner without a fresh authenticator code. Someone with a stolen session could point payment confirmation at their own server and get free licences. | Changing any payment API address now needs a fresh code, and outside local testing the portal refuses any payment API address that is not HTTPS. |
| 2 | Medium | Responses ignored their own Content-Type: CSS, robots.txt, the sitemap and JSON were all sent as HTML. | Fixed header precedence in Response. |
| 3 | Low | The admin password-change form could be used to guess the current password without limit from a hijacked session. | 5 attempts per 15 minutes. |
| 4 | Low | Removing a stored payment key did not need a fresh code (only changing one did). | Removing also needs the code. |
| 5 | Low | HEAD requests were refused with 405 on public pages (monitoring tools and link checkers use HEAD). | HEAD is answered as GET. |
| 6 | Info | A licence refund could only be detected for pending orders in the admin. | "Check with the provider" is offered for paid orders too; the refund then revokes the licence. |

### Passed

- Headers on every response: strict CSP with a per-request nonce and no inline script or style, `frame-ancestors 'none'`,
  `X-Frame-Options: DENY`, `nosniff`, a strict referrer policy, permissions policy, HSTS on HTTPS. No `X-Powered-By`.
- Sessions: stored in the database, `__Host-` cookie, HttpOnly, Secure, SameSite=Lax, strict mode, a new ID at
  sign-in, 30 minutes idle for admins, 12 hours absolute. A password change signs out other sessions.
- CSRF token on every POST on every site (419 without it). Logout is POST.
- Admin: password (Argon2id) plus mandatory TOTP, ten single-use recovery codes, rate limits per address and per
  account, account lock after 10 failures, constant-time answer for unknown accounts. Owner-only areas are refused to
  staff on the server. Issuing licences, revoking, marking paid, changing keys and adding admins need a fresh code.
- No admin on the company, product or licensing hosts. Unknown hosts are redirected to the company site;
  `X-Forwarded-Host` is ignored. Forwarded client addresses are believed only from configured proxies or Cloudflare.
- SQL: prepared statements only, no string-built identifiers. Probes on slugs, search, renewals and check-in found
  nothing.
- Output escaping: all template output goes through `e()`. Markdown pages allow only a safe subset; links are limited
  to http(s), mailto and relative.
- Files: the application, configuration and keys live outside the web root; `.htaccess` refuses dotfiles, PHP other
  than index.php, SQL, Markdown, logs and archives. The installer works only once, only with the token from the server,
  and only for a database on the same server.
- Orders and receipts are reachable only by a 128-bit random reference. Renewals need the licence ID and its e-mail.
- Payments: amounts are never taken from the browser or the webhook body; the order is re-read from the provider. A
  wrong amount or currency puts the order on hold for a person. Webhooks are signature-checked (Stripe 5-minute window,
  PayPal verification API, Chapa HMAC, telebirr RSA, ArifPay token) and stored once per event. Forged → 401,
  replayed → no effect, early → retried by the provider.
- Licences: Ed25519-signed; the private key is stored encrypted with a key derived from the server secret and is
  never shown again. Check-ins are rate limited (30 a minute per address), size-limited and strictly typed for the IDs.
- Mail: no header injection (addresses validated, subject and names stripped of line breaks, MIME-encoded).
- Audit log: hash-chained; the dashboard warns if any entry is changed or deleted.

### Accepted by design

- The check-in endpoint keeps unknown or badly typed optional fields (hosts, version, usage) out instead of refusing the
  whole request, so a future MediaOS version never locks a customer out. IDs are validated strictly.
- Anyone who has a customer's licence ID and installation ID can ask for that licence's current check-in answer. Both
  are private to the customer, and the answer only repeats the licence they already hold.
- Ten failed sign-ins lock an admin account for 30 minutes; an attacker who knows an admin's e-mail can cause that
  delay but cannot get in.

## SAML 2.0 review (MediaOS 2.2.0)

Reviewed `XmlDsigVerifier` and `SamlServiceProvider` line by line, with the 9 SAML tests (182 assertions) and the
full API suite (838 tests, 0 failures). No findings. It defends against: XML signature wrapping (exactly one
assertion, directly under the response; signatures only on the response or that assertion; unique IDs counted over ID,
Id, id and AssertionID; data read only from the verified elements), XXE and entity expansion (DOCTYPE refused, no
network), comment truncation of the NameID (full text content is used), SHA-1, keys taken from the message (only the
configured certificate), replay (assertion IDs remembered until expiry, single-use RelayState), and wrong audience,
destination, recipient, issuer, status or time window. Limits to know: requests are not signed, no single logout,
encrypted assertions are refused with a clear message, certificate dates are not checked (the configured key is
pinned). It has not yet been tried against a real IdP; do that with your first Enterprise customer.

## Portal 1.1.0 retest (7 November 2026)

New surfaces: news and updates, product sub-pages, the media library, releases and downloads, the update check for
installations, customer accounts with one-time sign-in links, the "install on your server" command, news by e-mail
with one-click unsubscribe, admin roles (owner, sales, editor), the System page (backup, update from a package,
rollback) and the one-file setup wizard.

Result: 42 of 42 new automated checks passed, and the 54 earlier checks gave the same result as for 1.0.0 (53, plus the
one accepted by design). Found and fixed during development and review:

1. **Sign-in and unsubscribe links in e-mails acted on GET.** Mail systems open links to scan them, which would have
   used up sign-in links and unsubscribed readers. Both now show a page with one button (POST with CSRF); the RFC 8058
   one-click unsubscribe is a separate POST address that carries only the subscriber's random token.
2. **Editors could read the audit log**, which holds customer e-mail addresses. Restricted to the owner and sales.
3. **Emphasis inside link and image addresses**: the Markdown renderer could alter an address containing underscores.
   Addresses are now set aside before emphasis is applied; images are accepted only from the site's own /media and
   /assets.
4. **A product's post was reachable on two addresses.** The company host now redirects it to the product host.

Checked and passing: stored XSS through post titles, summaries and bodies on every page, feed and sitemap that shows
them (javascript: and protocol-relative links, foreign images, raw HTML all neutralised); reflected XSS on the new
pages; CSRF on every new admin action; login required for every new admin page; role limits (editor and sales refused
from settings, signing key, admins, system, editions and each other's areas); media path traversal; a PNG/PHP/HTML
polyglot upload is re-encoded and served with a sandbox CSP and nosniff; HTML and SVG uploads refused; forged and
expired download links and install codes refused; downloads and install commands refused for another customer's
licence; update checks give a download link only to the installation the licence is bound to; signed update answers
(UPD1) verify with the public key; update packages with `..` paths, without a version, or older than the installed
version are refused before anything is written; rollback refuses names outside its own folder; the database backup
and every code change need a fresh authenticator code; announcement and social links accept only https:// and
site-relative addresses.

Setup wizard: runs only for someone who proves control of the hosting account (a cPanel API token that cPanel accepts,
or database credentials that connect); CSRF token; at most 15 attempts per browser; the cPanel address is limited to
this server; stops 12 hours after the file arrived (inode change time, which an upload program cannot set back); stops
for good and deletes itself once installed; the code and configuration go outside the web root; the random database
password exists only in config.php (mode 600). Tested end to end against a stand-in cPanel API and in manual mode.

## Recommendations for the owner

1. Keep `D:\JMN\keys` offline and backed up; import the signing key only through the admin.
2. Turn on two-step sign-in for the cPanel account itself, and use a unique cPanel password: whoever controls cPanel
   controls the portal.
3. Put sham.et behind Cloudflare (free plan) and tick "behind Cloudflare" so addresses in rate limits are real.
4. Ask an independent firm for a penetration test before you sell to banks or government, and repeat it yearly.
