<?php

// Example only. The installer writes the real app/config.php. Keep that file private (chmod 600) and back it up:
// app_secret decrypts the stored payment keys and the licence signing key.

return [
    'installed' => true,
    'env' => 'production',            // 'local' shows error details; never on a live site
    'app_secret' => '',               // base64 of 32 random bytes
    'db' => ['host' => 'localhost', 'port' => 3306, 'name' => 'cpuser_sham', 'user' => 'cpuser_sham', 'pass' => '', 'socket' => ''],
    'hosts' => ['company' => 'sham.et', 'store' => 'store.sham.et', 'licensing' => 'licensing.sham.et'],
    'scheme' => 'https',
    'secure_cookies' => true,
    'trusted_proxies' => [],          // proxy addresses whose X-Forwarded-For is believed
    'cloudflare' => false,            // true when the sites are behind Cloudflare (CF-Connecting-IP is believed from Cloudflare ranges only)
];
