<?php
use Sham\Config;
use Sham\Content;
use Sham\Media;
use Sham\Settings;
use Sham\View;

$headline = Settings::get('home.hero_title') !== '' ? Settings::get('home.hero_title') : Settings::get('company.tagline');
$intro = Settings::get('home.hero_text') !== '' ? Settings::get('home.hero_text')
    : 'We build software that runs where our customers need it: on their own servers, on slow connections, in their languages, with the payment methods their customers already use.';
$logos = [];
foreach ($products as $p) {
    if (! empty($p['logo_media_id'])) {
        $m = \Sham\Db::one('SELECT uid, filename, alt FROM media WHERE id = ?', [(int) $p['logo_media_id']]);
        if ($m !== null) {
            $logos[(int) $p['id']] = $m;
        }
    }
}
?>
<section class="hero">
  <div class="wrap">
    <p class="eyebrow"><?= e(Settings::get('company.name')) ?></p>
    <h1><?= e($headline) ?></h1>
    <p class="lead"><?= nl2br(e($intro)) ?></p>
    <p class="actions"><a class="btn" href="#products">See our products</a> <a class="btn ghost" href="/contact">Talk to us</a></p>
  </div>
</section>
<section class="wrap block" id="products">
  <h2>Products</h2>
  <div class="cards">
    <?php foreach ($products as $p): $u = Content::productUrl($p); ?>
    <article class="card ac-<?= e(strtolower(ltrim((string) $p['accent'], '#'))) ?>">
      <?php if (isset($logos[(int) $p['id']])): $lg = $logos[(int) $p['id']]; ?><img class="logo" src="<?= e(Media::url($lg)) ?>" alt="" loading="lazy"><?php else: ?><p class="dot" aria-hidden="true"></p><?php endif ?>
      <?php if (($p['category'] ?? '') !== ''): ?><span class="kind"><?= e($p['category']) ?></span><?php endif ?>
      <h3><a href="<?= e($u) ?>"><?= e($p['name']) ?></a></h3>
      <p class="tagline"><?= e($p['tagline']) ?></p>
      <p><?= e($p['summary']) ?></p>
      <p><a class="more" href="<?= e($u) ?>">Learn more about <?= e($p['name']) ?> <span aria-hidden="true">→</span></a></p>
    </article>
    <?php endforeach ?>
  </div>
</section>
<?php if ($news !== []): ?>
<section class="band">
  <div class="wrap">
    <h2>Latest news</h2>
    <?= View::partial('_post-cards', ['posts' => $news, 'showProduct' => true]) ?>
    <p class="center"><a class="more" href="/news">All news and updates <span aria-hidden="true">→</span></a></p>
  </div>
</section>
<?php endif ?>
<?php if (trim($sections) !== ''): ?>
<section class="wrap block prose wide"><?= $sections ?></section>
<?php else: ?>
<section class="<?= $news !== [] ? 'wrap block' : 'band' ?>">
  <div class="wrap split">
    <div>
      <h2>Made in Ethiopia, supported by the people who built it</h2>
      <p>Every Sham product is designed, built and supported by our own team. You talk to the engineers who wrote the software, in a language you share.</p>
    </div>
    <div>
      <h2>Your data stays where you put it</h2>
      <p>Our platforms install on your own server or the cloud of your choice. We never hold your content, your readers or your patients.</p>
    </div>
  </div>
</section>
<?php endif ?>
