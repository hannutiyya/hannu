<?php $f = $f ?? []; $v = fn (string $k): string => (string) ($f[$k] ?? ''); ?>
<h1>Install the Sham portal</h1>
<?php if (isset($blocked)): ?>
  <p class="flash bad"><?= e($blocked) ?></p>
<?php elseif (isset($done)): ?>
  <p class="flash ok">Installed. The installer has switched itself off.</p>
  <?php if ($tokenLeft): ?><p class="flash bad">Delete app/install-token.txt in your file manager: the server could not delete it.</p><?php endif ?>
  <ol>
    <li>Point the other subdomains at this same folder in your hosting panel and switch on HTTPS (AutoSSL / Let's Encrypt) for each.</li>
    <li>Sign in at <a href="<?= e($admin) ?>"><?= e($admin) ?></a> and set up your authenticator app.</li>
    <li>Import the licence signing key (Signing key), then fill in Settings: company, payment methods and e-mail.</li>
    <li>Add the cron job shown in INSTALL.md.</li>
  </ol>
<?php else: ?>
<p>Have the database details from your hosting panel ready (MySQL Databases). Use a new, empty database.</p>
<form method="post" class="form" autocomplete="off" novalidate>
  <fieldset>
    <legend>Install token</legend>
    <label>The text in app/install-token.txt <input name="token" required spellcheck="false" class="mono"<?= aria_error($errors, 'token') ?>></label>
    <?= field_error($errors, 'token') ?>
  </fieldset>
  <fieldset>
    <legend>Database</legend>
    <div class="row2">
      <label>Host <input name="db_host" value="<?= e($v('db_host')) ?>"></label>
      <label>Port <input name="db_port" value="<?= e($v('db_port')) ?>" inputmode="numeric"></label>
    </div>
    <?= field_error($errors, 'db_host') ?>
    <label>Database name <input name="db_name" value="<?= e($v('db_name')) ?>" required></label>
    <?= field_error($errors, 'db_name') ?>
    <label>User <input name="db_user" value="<?= e($v('db_user')) ?>" required></label>
    <?= field_error($errors, 'db_user') ?>
    <label>Password <input type="password" name="db_pass" autocomplete="new-password"></label>
    <label>Socket <span class="opt">(only if your host says so)</span> <input name="db_socket" value="<?= e($v('db_socket')) ?>"></label>
    <?= field_error($errors, 'db_socket') ?>
  </fieldset>
  <fieldset>
    <legend>Web addresses</legend>
    <?php foreach (['company' => 'Company site', 'store' => 'Store and admin', 'licensing' => 'Licence server', 'media' => 'Sham MediaOS site', 'taligaa' => 'Taligaa site'] as $k => $lbl): ?>
      <label><?= e($lbl) ?> <input name="<?= e($k) ?>" value="<?= e($v($k)) ?>" required></label><?= field_error($errors, $k) ?>
    <?php endforeach ?>
    <label class="check"><input type="checkbox" name="cloudflare" value="1"<?= $v('cloudflare') === '1' ? ' checked' : '' ?>> <span>The sites are behind Cloudflare</span></label>
  </fieldset>
  <fieldset>
    <legend>Owner account</legend>
    <label>Company name <input name="company_name" value="<?= e($v('company_name')) ?>" required></label><?= field_error($errors, 'company_name') ?>
    <label>Your name <input name="name" value="<?= e($v('name')) ?>" required autocomplete="name"></label><?= field_error($errors, 'name') ?>
    <label>Your e-mail <input type="email" name="email" value="<?= e($v('email')) ?>" required autocomplete="email"></label><?= field_error($errors, 'email') ?>
    <label>Password (12 characters or more) <input type="password" name="password" required autocomplete="new-password" minlength="12"></label><?= field_error($errors, 'password') ?>
    <label>Password again <input type="password" name="password2" required autocomplete="new-password"></label><?= field_error($errors, 'password2') ?>
  </fieldset>
  <button class="btn" type="submit">Install</button>
</form>
<?php endif ?>
