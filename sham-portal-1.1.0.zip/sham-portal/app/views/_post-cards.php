<?php
// $posts, optional $showProduct
use Sham\Content;
use Sham\Media;
?>
<div class="posts">
  <?php foreach ($posts as $pst): $u = Content::postUrl($pst); ?>
  <article class="post-card">
    <?php if (($pst['cover_uid'] ?? null) !== null): ?><img src="<?= e(Media::url(['uid' => $pst['cover_uid'], 'filename' => $pst['cover_filename']])) ?>" alt="<?= e($pst['cover_alt'] ?? '') ?>" loading="lazy" decoding="async"><?php endif ?>
    <div class="in">
      <span class="kind"><?= e(Content::POST_KINDS[$pst['kind']] ?? 'News') ?><?= ! empty($showProduct) && ($pst['product_name'] ?? null) !== null ? ' · '.e($pst['product_name']) : '' ?></span>
      <h3><a href="<?= e($u) ?>"><?= e($pst['title']) ?></a></h3>
      <p class="meta"><time datetime="<?= e(gmdate('c', (int) strtotime($pst['published_at'].' UTC'))) ?>"><?= e(date_human((string) $pst['published_at'])) ?></time></p>
      <?php if ($pst['summary'] !== ''): ?><p><?= e($pst['summary']) ?></p><?php endif ?>
    </div>
  </article>
  <?php endforeach ?>
</div>
