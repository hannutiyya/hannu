<?php
use Sham\Config;
use Sham\Store\Catalogue;

$featureNames = ['newsroom' => 'Newsroom and CMS', 'website' => 'Website', 'newsletters' => 'Newsletters', 'local_payments' => 'Local payments',
    'ads' => 'Advertising', 'paywall' => 'Paywall and memberships', 'apps' => 'Branded apps', 'ai' => 'AI desk', 'analytics' => 'Analytics',
    'podcasts' => 'Podcasts', 'elections' => 'Elections', 'broadcast' => 'Rundowns and studios', 'live' => 'Live streaming',
    'interaction' => 'Interaction centre', 'syndication' => 'Syndication', 'sso' => 'Single sign-on', 'multi_brand' => 'Several brands',
    'dam_tiers' => 'Media storage tiers', 'audit_export' => 'Signed audit export', 'multi_region' => 'Several data centres'];
$limitNames = ['editions' => 'editions', 'languages' => 'languages', 'staff' => 'staff accounts', 'studios' => 'studios'];
$store = fn (string $path): string => Config::url('store', $path);
$cur = in_array('ETB', $currencies, true) ? 'ETB' : 'USD';
$base = $base ?? '';
?>
<section class="hero hero-product">
  <div class="wrap">
    <p class="eyebrow"><?= e($product['name']) ?></p>
    <h1><?= e($product['tagline']) ?></h1>
    <p class="lead"><?= e($product['summary']) ?></p>
    <p class="actions">
      <?php if ($editions !== []): ?><a class="btn" href="#editions">See editions and prices</a><?php endif ?>
      <a class="btn <?= $editions !== [] ? 'ghost' : '' ?>" href="<?= e($base) ?>/contact">Talk to our team</a>
    </p>
    <?php if (($product['trial_note'] ?? '') !== ''): ?><p class="note"><?= e($product['trial_note']) ?></p><?php endif ?>
    <?php if (! empty($latest)): ?><p class="note">Latest version: <a href="<?= e($base) ?>/releases#v<?= e($latest['version']) ?>"><?= e($latest['version']) ?></a>, <?= e(date_human((string) $latest['released_at'])) ?>.</p><?php endif ?>
  </div>
</section>
<section class="wrap block prose wide">
  <?= $body ?>
  <?php if (($product['regulatory_note'] ?? '') !== ''): ?><p class="reg"><?= e($product['regulatory_note']) ?></p><?php endif ?>
</section>
<?php if (! empty($news)): ?>
<section class="wrap block">
  <h2>News from <?= e($product['name']) ?></h2>
  <?= \Sham\View::partial('_post-cards', ['posts' => $news]) ?>
  <p class="center"><a class="more" href="<?= e($base) ?>/news">All <?= e($product['name']) ?> news <span aria-hidden="true">→</span></a></p>
</section>
<?php endif ?>
<?php if ($editions !== []): ?>
<section class="band" id="editions">
  <div class="wrap">
    <h2>Editions</h2>
    <p class="muted">Prices are per installation, per year, before VAT. A perpetual licence costs three years' price and includes one year of updates.</p>
    <div class="plans">
      <?php foreach ($editions as $ed):
          $limits = json_in((string) $ed['limits_json']);
          $features = json_in((string) $ed['features_json']);
          $usd = Catalogue::price($ed, 'year', 'USD');
          $local = $cur !== 'USD' ? Catalogue::price($ed, 'year', $cur) : null; ?>
      <article class="plan">
        <h3><?= e($ed['label']) ?></h3>
        <p class="price">
          <?php if ($usd === null): ?>On quotation
          <?php else: ?><?= e(money($usd, 'USD', true)) ?><span> a year</span><?php endif ?>
        </p>
        <?php if ($local !== null): ?><p class="price-alt"><?= e(money($local, $cur, true)) ?> a year</p><?php endif ?>
        <p><?= e($ed['blurb']) ?></p>
        <ul class="limits">
          <li><?= (int) $ed['max_domains'] ?> domain<?= (int) $ed['max_domains'] === 1 ? '' : 's' ?></li>
          <?php foreach ($limitNames as $k => $n): if (! array_key_exists($k, $limits) || $limits[$k] === 0) { continue; } ?>
          <li><?= $limits[$k] === null ? 'Unlimited '.e($n) : (int) $limits[$k].' '.e((int) $limits[$k] === 1 ? rtrim($n, 's') : $n) ?></li>
          <?php endforeach ?>
        </ul>
        <details>
          <summary>What is included</summary>
          <ul class="features"><?php foreach ($features as $f): ?><li><?= e($featureNames[$f] ?? $f) ?></li><?php endforeach ?></ul>
        </details>
        <p class="plan-cta">
          <?php if ($usd === null): ?><a class="btn ghost" href="<?= e($store('/quote/'.$product['slug'].'?edition='.$ed['ekey'])) ?>">Ask for a quotation</a>
          <?php else: ?><a class="btn" href="<?= e($store('/buy/'.$product['slug'].'?edition='.$ed['ekey'])) ?>">Buy <?= e($ed['label']) ?></a><?php endif ?>
        </p>
      </article>
      <?php endforeach ?>
    </div>
  </div>
</section>
<?php endif ?>
<section class="wrap block narrow center">
  <h2>Questions?</h2>
  <p>Tell us about your organisation and we will reply within two business days.</p>
  <p><a class="btn" href="<?= e($base) ?>/contact">Contact the <?= e($product['name']) ?> team</a></p>
</section>
