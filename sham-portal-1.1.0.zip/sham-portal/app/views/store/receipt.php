<?php $cur = (string) $order['currency']; $domains = json_in((string) $order['domains_json']); ?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?></title>
<link rel="stylesheet" href="/assets/receipt.css?v=<?= e(SHAM_VERSION) ?>">
</head>
<body>
<main class="receipt">
  <header>
    <div>
      <p class="co"><?= e($company['name']) ?></p>
      <p><?= nl2br(e($company['address'])) ?></p>
      <?php if ($company['tin'] !== ''): ?><p>TIN <?= e($company['tin']) ?></p><?php endif ?>
      <?php if ($company['vat_no'] !== ''): ?><p>VAT reg. no. <?= e($company['vat_no']) ?></p><?php endif ?>
      <p><?= e($company['email']) ?><?= $company['phone'] !== '' ? ' · '.e($company['phone']) : '' ?></p>
    </div>
    <div class="right">
      <h1><?= $order['status'] === 'refunded' ? 'Receipt (refunded)' : 'Receipt' ?></h1>
      <p>No. <strong><?= e($order['receipt_number']) ?></strong></p>
      <p>Date <?= e(date_human((string) ($order['paid_at'] ?? $order['created_at']))) ?></p>
      <p>Order <?= e(strtoupper(substr((string) $order['ref'], 0, 12))) ?></p>
    </div>
  </header>
  <section>
    <p class="h">Billed to</p>
    <p><?= e($order['customer_name']) ?><br><?= e($order['customer_email']) ?><?= $order['customer_country'] !== null ? '<br>'.e($order['customer_country']) : '' ?><?= ($order['company_tax_id'] ?? '') !== '' ? '<br>TIN / VAT '.e($order['company_tax_id']) : '' ?></p>
  </section>
  <table>
    <thead><tr><th>Description</th><th class="num">Amount</th></tr></thead>
    <tbody>
      <tr><td><?= e(($product['name'] ?? '').' '.($edition['label'] ?? $order['edition'])) ?> licence,
        <?= $order['term'] === 'perpetual' ? ($order['renews_licence_id'] !== null ? 'one update year' : 'perpetual') : 'one year' ?>
        <?php if ($order['licence_id'] !== null): ?><br><span class="small">Licence <?= e($order['licence_id']) ?></span><?php endif ?>
        <?php if ($domains !== []): ?><br><span class="small"><?= e(implode(', ', $domains)) ?></span><?php endif ?></td>
        <td class="num"><?= e(money((int) $order['net_minor'], $cur)) ?></td></tr>
      <tr><td>VAT</td><td class="num"><?= e(money((int) $order['vat_minor'], $cur)) ?></td></tr>
    </tbody>
    <tfoot><tr><th>Total paid</th><th class="num"><?= e(money((int) $order['total_minor'], $cur)) ?></th></tr></tfoot>
  </table>
  <p class="small">Paid with <?= e(ucfirst((string) $order['provider'])) ?><?= ($order['provider_reference'] ?? '') !== '' ? ', reference '.e($order['provider_reference']) : '' ?>.</p>
  <p class="small">This receipt confirms payment. Where Ethiopian law requires a fiscal or VAT invoice, we issue it separately and send it to the e-mail address above.</p>
  <p class="noprint"><button type="button" id="print">Print or save as PDF</button></p>
</main>
<script src="/assets/receipt.js?v=<?= e(SHAM_VERSION) ?>" nonce="<?= e($nonce) ?>" defer></script>
</body>
</html>
