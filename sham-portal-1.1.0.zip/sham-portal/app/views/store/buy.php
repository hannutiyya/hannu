<?php
use Sham\Settings;
use Sham\Store\Catalogue;

$old = $old ?? [];
$v = fn (string $k, string $d = ''): string => is_array($old[$k] ?? null) ? implode("\n", $old[$k]) : (string) ($old[$k] ?? $d);
$cur = $v('currency', $currencies[0] ?? 'USD');
$isRenew = is_array($renewing);
$vatPct = Settings::float('store.vat_percent');
?>
<section class="wrap block">
  <p class="eyebrow"><a href="/">Store</a></p>
  <h1><?= e($title) ?></h1>
  <?php if (isset($errors['form'])): ?><div class="notice err" role="alert"><?= e($errors['form']) ?></div><?php endif ?>
  <?php if (isset($errors['renews'])): ?><div class="notice err" role="alert"><?= e($errors['renews']) ?></div><?php endif ?>
  <?php if ($editions === []): ?>
    <p>This product is sold on quotation. <a href="/quote/<?= e($product['slug']) ?>">Ask our team</a>.</p>
  <?php else: ?>
  <form method="post" class="form buy" id="buy" novalidate>
    <?= csrf_field() ?>
    <?php if ($isRenew): ?>
      <input type="hidden" name="renews" value="<?= e($renewing['id']) ?>">
      <input type="hidden" name="edition" value="<?= e($renewing['edition']) ?>">
      <input type="hidden" name="term" value="<?= $renewing['term'] === 'perpetual' ? 'perpetual' : 'year' ?>">
      <div class="notice">
        <p>Renewing licence <strong class="mono"><?= e($renewing['id']) ?></strong> (<?= e($editions[0]['label'] ?? $renewing['edition']) ?>).
        <?= $renewing['term'] === 'perpetual'
            ? 'This buys one more year of updates, counted from today; your perpetual licence keeps working either way.'
            : 'This adds one year from today or from the current expiry date, whichever is later.' ?></p>
      </div>
    <?php else: ?>
    <fieldset>
      <legend>1. Edition</legend>
      <div class="choices">
      <?php foreach ($editions as $ed): ?>
        <label class="choice"><input type="radio" name="edition" value="<?= e($ed['ekey']) ?>" data-domains="<?= (int) $ed['max_domains'] ?>"<?= $v('edition') === $ed['ekey'] ? ' checked' : '' ?>>
          <span><strong><?= e($ed['label']) ?></strong> <span class="muted">— <?= e(money((int) Catalogue::price($ed, 'year', 'USD'), 'USD', true)) ?> a year, up to <?= (int) $ed['max_domains'] ?> domains</span><br><span class="small"><?= e($ed['blurb']) ?></span></span></label>
      <?php endforeach ?>
      </div>
      <?= field_error($errors, 'edition') ?>
    </fieldset>
    <fieldset>
      <legend>2. Term</legend>
      <div class="choices row">
        <label class="choice"><input type="radio" name="term" value="year"<?= $v('term', 'year') !== 'perpetual' ? ' checked' : '' ?>><span><strong>One year</strong><br><span class="small">Renew each year. Updates and support included.</span></span></label>
        <label class="choice"><input type="radio" name="term" value="perpetual"<?= $v('term') === 'perpetual' ? ' checked' : '' ?>><span><strong>Perpetual</strong><br><span class="small">Three years' price. Yours to keep; one year of updates, then optional update years.</span></span></label>
      </div>
      <?= field_error($errors, 'term') ?>
    </fieldset>
    <fieldset>
      <legend>3. Domains</legend>
      <label>The domain names the platform will run on, one per line <textarea name="domains" rows="3" spellcheck="false" placeholder="news.example.com"<?= aria_error($errors, 'domains') ?>><?= e($v('domains')) ?></textarea></label>
      <p class="muted small">Subdomains of a listed domain are included (www, api, newsroom…). Staging and localhost always work.</p>
      <?= field_error($errors, 'domains') ?>
    </fieldset>
    <?php endif ?>
    <fieldset>
      <legend><?= $isRenew ? '1' : '4' ?>. Licensee</legend>
      <label>Organisation name (appears on the licence and receipt) <input name="name" maxlength="160" autocomplete="organization" required value="<?= e($v('name')) ?>"<?= aria_error($errors, 'name') ?>></label>
      <?= field_error($errors, 'name') ?>
      <label>E-mail for the licence key and receipt <input type="email" name="email" maxlength="190" autocomplete="email" required value="<?= e($v('email')) ?>"<?= $isRenew ? ' readonly' : '' ?><?= aria_error($errors, 'email') ?>></label>
      <?= field_error($errors, 'email') ?>
      <div class="row2">
        <label>Country code <span class="opt">(e.g. ET)</span> <input name="country" maxlength="2" autocomplete="country" value="<?= e($v('country')) ?>"<?= aria_error($errors, 'country') ?>></label>
        <label>TIN / VAT number <span class="opt">(optional)</span> <input name="tax_id" maxlength="40" value="<?= e($v('tax_id')) ?>"></label>
      </div>
      <?= field_error($errors, 'country') ?>
      <label>Phone <span class="opt">(needed for telebirr and Chapa)</span> <input type="tel" name="phone" maxlength="40" autocomplete="tel" value="<?= e($v('phone')) ?>"></label>
    </fieldset>
    <fieldset>
      <legend><?= $isRenew ? '2' : '5' ?>. Payment</legend>
      <?php if ($currencies === []): ?>
        <p class="notice err">Online payment is not open yet. <a href="/quote/<?= e($product['slug']) ?>">Ask our team for an invoice</a>.</p>
      <?php else: ?>
      <label>Currency <select name="currency" id="currency">
        <?php foreach ($currencies as $c): ?><option value="<?= e($c) ?>"<?= $cur === $c ? ' selected' : '' ?>><?= e($c === 'ETB' ? 'Ethiopian birr (ETB)' : 'US dollars (USD)') ?></option><?php endforeach ?>
      </select></label>
      <?= field_error($errors, 'currency') ?>
      <div class="choices" id="rails">
      <?php foreach ($rails as $c => $list): foreach ($list as $g): ?>
        <label class="choice" data-currency="<?= e($c) ?>"><input type="radio" name="provider" value="<?= e($g['key']) ?>"<?= $v('provider') === $g['key'] && $cur === $c ? ' checked' : '' ?>>
          <span><strong><?= e($g['label']) ?></strong> <span class="muted small">(<?= e($c) ?>)</span></span></label>
      <?php endforeach; endforeach ?>
      </div>
      <?= field_error($errors, 'provider') ?>
      <?php endif ?>
    </fieldset>
    <?php if ($currencies !== []): ?>
    <div class="summary" id="summary" aria-live="polite">
      <table class="table compact">
        <thead><tr><th scope="col">Price before VAT</th><?php foreach ($currencies as $c): ?><th scope="col"><?= e($c) ?></th><?php endforeach ?></tr></thead>
        <tbody>
        <?php foreach ($editions as $ed): foreach (($isRenew ? [$renewing['term'] === 'perpetual' ? 'perpetual' : 'year'] : ['year', 'perpetual']) as $t): ?>
          <tr data-edition="<?= e($ed['ekey']) ?>" data-term="<?= e($t) ?>">
            <th scope="row"><?= e($ed['label']) ?>, <?= $t === 'year' ? 'one year' : ($isRenew ? 'one update year' : 'perpetual') ?></th>
            <?php foreach ($currencies as $c): $pr = Catalogue::price($ed, $t, $c, $isRenew && $t === 'perpetual'); ?><td><?= $pr === null ? '—' : e(money($pr, $c)) ?></td><?php endforeach ?>
          </tr>
        <?php endforeach; endforeach ?>
        </tbody>
      </table>
      <p class="muted small">VAT of <?= e(rtrim(rtrim(number_format($vatPct, 2), '0'), '.')) ?>% is added for customers in <?= e(Settings::get('store.vat_countries')) ?>. The exact total is shown before you pay.</p>
    </div>
    <?php endif ?>
    <label class="check"><input type="checkbox" name="accept_terms" value="1"<?= ($old['accept_terms'] ?? false) ? ' checked' : '' ?><?= aria_error($errors, 'accept_terms') ?>>
      <span>I accept the <a href="/legal/licence-agreement" target="_blank" rel="noopener">licence agreement</a> and the <a href="/legal/terms-of-sale" target="_blank" rel="noopener">terms of sale</a>, and I have read the <a href="/legal/privacy" target="_blank" rel="noopener">privacy policy</a>.</span></label>
    <?= field_error($errors, 'accept_terms') ?>
    <button class="btn big" type="submit"<?= $currencies === [] ? ' disabled' : '' ?>>Continue to payment</button>
  </form>
  <script src="/assets/store.js?v=<?= e(SHAM_VERSION) ?>" nonce="<?= e($nonce) ?>" defer></script>
  <?php endif ?>
</section>
