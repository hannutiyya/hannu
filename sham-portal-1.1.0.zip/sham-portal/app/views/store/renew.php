<section class="wrap narrow block">
  <p class="eyebrow"><a href="/">Store</a></p>
  <h1>Renew a licence</h1>
  <p class="lead">Enter the licence ID and the e-mail address it was issued to. You pay for one more year; the new key arrives by e-mail and your installation also picks it up by itself at its next daily check.</p>
  <form method="post" class="form" novalidate>
    <?= csrf_field() ?>
    <label>Licence ID <input name="licence" class="mono" required placeholder="LIC-…" maxlength="40" spellcheck="false" value="<?= e($old['licence']) ?>"<?= aria_error($errors, 'licence') ?>></label>
    <?= field_error($errors, 'licence') ?>
    <label>E-mail <input type="email" name="email" required maxlength="190" autocomplete="email" value="<?= e($old['email']) ?>"></label>
    <button class="btn" type="submit">Continue</button>
  </form>
  <p class="muted small">Your licence ID is in Administration → Licence in your installation, and in the e-mail that brought your key.</p>
</section>
