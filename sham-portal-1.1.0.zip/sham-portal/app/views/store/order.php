<?php
$st = (string) $order['status'];
$ref = strtoupper(substr((string) $order['ref'], 0, 12));
$label = ['pending' => 'Waiting for payment', 'review' => 'Being checked by our team', 'paid' => 'Paid, preparing your licence', 'fulfilled' => 'Paid and delivered',
    'failed' => 'Payment failed', 'cancelled' => 'Cancelled', 'expired' => 'Expired', 'refunded' => 'Refunded'][$st] ?? ucfirst($st);
$domains = json_in((string) $order['domains_json']);
?>
<section class="wrap narrow block">
  <p class="eyebrow">Order <span class="mono"><?= e($ref) ?></span></p>
  <h1><?= e($label) ?></h1>
  <?php if ($cancelled && $st === 'pending'): ?><div class="notice" role="status">You left the payment page before paying. You can try again below, or choose another method from the store.</div><?php endif ?>
  <?php if ((int) $order['test_mode'] === 1): ?><div class="notice err">Test mode: no real money moves and the licence is for testing only.</div><?php endif ?>

  <dl class="facts">
    <dt>Product</dt><dd><?= e($product['name'] ?? '') ?> <?= e($edition['label'] ?? $order['edition']) ?></dd>
    <dt>Term</dt><dd><?= $order['term'] === 'perpetual' ? ($order['renews_licence_id'] !== null ? 'One update year' : 'Perpetual') : 'One year' ?></dd>
    <?php if ($domains !== []): ?><dt>Domains</dt><dd><?= e(implode(', ', $domains)) ?></dd><?php endif ?>
    <dt>Licensee</dt><dd><?= e($order['customer_name']) ?> (<?= e($order['customer_email']) ?>)</dd>
    <dt>Total</dt><dd><strong><?= e(money((int) $order['total_minor'], (string) $order['currency'])) ?></strong><?= (int) $order['vat_minor'] > 0 ? ' including VAT of '.e(money((int) $order['vat_minor'], (string) $order['currency'])) : '' ?></dd>
    <dt>Placed</dt><dd><?= e(date_human((string) $order['created_at'])) ?></dd>
  </dl>

  <?php if ($st === 'pending' && $bank !== null): ?>
    <h2>Pay by bank transfer</h2>
    <p>Transfer the exact amount and write the payment reference in the transfer description. We confirm transfers within two business days and send your licence key by e-mail.</p>
    <dl class="facts bank"><?php foreach ($bank as $k => $val): ?><dt><?= e($k) ?></dt><dd class="mono"><?= e($val) ?></dd><?php endforeach ?></dl>
  <?php elseif ($st === 'pending'): ?>
    <p>If you have paid, it can take a minute for <?= e(ucfirst((string) $order['provider'])) ?> to confirm. This page checks again by itself.</p>
    <div class="actions">
      <form method="post" action="/order/<?= e($order['ref']) ?>/check"><?= csrf_field() ?><button class="btn" type="submit">Check the payment now</button></form>
      <?php if (str_starts_with((string) $order['checkout_url'], 'https://')): ?><a class="btn ghost" href="/order/<?= e($order['ref']) ?>/pay">Go back to the payment page</a><?php endif ?>
    </div>
    <script src="/assets/order.js?v=<?= e(SHAM_VERSION) ?>" nonce="<?= e($nonce) ?>" defer></script>
  <?php elseif ($st === 'review'): ?>
    <p>The payment did not match the order exactly, so a person on our team is checking it. We will write to <?= e($order['customer_email']) ?> within one business day.</p>
  <?php elseif ($st === 'failed' || $st === 'expired' || $st === 'cancelled'): ?>
    <p><?= e((string) ($order['failure_reason'] ?? '')) ?></p>
    <p><a class="btn" href="/buy/<?= e($product['slug'] ?? '') ?>">Start a new order</a></p>
  <?php endif ?>

  <?php if (is_array($licence) && $st === 'fulfilled'): ?>
    <h2>Your licence</h2>
    <p>We have e-mailed this to <?= e($order['customer_email']) ?>. In your installation, open <strong>Administration → Licence</strong>, paste the key and save. Nothing is reinstalled.</p>
    <dl class="facts">
      <dt>Licence ID</dt><dd class="mono"><?= e($licence['id']) ?></dd>
      <dt>Valid until</dt><dd><?= $licence['expires_at'] === null ? 'No end date (perpetual)' : e(date_human((string) $licence['expires_at'])) ?></dd>
      <dt>Updates until</dt><dd><?= e(date_human((string) $licence['updates_until'])) ?></dd>
    </dl>
    <label for="key">Licence key</label>
    <textarea id="key" class="mono key" rows="6" readonly><?= e($licence['token']) ?></textarea>
    <p class="actions"><button class="btn" type="button" data-copy="key">Copy the key</button> <a class="btn ghost" href="/order/<?= e($order['ref']) ?>/receipt">Receipt</a></p>
    <script src="/assets/order.js?v=<?= e(SHAM_VERSION) ?>" nonce="<?= e($nonce) ?>" defer></script>
  <?php elseif (in_array($st, ['paid', 'refunded'], true)): ?>
    <p><a class="btn ghost" href="/order/<?= e($order['ref']) ?>/receipt">Receipt</a></p>
  <?php endif ?>
  <p class="muted small">Questions about this order? Write to <a href="mailto:<?= e(\Sham\Settings::get('company.sales_email')) ?>?subject=Order%20<?= e($ref) ?>"><?= e(\Sham\Settings::get('company.sales_email')) ?></a> with the reference <?= e($ref) ?>.</p>
</section>
