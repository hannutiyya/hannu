<?php
use Sham\Store\Catalogue;
?>
<section class="wrap block">
  <h1>Store</h1>
  <p class="lead">Buy, renew or ask for a quotation. Your licence key arrives by e-mail as soon as the payment is confirmed.</p>
  <p><a href="/renew">Renew an existing licence</a></p>
  <?php foreach ($items as $it): $p = $it['product']; ?>
  <section class="store-product ac-<?= e(strtolower(ltrim((string) $p['accent'], '#'))) ?>">
    <h2><?= e($p['name']) ?></h2>
    <p><?= e($p['tagline']) ?></p>
    <?php if ($it['editions'] === []): ?>
      <p><a class="btn ghost" href="/quote/<?= e($p['slug']) ?>">Ask our team</a></p>
    <?php else: ?>
    <table class="table">
      <thead><tr><th scope="col">Edition</th><th scope="col">Per year</th><th scope="col">Perpetual</th><th scope="col"><span class="sr">Action</span></th></tr></thead>
      <tbody>
      <?php foreach ($it['editions'] as $ed): $y = Catalogue::price($ed, 'year', 'USD'); $pp = Catalogue::price($ed, 'perpetual', 'USD'); ?>
        <tr>
          <th scope="row"><?= e($ed['label']) ?><span class="muted small block"><?= e($ed['blurb']) ?></span></th>
          <td><?= $y === null ? 'Quotation' : e(money($y, 'USD', true)) ?></td>
          <td><?= $pp === null ? 'Quotation' : e(money($pp, 'USD', true)) ?></td>
          <td><?= $y === null ? '<a href="/quote/'.e($p['slug']).'?edition='.e($ed['ekey']).'">Ask</a>' : '<a class="btn small" href="/buy/'.e($p['slug']).'?edition='.e($ed['ekey']).'">Buy</a>' ?></td>
        </tr>
      <?php endforeach ?>
      </tbody>
    </table>
    <?php endif ?>
  </section>
  <?php endforeach ?>
  <p class="muted small">Prices before VAT. VAT is added for customers in Ethiopia. <?= in_array('ETB', $currencies, true) ? 'You can pay in birr at the rate shown at checkout.' : '' ?></p>
</section>
