<section class="wrap narrow block center">
  <h1>Continue to payment</h1>
  <p class="lead">You will pay <strong><?= e(money((int) $order['total_minor'], (string) $order['currency'])) ?></strong> with <?= e($gateway) ?>.</p>
  <p>The payment page belongs to <?= e($gateway) ?>. When you finish, you come back here and we confirm the payment with them directly.</p>
  <?php if (str_starts_with((string) $order['checkout_url'], 'https://')): ?><p><a class="btn big" id="go" rel="noreferrer" href="<?= e($order['checkout_url']) ?>">Pay with <?= e($gateway) ?></a></p><?php endif ?>
  <p class="muted small">Order reference <span class="mono"><?= e(strtoupper(substr((string) $order['ref'], 0, 12))) ?></span>. Keep this page's address to see your order later.</p>
  <p><a href="/order/<?= e($order['ref']) ?>">See the order without paying now</a></p>
</section>
<script src="/assets/pay.js?v=<?= e(SHAM_VERSION) ?>" nonce="<?= e($nonce) ?>" defer></script>
