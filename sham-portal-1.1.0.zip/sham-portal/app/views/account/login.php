<section class="wrap narrow block">
  <h1>Your licences and downloads</h1>
  <?php if (! empty($confirm)): ?>
    <p>Press the button to sign in. The link works once.</p>
    <form method="post" action="/account/login/<?= e($confirm) ?>">
      <?= csrf_field() ?>
      <button class="btn" type="submit">Sign in</button>
    </form>
  <?php elseif ($sent): ?>
    <div class="notice ok" role="status"><p>If we have licences or orders for that address, a sign-in link is on its way. It works once, for 30 minutes. Check the spam folder too.</p></div>
  <?php else: ?>
    <p class="lead">Enter the e-mail address your licence was issued to. We send you a link: no password needed.</p>
    <?php if ($error !== null): ?><div class="notice err" role="alert"><p><?= e($error) ?></p></div><?php endif ?>
    <form method="post" action="/account" class="form">
      <?= csrf_field() ?>
      <label>E-mail address <input type="email" name="email" required maxlength="190" autocomplete="email"></label>
      <p><button class="btn" type="submit">Send me a sign-in link</button></p>
    </form>
    <p class="muted small">Lost the e-mail with your key? Sign in here and copy it again. Bought for your organisation by someone else? Ask them, or <a href="<?= e(\Sham\Config::url('company', '/contact')) ?>">write to us</a>.</p>
  <?php endif ?>
</section>
