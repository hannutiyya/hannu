<section class="wrap narrow block">
  <p class="eyebrow"><a href="/account">Your licences</a></p>
  <h1>Install <?= e($licence['product_name']) ?> on your server</h1>
  <?php if ($command !== null): ?>
    <div class="notice ok" role="status"><p>Paste this line into the terminal of a fresh <strong>Ubuntu 24.04</strong> server (logged in over SSH). It works for 24 hours.</p></div>
    <label class="sr" for="cmd">Install command</label>
    <textarea class="key" id="cmd" rows="3" readonly><?= e($command) ?></textarea>
    <p class="small muted">It downloads the newest version your licence includes, checks it, prepares the server (firewall, Docker, HTTPS certificates), installs Sham MediaOS under your name with your licence key, and starts it. It takes 10 to 20 minutes. The address must already point at the server (a DNS A record). The first administrator's password is shown at the end and kept in /root/jmn-admin-password.</p>
    <p class="small muted">Keep this line to yourself: it contains a link to your licence key.</p>
  <?php else: ?>
    <p class="lead">Answer three questions and we make a one-line command that installs everything on your server, with no files to edit.</p>
    <?php if ($error !== null): ?><div class="notice err" role="alert"><p><?= e($error) ?></p></div><?php endif ?>
    <form method="post" class="form">
      <?= csrf_field() ?>
      <label>Web address of the news site <input name="host" required maxlength="190" value="<?= e($old['host']) ?>" spellcheck="false" placeholder="news.example.com"></label>
      <label>E-mail of the first administrator <input type="email" name="admin" required maxlength="190" value="<?= e($old['admin']) ?>"></label>
      <label>Name of the organisation <input name="org" required maxlength="120" value="<?= e($old['org']) ?>"></label>
      <p><button class="btn" type="submit">Make the install command</button></p>
    </form>
    <p class="small muted">Prefer to do it by hand, or use Docker, Kubernetes or a browser installer? Download the package from your account and follow the installation guide inside.</p>
  <?php endif ?>
</section>
