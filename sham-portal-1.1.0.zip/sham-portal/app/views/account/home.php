<?php
use Sham\Config;

$active = fn (array $l): bool => $l['status'] === 'active' && ($l['expires_at'] === null || strtotime($l['expires_at'].' UTC') > time());
?>
<section class="wrap block">
  <h1>Your licences and downloads</h1>
  <p class="muted">Signed in as <strong><?= e($email) ?></strong>.</p>
  <form method="post" action="/account/logout"><?= csrf_field() ?><button class="btn small ghost" type="submit">Sign out</button></form>

  <h2>Licences</h2>
  <?php if ($licences === []): ?><p class="muted">No licences for this address yet.</p><?php endif ?>
  <?php foreach ($licences as $l): $ok = $active($l); ?>
  <article class="release">
    <h3><?= e($l['product_name']) ?> · <?= e(ucfirst((string) $l['edition'])) ?>
      <span class="badge <?= $ok ? 'ok' : 'warn' ?>"><?= $ok ? 'active' : e($l['status'] === 'active' ? 'expired' : $l['status']) ?></span></h3>
    <dl class="facts">
      <dt>Licence</dt><dd class="mono"><?= e($l['id']) ?></dd>
      <dt>Issued to</dt><dd><?= e($l['customer_name']) ?></dd>
      <dt>Domains</dt><dd><?= e(implode(', ', json_in((string) $l['domains_json']))) ?></dd>
      <dt>Valid until</dt><dd><?= $l['expires_at'] === null ? 'No end date (perpetual)' : e(date_human((string) $l['expires_at'])) ?></dd>
      <dt>Updates until</dt><dd><?= $l['updates_until'] === null ? 'With the licence' : e(date_human((string) $l['updates_until'])) ?></dd>
      <?php if ($l['last_check_in_at'] !== null): ?><dt>Last seen</dt><dd><?= e(date_human((string) $l['last_check_in_at'])) ?><?= $l['last_version'] !== null ? ', version '.e($l['last_version']) : '' ?></dd><?php endif ?>
    </dl>
    <?php if ($ok): ?>
    <details>
      <summary>Show the licence key</summary>
      <p class="small muted">Paste it in your installation under Administration → Licence.</p>
      <textarea class="key" id="key-<?= e($l['id']) ?>" rows="4" readonly><?= e($l['token']) ?></textarea>
    </details>
    <?php endif ?>
    <?php if (! empty($downloads[$l['id']])): ?>
      <p><strong>Downloads</strong></p>
      <ul>
      <?php foreach ($downloads[$l['id']] as $rel): ?>
        <li><a href="/account/download/<?= (int) $rel['id'] ?>/<?= e($l['id']) ?>" rel="nofollow"><?= e($l['product_name']) ?> <?= e($rel['version']) ?></a>
          <span class="muted small"><?= e(date_human((string) $rel['released_at'])) ?><?= $rel['channel'] === 'beta' ? ' · beta' : '' ?><?= (int) $rel['critical'] === 1 ? ' · security update' : '' ?></span></li>
      <?php endforeach ?>
      </ul>
    <?php endif ?>
    <?php if ($ok && ($l['licence_kind'] ?? '') === 'mediaos'): ?><p><a class="btn small" href="/account/install/<?= e($l['id']) ?>">Install on a server</a></p><?php endif ?>
    <p><a class="btn small<?= $ok ? ' ghost' : '' ?>" href="<?= e(Config::url('store', '/renew?licence='.rawurlencode((string) $l['id']))) ?>">Renew or upgrade</a></p>
  </article>
  <?php endforeach ?>

  <h2>Orders and receipts</h2>
  <?php if ($orders === []): ?><p class="muted">No orders.</p><?php else: ?>
  <div class="scroll"><table class="table compact">
    <thead><tr><th scope="col">Date</th><th scope="col">Product</th><th scope="col">Total</th><th scope="col">Status</th><th scope="col">Receipt</th></tr></thead>
    <tbody><?php foreach ($orders as $o): ?>
      <tr><td><?= e(date_human((string) $o['created_at'])) ?></td><td><?= e($o['product_name']) ?> · <?= e($o['edition']) ?></td>
        <td><?= e(money((int) $o['total_minor'], (string) $o['currency'])) ?></td><td><?= e($o['status']) ?></td>
        <td><?php if ($o['receipt_number'] !== null): ?><a href="/order/<?= e($o['ref']) ?>/receipt"><?= e($o['receipt_number']) ?></a><?php elseif ($o['status'] === 'pending'): ?><a href="/order/<?= e($o['ref']) ?>">Continue</a><?php endif ?></td></tr>
    <?php endforeach ?></tbody>
  </table></div>
  <?php endif ?>
</section>
