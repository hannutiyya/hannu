<h1>Authenticator code</h1>
<?php if ($error): ?><p class="flash bad" role="alert"><?= e($error) ?></p><?php endif ?>
<form method="post" class="form">
  <?= csrf_field() ?>
  <label>The 6-digit code from your authenticator app <input name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="11" required autofocus></label>
  <button class="btn" type="submit">Sign in</button>
</form>
<p class="muted small">Lost your phone? Enter one of your recovery codes (XXXXX-XXXXX) instead. Each works once.</p>
<p class="small"><a href="/admin/login">Start again</a></p>
