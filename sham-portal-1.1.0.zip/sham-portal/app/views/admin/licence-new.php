<?php $v = fn (string $k, string $d = ''): string => (string) ($old[$k] ?? $d); ?>
<p class="crumbs"><a href="/admin/licences">Licences</a></p>
<h1>Issue a licence</h1>
<p>For a sale made outside the store (an invoice, a partner, a demo). The key is signed now and shown on the next page.</p>
<form method="post" class="form wide-form" novalidate>
  <?= csrf_field() ?>
  <div class="row2">
    <label>Product <select name="product"><?php foreach ($products as $p): ?><option value="<?= (int) $p['id'] ?>"<?= $v('product') === (string) $p['id'] ? ' selected' : '' ?>><?= e($p['name']) ?></option><?php endforeach ?></select></label>
    <label>Edition <select name="edition"><?php foreach ($editions as $pid => $list): foreach ($list as $ed): ?><option value="<?= e($ed['ekey']) ?>"<?= $v('edition') === $ed['ekey'] ? ' selected' : '' ?>><?= e($ed['label']) ?><?= count($editions) > 1 ? ' ('.(int) $pid.')' : '' ?></option><?php endforeach; endforeach ?></select></label>
  </div>
  <?= field_error($errors, 'product') ?><?= field_error($errors, 'edition') ?>
  <div class="row3">
    <label>Term <select name="term">
      <option value="year"<?= $v('term') === 'year' ? ' selected' : '' ?>>One year</option>
      <option value="perpetual"<?= $v('term') === 'perpetual' ? ' selected' : '' ?>>Perpetual</option>
      <option value="custom"<?= $v('term') === 'custom' ? ' selected' : '' ?>>Custom months</option>
    </select></label>
    <label>Months (custom term) <input type="number" name="months" min="1" max="120" value="<?= e($v('months', '12')) ?>"></label>
    <label>Months of updates <input type="number" name="update_months" min="1" max="120" value="<?= e($v('update_months', '12')) ?>"></label>
  </div>
  <?= field_error($errors, 'term') ?>
  <label>Domains, one per line <textarea name="domains" rows="3" spellcheck="false"><?= e($v('domains')) ?></textarea></label>
  <?= field_error($errors, 'domains') ?>
  <div class="row3">
    <label>Licensee <input name="name" maxlength="160" value="<?= e($v('name')) ?>"></label>
    <label>E-mail <input type="email" name="email" maxlength="190" value="<?= e($v('email')) ?>"></label>
    <label>Country <input name="country" maxlength="2" value="<?= e($v('country')) ?>"></label>
  </div>
  <?= field_error($errors, 'name') ?><?= field_error($errors, 'email') ?>
  <label class="check"><input type="checkbox" name="offline" value="1"<?= ($old['offline'] ?? false) ? ' checked' : '' ?>> <span>Offline licence (the installation never needs to check in; for air-gapped sites)</span></label>
  <label>Notes <input name="notes" maxlength="400" value="<?= e($v('notes')) ?>"></label>
  <?= \Sham\View::partial('admin/_code') ?>
  <?= field_error($errors, 'confirm_code') ?>
  <button class="btn" type="submit">Sign and issue</button>
</form>
