<?php $p = $product; $owner = $owner ?? false; ?>
<p class="crumbs"><a href="/admin/products">Products</a></p>
<h1><?= e($p['name']) ?></h1>
<form method="post" class="form wide-form" novalidate>
  <?= csrf_field() ?>
  <div class="row3">
    <label>Name <input name="name" maxlength="120" value="<?= e($p['name']) ?>"></label>
    <label>Own site host <span class="opt">(optional)</span> <input name="host" value="<?= e($p['host']) ?>" placeholder="taligaa.sham.et"<?= aria_error($errors, 'host') ?>></label>
    <label>Colour <input name="accent" value="<?= e($p['accent']) ?>" pattern="#[0-9A-Fa-f]{6}" maxlength="7"></label>
  </div>
  <?= field_error($errors, 'name') ?><?= field_error($errors, 'host') ?>
  <div class="row2">
    <label>Tagline <input name="tagline" maxlength="255" value="<?= e($p['tagline']) ?>"></label>
    <label>Field <span class="opt">(groups products: Media, Health, Business …)</span> <input name="category" maxlength="60" value="<?= e($p['category'] ?? '') ?>" list="cats"></label>
  </div>
  <datalist id="cats"><option value="Media"><option value="Health"><option value="Business"><option value="Education"><option value="Government"></datalist>
  <label>Summary (cards and search engines) <textarea name="summary" rows="3" maxlength="2000"><?= e($p['summary']) ?></textarea></label>
  <label>Page text (Markdown: ## headings, - lists, **bold**, [links](https://…)) <textarea name="body" rows="18" class="mono"><?= e($p['body']) ?></textarea></label>
  <label>Trial note <span class="opt">(optional)</span> <input name="trial_note" maxlength="255" value="<?= e($p['trial_note']) ?>"></label>
  <label>Regulatory note <span class="opt">(optional; for example registration and approval numbers, shown under the text)</span> <input name="regulatory_note" maxlength="500" value="<?= e($p['regulatory_note'] ?? '') ?>"></label>
  <?= \Sham\View::partial('admin/_image-picker', ['name' => 'logo_media_id', 'images' => $images ?? [], 'selected' => $p['logo_media_id'] ?? null, 'legend' => 'Logo on the home page']) ?>
  <div class="row3">
    <label>Licences <select name="licence_kind"<?= $owner ? '' : ' disabled title="Only the owner can change this"' ?>>
      <option value="mediaos"<?= $p['licence_kind'] === 'mediaos' ? ' selected' : '' ?>>Signed keys (Sham MediaOS)</option>
      <option value="manual"<?= $p['licence_kind'] !== 'mediaos' ? ' selected' : '' ?>>Sold by the team (enquiries)</option>
    </select></label>
    <label>Status <select name="status">
      <option value="published"<?= $p['status'] === 'published' ? ' selected' : '' ?>>Published</option>
      <option value="draft"<?= $p['status'] !== 'published' ? ' selected' : '' ?>>Draft</option>
    </select></label>
    <label>Order on pages <input type="number" name="sort" value="<?= (int) $p['sort'] ?>"></label>
  </div>
  <button class="btn" type="submit">Save</button>
</form>

<h2 id="subpages">Pages of this product</h2>
<p class="muted small">Extra pages on the product's site, such as Features, Pricing details, Case studies or Documentation. Pages ticked for the menu appear in its header.</p>
<?php if (($subpages ?? []) !== []): ?>
<div class="scroll"><table class="table compact"><thead><tr><th scope="col">Page</th><th scope="col">Address</th><th scope="col">Menu</th><th scope="col">Status</th></tr></thead><tbody>
<?php foreach ($subpages as $sp): ?><tr><td><a href="/admin/product-pages/<?= (int) $sp['id'] ?>"><?= e($sp['title']) ?></a></td><td class="mono small">/<?= e($sp['slug']) ?></td><td><?= (int) ($sp['in_nav'] ?? 0) === 1 ? 'yes' : '' ?></td><td><span class="status s-<?= e($sp['status']) ?>"><?= e($sp['status']) ?></span></td></tr><?php endforeach ?>
</tbody></table></div>
<?php endif ?>
<p><a class="btn small ghost" href="/admin/product-pages/new?product=<?= (int) $p['id'] ?>">New page</a> <a class="btn small ghost" href="/admin/posts/new">New post</a> <a class="btn small ghost" href="/admin/releases/new">New release</a></p>

<h2 id="editions">Editions and prices</h2>
<?php if (! $owner): ?><p class="muted small">Only the owner can change editions and prices.</p><?php endif ?>
<?php if ($editions === []): ?><p class="muted">No editions: the product is shown with a contact button only.</p><?php else: ?>
<form method="post" action="/admin/products/<?= (int) $p['id'] ?>/editions" class="form">
  <?= csrf_field() ?>
  <?php foreach ($editions as $ed): $n = 'ed['.(int) $ed['id'].']'; ?>
  <fieldset class="box">
    <legend><?= e($ed['label']) ?> <span class="muted mono small"><?= e($ed['ekey']) ?></span></legend>
    <div class="row3">
      <label>Label <input name="<?= $n ?>[label]" maxlength="80" value="<?= e($ed['label']) ?>"></label>
      <label>US$ per year <input type="number" name="<?= $n ?>[price]" min="0" value="<?= (int) $ed['price_usd_year'] ?>"></label>
      <label>Perpetual = years × <input type="number" name="<?= $n ?>[multiple]" min="1" max="10" value="<?= (int) $ed['perpetual_multiple'] ?>"></label>
    </div>
    <label>Description <input name="<?= $n ?>[blurb]" maxlength="255" value="<?= e($ed['blurb']) ?>"></label>
    <div class="row3">
      <label>Domains <input type="number" name="<?= $n ?>[domains]" min="1" max="100" value="<?= (int) $ed['max_domains'] ?>"></label>
      <label>Order <input type="number" name="<?= $n ?>[sort]" value="<?= (int) $ed['sort'] ?>"></label>
      <span>
        <label class="check"><input type="checkbox" name="<?= $n ?>[quote]" value="1"<?= (int) $ed['quote_only'] === 1 ? ' checked' : '' ?>> <span>On quotation only</span></label>
        <label class="check"><input type="checkbox" name="<?= $n ?>[active]" value="1"<?= (int) $ed['active'] === 1 ? ' checked' : '' ?>> <span>Shown</span></label>
      </span>
    </div>
    <?php if ($p['licence_kind'] === 'mediaos'): ?>
    <details>
      <summary>Limits and features written into the licence (JSON)</summary>
      <p class="small muted">These must match what Sham MediaOS understands (apps/api/config/licensing.php). null = unlimited.</p>
      <label>Limits <textarea class="mono" rows="2" name="<?= $n ?>[limits]"><?= e($ed['limits_json']) ?></textarea></label>
      <label>Features <textarea class="mono" rows="3" name="<?= $n ?>[features]"><?= e($ed['features_json']) ?></textarea></label>
    </details>
    <?php else: ?>
      <input type="hidden" name="<?= $n ?>[limits]" value="<?= e($ed['limits_json']) ?>"><input type="hidden" name="<?= $n ?>[features]" value="<?= e($ed['features_json']) ?>">
    <?php endif ?>
  </fieldset>
  <?php endforeach ?>
  <?php if ($owner): ?><button class="btn" type="submit">Save editions</button><?php endif ?>
</form>
<?php endif ?>
<?php if ($owner): ?>
<form method="post" action="/admin/products/<?= (int) $p['id'] ?>/edition-new" class="form inline">
  <?= csrf_field() ?>
  <label>New edition key <input name="ekey" pattern="[a-z0-9_]{2,40}" required placeholder="clinic_basic"></label>
  <button class="btn small ghost" type="submit">Add edition</button>
</form>
<?php endif ?>
