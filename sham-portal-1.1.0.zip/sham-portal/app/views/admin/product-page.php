<?php $d = $data; ?>
<p class="crumbs"><a href="/admin/products">Products</a> › <a href="/admin/products/<?= (int) $product['id'] ?>#subpages"><?= e($product['name']) ?></a></p>
<h1><?= e($pg === null ? 'New page for '.$product['name'] : $pg['title']) ?></h1>
<?php if ($url !== null && $pg['status'] === 'published'): ?><p>Live at <a href="<?= e($url) ?>"><?= e($url) ?></a></p><?php endif ?>
<form method="post" class="form wide-form" action="/admin/product-pages/<?= $pg === null ? 'new' : (int) $pg['id'] ?>" novalidate>
  <?= csrf_field() ?>
  <input type="hidden" name="product_id" value="<?= (int) $product['id'] ?>">
  <div class="row2">
    <label>Title <input name="title" maxlength="160" required value="<?= e($d['title']) ?>"<?= aria_error($errors, 'title') ?>></label>
    <label>Address <span class="opt">(empty = from the title)</span> <input name="slug" maxlength="80" class="mono" value="<?= e($d['slug']) ?>"<?= aria_error($errors, 'slug') ?>></label>
  </div>
  <?= field_error($errors, 'title') ?><?= field_error($errors, 'slug') ?>
  <label>Text (Markdown) <textarea name="body" rows="24" class="mono"><?= e($d['body']) ?></textarea></label>
  <div class="row3">
    <label>Status <select name="status"><option value="draft"<?= $d['status'] !== 'published' ? ' selected' : '' ?>>Draft</option><option value="published"<?= $d['status'] === 'published' ? ' selected' : '' ?>>Published</option></select></label>
    <label>Order in the menu <input type="number" name="sort" value="<?= (int) $d['sort'] ?>"></label>
    <label class="check"><input type="checkbox" name="in_nav" value="1"<?= (int) $d['in_nav'] === 1 ? ' checked' : '' ?>> <span>Show in the product's menu</span></label>
  </div>
  <p><button class="btn" type="submit">Save</button></p>
</form>
<?php if ($pg !== null): ?>
<form method="post" action="/admin/product-pages/<?= (int) $pg['id'] ?>/delete" class="form box danger-box" data-confirm="Delete this page?">
  <?= csrf_field() ?><p><button class="btn small danger" type="submit">Delete page</button></p>
</form>
<?php endif ?>
