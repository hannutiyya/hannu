<h1>Releases</h1>
<p class="muted">Each version you publish appears on the product's Releases page. Installations of Sham MediaOS ask the licence server every day whether there is a newer version, and customers download it from their account. Licensed downloads go only to licences with updates for that date.</p>
<p><a class="btn" href="/admin/releases/new">New release</a></p>
<div class="scroll"><table class="table">
  <thead><tr><th scope="col">Product</th><th scope="col">Version</th><th scope="col">Channel</th><th scope="col">Released</th><th scope="col">Access</th><th scope="col">File</th><th scope="col">Downloads</th><th scope="col">Status</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $rl): ?>
    <tr><td><?= e($rl['product_name']) ?></td><td><a href="/admin/releases/<?= (int) $rl['id'] ?>"><?= e($rl['version']) ?></a><?= (int) $rl['critical'] === 1 ? ' <span class="tag">security</span>' : '' ?></td>
      <td><?= e($rl['channel']) ?></td><td><?= e(date_human((string) $rl['released_at'])) ?></td><td><?= e($rl['access']) ?></td>
      <td><?= $rl['file_name'] !== null ? '<span class="mono small">'.e($rl['file_name']).'</span>' : ($rl['external_url'] !== null ? 'link' : '<span class="muted">none</span>') ?></td>
      <td><?= (int) $rl['downloads'] ?></td><td><span class="status s-<?= e($rl['status']) ?>"><?= e($rl['status']) ?></span></td></tr>
  <?php endforeach ?>
  <?php if ($rows === []): ?><tr><td colspan="8" class="muted">No releases yet.</td></tr><?php endif ?>
  </tbody>
</table></div>
