<h1>Enquiries</h1>
<p><?= $all ? '<a href="/admin/enquiries">Show new only</a>' : '<a href="/admin/enquiries?show=all">Show all, including handled</a>' ?></p>
<?php if ($rows === []): ?><p class="muted">Nothing <?= $all ? '' : 'new ' ?>here.</p><?php endif ?>
<?php foreach ($rows as $q): ?>
<article class="box enquiry">
  <header>
    <strong><?= e($q['name']) ?></strong> &lt;<a href="mailto:<?= e($q['email']) ?>?subject=<?= rawurlencode('Re: your message to Sham') ?>"><?= e($q['email']) ?></a>&gt;
    <?= $q['organisation'] !== '' ? ' · '.e($q['organisation']) : '' ?><?= $q['country'] ? ' · '.e($q['country']) : '' ?><?= $q['phone'] !== '' ? ' · '.e($q['phone']) : '' ?>
    <span class="muted small"> · <?= e($q['kind']) ?><?= $q['product_name'] ? ' · '.e($q['product_name']) : '' ?> · <?= e($q['created_at']) ?></span>
  </header>
  <p class="pre"><?= e($q['message']) ?></p>
  <form method="post" action="/admin/enquiries/<?= (int) $q['id'] ?>/<?= $q['status'] === 'new' ? 'handled' : 'new' ?>"><?= csrf_field() ?>
    <button class="btn small <?= $q['status'] === 'new' ? '' : 'ghost' ?>" type="submit"><?= $q['status'] === 'new' ? 'Mark handled' : 'Mark as new' ?></button></form>
</article>
<?php endforeach ?>
