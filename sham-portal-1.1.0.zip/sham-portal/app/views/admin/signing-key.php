<h1>Licence signing key</h1>
<p>Licences and check-in answers are signed with an Ed25519 private key. Sham MediaOS installations trust only the matching public key, so a licence cannot be forged without this key.</p>
<?php if ($available): ?>
  <p class="flash ok">A signing key is installed. Public key: <span class="mono"><?= e($public) ?></span>
  <?= in_array($public, $known, true) ? '— trusted by Sham MediaOS.' : '— <strong>not</strong> one of the keys Sham MediaOS trusts.' ?></p>
<?php else: ?>
  <p class="flash bad">No signing key yet. The store cannot issue licences and check-ins are refused until you import one.</p>
<?php endif ?>
<?php if ($error): ?><p class="flash bad" role="alert"><?= e($error) ?></p><?php endif ?>
<form method="post" class="form wide-form" autocomplete="off">
  <?= csrf_field() ?>
  <label>Private key file contents (PEM, begins with -----BEGIN PRIVATE KEY-----) <textarea name="pem" rows="5" class="mono" spellcheck="false" required></textarea></label>
  <?= \Sham\View::partial('admin/_code') ?>
  <button class="btn" type="submit"><?= $available ? 'Replace the key' : 'Import the key' ?></button>
</form>
<p class="small muted">The key is stored encrypted with this server's secret and is never shown again. Keep the original file offline (for example on a USB stick in a safe) as your backup. Trusted public keys: <span class="mono"><?= e(implode(', ', $known)) ?></span></p>
