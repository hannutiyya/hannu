<h1>Sign in</h1>
<?php if ($error): ?><p class="flash bad" role="alert"><?= e($error) ?></p><?php endif ?>
<form method="post" class="form">
  <?= csrf_field() ?>
  <label>E-mail <input type="email" name="email" required autocomplete="username" value="<?= e($email) ?>" autofocus></label>
  <label>Password <input type="password" name="password" required autocomplete="current-password"></label>
  <button class="btn" type="submit">Continue</button>
</form>
<p class="muted small">After your password you enter the code from your authenticator app.</p>
