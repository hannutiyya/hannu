<h1>Audit log</h1>
<p class="flash <?= $chain['ok'] ? 'ok' : 'bad' ?>"><?= $chain['ok'] ? 'The chain of '.(int) $chain['rows'].' entries is intact: no entry has been changed or removed.' : 'The chain is broken at entry '.(int) $chain['broken_at'].'. An entry was changed or deleted in the database.' ?></p>
<div class="scroll"><table class="table compact">
  <thead><tr><th scope="col">#</th><th scope="col">When (UTC)</th><th scope="col">Who</th><th scope="col">What</th><th scope="col">Subject</th><th scope="col">Details</th></tr></thead>
  <tbody><?php foreach ($rows as $a): ?>
    <tr><td><?= (int) $a['id'] ?></td><td><?= e($a['created_at']) ?></td><td><?= e($a['actor']) ?></td><td><?= e($a['action']) ?></td><td class="mono small"><?= e($a['subject']) ?></td><td class="mono small"><?= e(str_limit((string) $a['data'], 200)) ?></td></tr>
  <?php endforeach ?></tbody>
</table></div>
<p class="muted small">Showing the latest 300 entries.</p>
