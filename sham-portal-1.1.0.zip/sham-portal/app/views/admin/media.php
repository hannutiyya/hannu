<?php use Sham\Media; ?>
<h1>Media library</h1>
<p class="muted">Images (JPEG, PNG, WebP, GIF) are checked and saved again by the server, which removes anything hidden in them and the camera data. Documents (PDF, ZIP) are offered as downloads. Largest upload on this server: <?= e((string) $maxUpload) ?>.</p>
<form method="post" action="/admin/media" enctype="multipart/form-data" class="form box">
  <?= csrf_field() ?>
  <h2>Upload</h2>
  <div class="row2">
    <label>File <input type="file" name="file" required accept="image/jpeg,image/png,image/webp,image/gif,application/pdf,application/zip"></label>
    <label>Description <span class="opt">(read aloud to blind visitors)</span> <input name="alt" maxlength="255"></label>
  </div>
  <label class="check"><input type="checkbox" name="kind" value="file"> <span>A document (PDF or ZIP, up to 25 MB), not an image</span></label>
  <p><button class="btn" type="submit">Upload</button></p>
</form>
<div class="media-grid">
<?php foreach ($rows as $m): $u = Media::url($m); ?>
  <div class="media-card">
    <?php if ($m['kind'] === 'image'): ?><img src="<?= e($u) ?>" alt="<?= e($m['alt']) ?>" loading="lazy"><?php else: ?><span class="file"><?= e(strtoupper(pathinfo((string) $m['filename'], PATHINFO_EXTENSION))) ?></span><?php endif ?>
    <span class="mono small"><?= e($m['filename']) ?></span>
    <span class="muted small"><?= e(number_format((int) $m['bytes'] / 1024, 0)) ?> KB<?= $m['width'] !== null ? ' · '.(int) $m['width'].'×'.(int) $m['height'] : '' ?></span>
    <input readonly value="<?= e($m['kind'] === 'image' ? '!['.$m['alt'].']('.$u.')' : '['.$m['filename'].']('.$u.')') ?>" aria-label="Markdown to paste" id="md-<?= (int) $m['id'] ?>">
    <button class="btn small ghost" type="button" data-copy="md-<?= (int) $m['id'] ?>">Copy Markdown</button>
    <form method="post" action="/admin/media/<?= (int) $m['id'] ?>/alt" class="inline-actions">
      <?= csrf_field() ?><input name="alt" value="<?= e($m['alt']) ?>" maxlength="255" aria-label="Description"><button class="btn small ghost" type="submit">Save</button>
    </form>
    <form method="post" action="/admin/media/<?= (int) $m['id'] ?>/delete" data-confirm="Delete this file? Pages that show it will have a broken image.">
      <?= csrf_field() ?><button class="btn small danger" type="submit">Delete</button>
    </form>
  </div>
<?php endforeach ?>
</div>
<?php if ($rows === []): ?><p class="muted">Nothing uploaded yet.</p><?php endif ?>
