<h1>Subscribers</h1>
<p class="muted">People who asked for news by e-mail and confirmed their address. Send a post from its page (News and updates → the post → Send).</p>
<div class="stats">
  <span class="stat"><span><?= (int) ($stats['active'] ?? 0) ?></span>confirmed</span>
  <span class="stat"><span><?= (int) ($stats['pending'] ?? 0) ?></span>not confirmed yet</span>
  <span class="stat"><span><?= (int) ($stats['gone'] ?? 0) ?></span>unsubscribed</span>
  <span class="stat"><span><?= (int) ($queue['waiting'] ?? 0) ?></span>e-mails waiting to go</span>
  <span class="stat<?= (int) ($queue['failed'] ?? 0) > 0 ? ' warn' : '' ?>"><span><?= (int) ($queue['failed'] ?? 0) ?></span>e-mails that failed</span>
</div>
<p><a class="btn small ghost" href="/admin/subscribers/export">Download confirmed subscribers (CSV)</a></p>
<div class="scroll"><table class="table compact">
  <thead><tr><th scope="col">E-mail</th><th scope="col">Follows</th><th scope="col">Since</th><th scope="col">State</th><th scope="col"><span class="sr">Remove</span></th></tr></thead>
  <tbody><?php foreach ($rows as $s): $f = json_in((string) $s['products_json']); ?>
    <tr<?= $s['unsubscribed_at'] !== null ? ' class="off"' : '' ?>><td><?= e($s['email']) ?></td><td><?= $f === [] ? 'everything' : e(implode(', ', $f)) ?></td>
      <td><?= e(date_human((string) $s['created_at'])) ?></td>
      <td><?= $s['unsubscribed_at'] !== null ? 'unsubscribed' : ($s['confirmed_at'] !== null ? 'confirmed' : 'waiting for confirmation') ?></td>
      <td><form method="post" action="/admin/subscribers/<?= (int) $s['id'] ?>/remove" data-confirm="Remove this address and its history?"><?= csrf_field() ?><button class="btn small ghost" type="submit">Remove</button></form></td></tr>
  <?php endforeach ?>
  <?php if ($rows === []): ?><tr><td colspan="5" class="muted">No subscribers yet.</td></tr><?php endif ?>
  </tbody>
</table></div>
