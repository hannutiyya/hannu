<?php use Sham\Content; ?>
<h1>News and updates</h1>
<p class="muted">Posts appear on sham.et/news, on the product's own site when a product is chosen, in the RSS feeds and, when you press Send, in subscribers' inboxes.</p>
<p><a class="btn" href="/admin/posts/new">New post</a></p>
<form method="get" class="filters">
  <label>Product <select name="product"><option value="">All</option><?php foreach ($products as $p): ?><option value="<?= (int) $p['id'] ?>"<?= $filter['product'] === (string) $p['id'] ? ' selected' : '' ?>><?= e($p['name']) ?></option><?php endforeach ?></select></label>
  <label>Status <select name="status"><option value="">All</option><option value="published"<?= $filter['status'] === 'published' ? ' selected' : '' ?>>Published</option><option value="draft"<?= $filter['status'] === 'draft' ? ' selected' : '' ?>>Draft</option></select></label>
  <button class="btn small ghost" type="submit">Show</button>
</form>
<div class="scroll"><table class="table">
  <thead><tr><th scope="col">Title</th><th scope="col">Kind</th><th scope="col">Product</th><th scope="col">Published</th><th scope="col">Status</th><th scope="col">E-mailed</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $pst): $future = $pst['status'] === 'published' && $pst['published_at'] !== null && strtotime($pst['published_at'].' UTC') > time(); ?>
    <tr><td><a href="/admin/posts/<?= (int) $pst['id'] ?>"><?= e($pst['title']) ?></a><br><span class="muted small mono">/news/<?= e($pst['slug']) ?></span></td>
      <td><?= e(Content::POST_KINDS[$pst['kind']] ?? $pst['kind']) ?></td><td><?= e($pst['product_name'] ?? 'Company') ?></td>
      <td><?= $pst['published_at'] !== null ? e(date_human((string) $pst['published_at'])) : '—' ?></td>
      <td><span class="status s-<?= e($pst['status']) ?>"><?= $future ? 'scheduled' : e($pst['status']) ?></span></td>
      <td><?= $pst['mailed_at'] !== null ? e(date_human((string) $pst['mailed_at'])) : '—' ?></td></tr>
  <?php endforeach ?>
  <?php if ($rows === []): ?><tr><td colspan="6" class="muted">No posts yet.</td></tr><?php endif ?>
  </tbody>
</table></div>
