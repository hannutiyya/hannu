<?php
use Sham\Config;

$me = $me ?? null;
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/admin', PHP_URL_PATH) ?: '/admin';
// Grouped; each link shows only to the roles that may open it (Admin::AREAS).
$groups = [
    '' => [['/admin', 'Overview']],
    'Sales' => [['/admin/orders', 'Orders'], ['/admin/licences', 'Licences'], ['/admin/enquiries', 'Enquiries']],
    'Website' => [['/admin/posts', 'News and updates'], ['/admin/products', 'Products'], ['/admin/pages', 'Pages'], ['/admin/media', 'Media library'],
        ['/admin/releases', 'Releases'], ['/admin/subscribers', 'Subscribers']],
    'Control' => [['/admin/settings', 'Settings'], ['/admin/signing-key', 'Signing key'], ['/admin/admins', 'Admins'], ['/admin/system', 'System'], ['/admin/audit', 'Audit log']],
];
$can = fn (string $href): bool => \Sham\Controllers\Admin::can(is_array($me) ? $me : null, explode('/', trim(substr($href, 6), '/'))[0] ?? '');
$active = fn (string $href): bool => $href === '/admin' ? $path === '/admin' : str_starts_with($path, $href);
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e($title ?? 'Admin') ?> · Sham admin</title>
<link rel="stylesheet" href="/assets/admin.css?v=<?= e(SHAM_VERSION) ?>">
<link rel="icon" href="/assets/icon.svg" type="image/svg+xml">
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<div class="shell">
  <aside class="side">
    <p class="side-brand"><span class="mark" aria-hidden="true"></span> Sham admin</p>
    <nav aria-label="Admin">
      <?php foreach ($groups as $group => $links): $links = array_filter($links, fn ($l) => $can($l[0])); if ($links === []) { continue; } ?>
      <?php if ($group !== ''): ?><p class="side-group"><?= e($group) ?></p><?php endif ?>
      <ul>
      <?php foreach ($links as [$href, $label]): ?>
        <li><a href="<?= e($href) ?>"<?= $active($href) ? ' aria-current="page"' : '' ?>><?= e($label) ?></a></li>
      <?php endforeach ?>
      </ul>
      <?php endforeach ?>
    </nav>
    <?php if (is_array($me)): ?>
    <div class="side-me">
      <p><?= e($me['name']) ?><br><span class="muted small"><?= e($me['email']) ?> · <?= e($me['role']) ?></span></p>
      <p><a href="/admin/account">Your account</a></p>
      <form method="post" action="/admin/logout"><?= csrf_field() ?><button class="link" type="submit">Sign out</button></form>
    </div>
    <?php endif ?>
    <p class="side-sites small"><a href="<?= e(Config::url('company')) ?>">sham.et</a> · <a href="/">Store</a> · v<?= e(SHAM_VERSION) ?></p>
  </aside>
  <main class="main" id="main">
    <?php foreach (($flash ?? []) as $f): ?><div class="flash <?= e($f['kind'] ?? 'ok') ?>" role="status"><?= e($f['msg'] ?? '') ?></div><?php endforeach ?>
    <?= $content ?>
  </main>
</div>
<script src="/assets/admin.js?v=<?= e(SHAM_VERSION) ?>" nonce="<?= e($nonce) ?>" defer></script>
</body>
</html>
