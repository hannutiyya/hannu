<?php use Sham\Config; ?>
<h1>Products</h1>
<div class="scroll"><table class="table">
  <thead><tr><th scope="col">Product</th><th scope="col">Site</th><th scope="col">Licences</th><th scope="col">Status</th></tr></thead>
  <tbody><?php foreach ($rows as $p): ?>
    <tr><td><a href="/admin/products/<?= (int) $p['id'] ?>"><?= e($p['name']) ?></a> <span class="muted small"><?= e($p['slug']) ?></span></td>
      <td><?= $p['host'] ? '<a href="'.e(Config::get('scheme', 'https').'://'.$p['host'].'/').'">'.e($p['host']).'</a>' : '<span class="muted">none</span>' ?></td>
      <td><?= $p['licence_kind'] === 'mediaos' ? 'Signed keys' : 'Sold by the team' ?></td>
      <td><span class="status s-<?= e($p['status']) ?>"><?= e($p['status']) ?></span></td></tr>
  <?php endforeach ?></tbody>
</table></div>
<form method="post" class="form box">
  <?= csrf_field() ?>
  <h2>New product</h2>
  <div class="row2">
    <label>Short name for addresses <input name="slug" pattern="[a-z0-9-]{2,40}" required placeholder="taligaa-clinic"></label>
    <label>Name <input name="name" required maxlength="120"></label>
  </div>
  <button class="btn" type="submit">Create as draft</button>
</form>
<p class="muted small">A product's own site (such as taligaa.sham.et) works once you give it a host name here and point that subdomain at the same folder in your hosting panel.</p>
