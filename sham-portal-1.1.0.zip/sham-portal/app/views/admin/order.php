<?php $st = (string) $o['status']; ?>
<p class="crumbs"><a href="/admin/orders">Orders</a></p>
<h1>Order <span class="mono"><?= e($o['id']) ?></span> <span class="status s-<?= e($st) ?>"><?= e($st) ?></span><?= (int) $o['test_mode'] === 1 ? ' <span class="tag">test</span>' : '' ?></h1>
<div class="grid2">
  <dl class="facts">
    <dt>Buyer</dt><dd><?= e($o['customer_name']) ?><br><a href="mailto:<?= e($o['customer_email']) ?>"><?= e($o['customer_email']) ?></a><?= $o['customer_country'] ? ' · '.e($o['customer_country']) : '' ?><?= $o['company_tax_id'] ? '<br>TIN/VAT '.e($o['company_tax_id']) : '' ?></dd>
    <dt>Product</dt><dd><?= e($o['product_name']) ?> <?= e($o['edition']) ?>, <?= e($o['term']) ?></dd>
    <dt>Domains</dt><dd><?= e(implode(', ', json_in((string) $o['domains_json']))) ?></dd>
    <dt>Amount</dt><dd><?= e(money((int) $o['net_minor'], (string) $o['currency'])) ?> + VAT <?= e(money((int) $o['vat_minor'], (string) $o['currency'])) ?> = <strong><?= e(money((int) $o['total_minor'], (string) $o['currency'])) ?></strong></dd>
    <dt>Method</dt><dd><?= e($o['provider']) ?><?= $o['provider_session'] ? '<br><span class="mono small">'.e($o['provider_session']).'</span>' : '' ?></dd>
    <dt>Bank / payment reference</dt><dd class="mono"><?= e(strtoupper(substr((string) $o['ref'], 0, 12))) ?><?= $o['provider_reference'] ? ' · '.e($o['provider_reference']) : '' ?></dd>
    <?php if ($o['renews_licence_id']): ?><dt>Renews</dt><dd><a class="mono" href="/admin/licences/<?= e($o['renews_licence_id']) ?>"><?= e($o['renews_licence_id']) ?></a></dd><?php endif ?>
    <?php if ($o['licence_id']): ?><dt>Licence</dt><dd><a class="mono" href="/admin/licences/<?= e($o['licence_id']) ?>"><?= e($o['licence_id']) ?></a></dd><?php endif ?>
    <?php if ($o['receipt_number']): ?><dt>Receipt</dt><dd><a href="/order/<?= e($o['ref']) ?>/receipt"><?= e($o['receipt_number']) ?></a></dd><?php endif ?>
    <?php if ($o['failure_reason']): ?><dt>Note</dt><dd><?= e($o['failure_reason']) ?></dd><?php endif ?>
    <dt>Placed</dt><dd><?= e($o['created_at']) ?> UTC</dd>
    <dt>Paid</dt><dd><?= e($o['paid_at'] ?? '—') ?></dd>
    <dt>Customer page</dt><dd><a href="/order/<?= e($o['ref']) ?>">Open the order page</a></dd>
  </dl>
  <div class="actions-col">
    <?php if (in_array($st, ['pending', 'review', 'paid', 'fulfilled'], true) && $o['provider'] !== 'bank'): ?>
    <form method="post" action="/admin/orders/<?= e($o['id']) ?>/refresh"><?= csrf_field() ?><button class="btn" type="submit">Check with the provider (<?= e($o['provider']) ?>)</button></form>
    <?php endif ?>
    <?php if (in_array($st, ['pending', 'failed', 'cancelled', 'review'], true)): ?>
    <form method="post" action="/admin/orders/<?= e($o['id']) ?>/mark-paid" class="form box">
      <?= csrf_field() ?>
      <h2>Mark as paid</h2>
      <p class="small">Only after you have seen the money in the account. The licence is issued and e-mailed at once.</p>
      <label>Bank or payment reference <input name="reference" required maxlength="120"></label>
      <?= \Sham\View::partial('admin/_code') ?>
      <button class="btn" type="submit">Mark paid and issue the licence</button>
    </form>
    <?php endif ?>
    <?php if ($st === 'fulfilled'): ?>
    <form method="post" action="/admin/orders/<?= e($o['id']) ?>/resend"><?= csrf_field() ?><button class="btn ghost" type="submit">E-mail the licence again</button></form>
    <?php endif ?>
    <?php if ($st === 'pending'): ?>
    <form method="post" action="/admin/orders/<?= e($o['id']) ?>/cancel" data-confirm="Cancel this order?"><?= csrf_field() ?><button class="btn danger" type="submit">Cancel the order</button></form>
    <?php endif ?>
    <p class="small muted">Refunds are made in the payment provider's own dashboard. Afterwards press "Check with the provider": when it reports the refund, the order is marked refunded and the licence revoked. If it does not, or for bank transfers, revoke the licence by hand.</p>
  </div>
</div>
<h2>Payment events</h2>
<?php if ($events === []): ?><p class="muted">None.</p><?php else: ?>
<div class="scroll"><table class="table compact">
  <thead><tr><th scope="col">When</th><th scope="col">Provider</th><th scope="col">Type</th><th scope="col">Outcome</th><th scope="col">Detail</th></tr></thead>
  <tbody><?php foreach ($events as $ev): ?><tr><td><?= e($ev['created_at']) ?></td><td><?= e($ev['provider']) ?></td><td><?= e($ev['type']) ?></td><td><?= e($ev['outcome']) ?></td><td><?= e($ev['detail']) ?></td></tr><?php endforeach ?></tbody>
</table></div>
<?php endif ?>
