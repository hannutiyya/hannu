<h1>Overview</h1>
<?php foreach ($alerts as [$kind, $msg, $href]): ?>
  <p class="flash <?= e($kind) ?>"><?= e($msg) ?> <a href="<?= e($href) ?>">Fix this</a></p>
<?php endforeach ?>
<?php if ($stats !== null): ?>
<div class="stats">
  <a class="stat" href="/admin/orders?status=pending"><span><?= (int) $stats['pending'] ?></span>orders waiting for payment</a>
  <a class="stat<?= $stats['bank'] > 0 ? ' hot' : '' ?>" href="/admin/orders?status=pending"><span><?= (int) $stats['bank'] ?></span>bank transfers to confirm</a>
  <a class="stat<?= $stats['review'] > 0 ? ' hot' : '' ?>" href="/admin/orders?status=review"><span><?= (int) $stats['review'] ?></span>payments to review</a>
  <a class="stat" href="/admin/licences"><span><?= (int) $stats['licences'] ?></span>active licences</a>
  <a class="stat" href="/admin/licences"><span><?= (int) $stats['expiring'] ?></span>expiring in 30 days</a>
  <a class="stat<?= $stats['silent'] > 0 ? ' warn' : '' ?>" href="/admin/licences"><span><?= (int) $stats['silent'] ?></span>silent for 7+ days</a>
  <a class="stat<?= $stats['enquiries'] > 0 ? ' hot' : '' ?>" href="/admin/enquiries"><span><?= (int) $stats['enquiries'] ?></span>new enquiries</a>
</div>
<?php endif ?>
<div class="stats">
  <a class="stat" href="/admin/posts?status=published"><span><?= (int) $cstats['posts'] ?></span>published posts</a>
  <a class="stat" href="/admin/posts?status=draft"><span><?= (int) $cstats['drafts'] ?></span>drafts</a>
  <a class="stat" href="/admin/subscribers"><span><?= (int) $cstats['subscribers'] ?></span>subscribers</a>
  <a class="stat" href="/admin/releases"><span><?= (int) $cstats['releases'] ?></span>published releases</a>
</div>
<?php if ($stats === null): ?>
<p><a class="btn" href="/admin/posts/new">Write a post</a> <a class="btn ghost" href="/admin/media">Media library</a></p>
<h2>Latest edits</h2>
<ul class="plain"><?php foreach ($latestPosts as $lp): ?><li><a href="/admin/posts/<?= (int) $lp['id'] ?>"><?= e($lp['title']) ?></a> <span class="muted small"><?= e($lp['status']) ?>, <?= e(date_human((string) $lp['updated_at'])) ?></span></li><?php endforeach ?></ul>
<?php return; endif ?>
<h2>Paid this month</h2>
<?php if ($revenue === []): ?><p class="muted">Nothing yet.</p><?php else: ?>
<ul class="plain"><?php foreach ($revenue as $rv): ?><li><strong><?= e(money((int) $rv['total'], (string) $rv['currency'])) ?></strong> from <?= (int) $rv['n'] ?> order<?= (int) $rv['n'] === 1 ? '' : 's' ?></li><?php endforeach ?></ul>
<?php endif ?>
<h2>Latest orders</h2>
<?= \Sham\View::partial('admin/_orders', ['rows' => $recent]) ?>
