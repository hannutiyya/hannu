<?php
use Sham\Content;
use Sham\View;

$d = $data;
$when = $d['published_at'] !== null ? str_replace(' ', 'T', substr((string) $d['published_at'], 0, 16)) : '';
?>
<p class="crumbs"><a href="/admin/posts">News and updates</a></p>
<h1><?= e($post === null ? 'New post' : $post['title']) ?></h1>
<?php if ($post !== null && $live && $url !== null): ?><p>Live at <a href="<?= e($url) ?>"><?= e($url) ?></a></p><?php endif ?>
<form method="post" class="form wide-form" action="/admin/posts/<?= $post === null ? 'new' : (int) $post['id'] ?>" novalidate>
  <?= csrf_field() ?>
  <label>Title <input name="title" maxlength="200" required value="<?= e($d['title']) ?>"<?= aria_error($errors, 'title') ?>></label>
  <?= field_error($errors, 'title') ?>
  <div class="row3">
    <label>Address <span class="opt">(empty = from the title)</span> <input name="slug" maxlength="100" value="<?= e($d['slug']) ?>" class="mono"<?= aria_error($errors, 'slug') ?>></label>
    <label>Kind <select name="kind"><?php foreach (Content::POST_KINDS as $k => $label): ?><option value="<?= e($k) ?>"<?= $d['kind'] === $k ? ' selected' : '' ?>><?= e($label) ?></option><?php endforeach ?></select></label>
    <label>About <select name="product_id"><option value="">The company (sham.et only)</option><?php foreach ($products as $p): ?><option value="<?= (int) $p['id'] ?>"<?= (int) $d['product_id'] === (int) $p['id'] ? ' selected' : '' ?>><?= e($p['name']) ?></option><?php endforeach ?></select></label>
  </div>
  <?= field_error($errors, 'slug') ?>
  <label>Summary <span class="opt">(lists, feeds, e-mails and search engines)</span> <textarea name="summary" rows="2" maxlength="500"><?= e($d['summary']) ?></textarea></label>
  <label>Text (Markdown: ## headings, - lists, **bold**, [links](https://…), ![image](/media/…)) <textarea name="body" rows="22" class="mono"><?= e($d['body']) ?></textarea></label>
  <?= View::partial('admin/_image-picker', ['name' => 'cover_media_id', 'images' => $images, 'selected' => $d['cover_media_id'], 'legend' => 'Cover image']) ?>
  <div class="row3">
    <label>Status <select name="status"><option value="draft"<?= $d['status'] !== 'published' ? ' selected' : '' ?>>Draft</option><option value="published"<?= $d['status'] === 'published' ? ' selected' : '' ?>>Published</option></select></label>
    <label>Publish at (UTC) <span class="opt">(empty = now; later = scheduled)</span> <input type="datetime-local" name="published_at" value="<?= e($when) ?>"></label>
  </div>
  <p><button class="btn" type="submit">Save</button></p>
</form>
<?php if ($post !== null): ?>
<div class="row2">
  <form method="post" action="/admin/posts/<?= (int) $post['id'] ?>/mail" class="form box" data-confirm="Send this post to the subscribers now?">
    <?= csrf_field() ?>
    <h2>Send by e-mail</h2>
    <p class="small muted"><?= (int) $subscribers ?> confirmed subscriber<?= $subscribers === 1 ? '' : 's' ?>. Those who follow only other products are left out. Sent in batches by the scheduled work.</p>
    <?php if ($post['mailed_at'] !== null): ?><p class="small">Sent on <?= e(date_human((string) $post['mailed_at'])) ?>.</p>
    <label class="check"><input type="checkbox" name="again" value="1"> <span>Send again</span></label><?php endif ?>
    <p><button class="btn small" type="submit"<?= $live ? '' : ' disabled' ?>>Send to subscribers</button></p>
    <?php if (! $live): ?><p class="small muted">Publish the post first.</p><?php endif ?>
  </form>
  <form method="post" action="/admin/posts/<?= (int) $post['id'] ?>/delete" class="form box danger-box" data-confirm="Delete this post for good?">
    <?= csrf_field() ?>
    <h2>Delete</h2>
    <p class="small muted">Removes the post from the site and the feeds. E-mails already sent stay sent.</p>
    <p><button class="btn small danger" type="submit">Delete post</button></p>
  </form>
</div>
<?php endif ?>
