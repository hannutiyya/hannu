<h1>Admins</h1>
<p class="muted">Owner: everything. Sales: orders, licences and enquiries. Editor: news, pages, products, the media library and releases. Every change here needs a fresh authenticator code.</p>
<div class="scroll"><table class="table">
  <thead><tr><th scope="col">Name</th><th scope="col">Role</th><th scope="col">Two-step</th><th scope="col">Last sign-in</th><th scope="col">Change (needs a fresh code)</th></tr></thead>
  <tbody><?php foreach ($rows as $a): ?>
    <tr<?= (int) $a['active'] === 1 ? '' : ' class="off"' ?>>
      <td><?= e($a['name']) ?><br><span class="muted small"><?= e($a['email']) ?></span><?= (int) $a['active'] === 1 ? '' : ' <span class="tag">deactivated</span>' ?></td>
      <td><?php if ((int) $a['id'] !== (int) $me['id']): ?>
        <form method="post" action="/admin/admins/<?= (int) $a['id'] ?>/role" class="inline-actions">
          <?= csrf_field() ?>
          <select name="role" aria-label="Role for <?= e($a['name']) ?>"><?php foreach (\Sham\Controllers\Admin::ROLES as $k => $label): ?><option value="<?= e($k) ?>"<?= $a['role'] === $k ? ' selected' : '' ?>><?= e(ucfirst($k)) ?></option><?php endforeach ?></select>
          <input name="confirm_code" inputmode="numeric" maxlength="6" placeholder="code" aria-label="Authenticator code" required>
          <button class="btn small ghost" type="submit">Change</button>
        </form>
      <?php else: ?><?= e($a['role']) ?><?php endif ?></td><td><?= (int) $a['has_2fa'] === 1 ? 'on' : 'at first sign-in' ?></td><td><?= e($a['last_login_at'] ?? 'never') ?></td>
      <td><?php if ((int) $a['id'] !== (int) $me['id']): ?>
        <form method="post" class="inline-actions" action="" data-admin-action="<?= (int) $a['id'] ?>">
          <?= csrf_field() ?>
          <input name="confirm_code" inputmode="numeric" maxlength="6" placeholder="code" aria-label="Authenticator code" required>
          <?php if ((int) $a['active'] === 1): ?><button class="btn small danger" formaction="/admin/admins/<?= (int) $a['id'] ?>/deactivate">Deactivate</button>
          <?php else: ?><button class="btn small" formaction="/admin/admins/<?= (int) $a['id'] ?>/activate">Activate</button><?php endif ?>
          <button class="btn small ghost" formaction="/admin/admins/<?= (int) $a['id'] ?>/reset-2fa">Reset two-step</button>
        </form>
      <?php else: ?><span class="muted small">you</span><?php endif ?></td>
    </tr>
  <?php endforeach ?></tbody>
</table></div>
<form method="post" class="form box" autocomplete="off">
  <?= csrf_field() ?>
  <h2>Add an admin</h2>
  <div class="row2">
    <label>Name <input name="name" required maxlength="120"></label>
    <label>E-mail <input type="email" name="email" required maxlength="190"></label>
  </div>
  <div class="row2">
    <label>First password (give it to them in person) <input type="password" name="password" required autocomplete="new-password" minlength="12"></label>
    <label>Role <select name="role"><?php foreach (\Sham\Controllers\Admin::ROLES as $k => $label): ?><option value="<?= e($k) ?>"<?= $k === 'staff' ? ' selected' : '' ?>><?= e($label) ?></option><?php endforeach ?></select></label>
  </div>
  <?= \Sham\View::partial('admin/_code') ?>
  <button class="btn" type="submit">Add</button>
</form>
