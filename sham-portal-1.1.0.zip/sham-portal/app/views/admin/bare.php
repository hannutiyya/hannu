<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e($title ?? 'Admin') ?> · Sham admin</title>
<link rel="stylesheet" href="/assets/admin.css?v=<?= e(SHAM_VERSION) ?>">
<link rel="icon" href="/assets/icon.svg" type="image/svg+xml">
</head>
<body class="bare">
<main class="bare-box">
  <p class="bare-brand"><span class="mark" aria-hidden="true"></span> Sham admin</p>
  <?= $content ?>
</main>
</body>
</html>
