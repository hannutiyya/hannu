<h1>Your account</h1>
<?php if ($error): ?><p class="flash bad" role="alert"><?= e($error) ?></p><?php endif ?>
<form method="post" class="form">
  <?= csrf_field() ?>
  <h2>Change your password</h2>
  <label>Current password <input type="password" name="current_password" required autocomplete="current-password"></label>
  <label>New password (12 characters or more) <input type="password" name="new_password" required autocomplete="new-password" minlength="12"></label>
  <label>New password again <input type="password" name="new_password2" required autocomplete="new-password" minlength="12"></label>
  <button class="btn" type="submit">Change password</button>
</form>
<p class="muted small">Lost your authenticator? Another owner can reset your two-step sign-in under Admins. You set it up again at your next sign-in.</p>
