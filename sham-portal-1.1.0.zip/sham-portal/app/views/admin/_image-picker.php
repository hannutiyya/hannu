<?php
// $name, $images, $selected (id or null), $legend
use Sham\Media;
?>
<fieldset>
  <legend><?= e($legend) ?> <span class="opt">(from the <a href="/admin/media">media library</a>)</span></legend>
  <div class="picker">
    <label><input type="radio" name="<?= e($name) ?>" value=""<?= $selected === null ? ' checked' : '' ?>> <span>None</span></label>
    <?php foreach ($images as $im): ?>
    <label><input type="radio" name="<?= e($name) ?>" value="<?= (int) $im['id'] ?>"<?= (int) $selected === (int) $im['id'] ? ' checked' : '' ?>>
      <img src="<?= e(Media::url($im)) ?>" alt="" loading="lazy"><span><?= e(str_limit((string) ($im['alt'] !== '' ? $im['alt'] : $im['filename']), 40)) ?></span></label>
    <?php endforeach ?>
  </div>
</fieldset>
