<?php use Sham\View; ?>
<h1>System</h1>
<div class="stats">
  <span class="stat"><span><?= e($version) ?></span>portal version</span>
  <span class="stat"><span><?= e($php) ?></span>PHP</span>
  <span class="stat"><span><?= e(preg_replace('/-.*$/', '', $mysql)) ?></span><?= stripos($mysql, 'mariadb') !== false ? 'MariaDB' : 'MySQL' ?></span>
  <span class="stat<?= $pending !== [] ? ' hot' : '' ?>"><span><?= count($applied) ?>/<?= count($available) ?></span>database upgrades applied</span>
  <span class="stat<?= time() - $cronLast > 3600 ? ' warn' : '' ?>"><span><?= $cronLast > 0 ? e((string) max(0, intdiv(time() - $cronLast, 60))).' min' : 'never' ?></span>since scheduled work ran<?= $cronVia !== '' ? ' ('.e($cronVia).')' : '' ?></span>
  <?php if ($diskFree !== null): ?><span class="stat"><span><?= e(number_format($diskFree / 1073741824, 1)) ?> GB</span>free disk</span><?php endif ?>
</div>

<h2>Health</h2>
<ul class="checks">
<?php foreach ($checks as [$label, $ok, $detail]): ?>
  <li><span class="<?= $ok ? 'ok' : 'no' ?>" aria-hidden="true"><?= $ok ? '✓' : '✗' ?></span> <span><?= e($label) ?> <span class="muted small"><?= e($detail) ?></span><?= $ok ? '' : ' <span class="sr">(needs attention)</span>' ?></span></li>
<?php endforeach ?>
</ul>

<div class="row2">
  <form method="post" action="/admin/system/migrate" class="form box">
    <?= csrf_field() ?>
    <h2>Database upgrades</h2>
    <p class="small muted">New versions bring their database changes with them; they are applied by themselves on the first page after an update. Applied: <?= e(implode(', ', $applied)) ?>.<?= $pending !== [] ? ' Waiting: '.e(implode(', ', $pending)).'.' : '' ?></p>
    <p><button class="btn small<?= $pending === [] ? ' ghost' : '' ?>" type="submit">Apply now</button></p>
  </form>
  <form method="post" action="/admin/system/cron" class="form box">
    <?= csrf_field() ?>
    <h2>Scheduled work</h2>
    <p class="small muted">Every 10 minutes: checks pending payments, closes unpaid orders, sends expiry reminders and news e-mails (<?= (int) ($queue['waiting'] ?? 0) ?> waiting), and tidies up. It runs by itself while people visit the site; a cron job (php app/cron.php) makes it regular.</p>
    <p><button class="btn small ghost" type="submit">Run now</button></p>
  </form>
</div>

<div class="row2">
  <form method="post" action="/admin/system/backup" class="form box">
    <?= csrf_field() ?>
    <h2>Database backup</h2>
    <p class="small muted">Downloads the whole database as a compressed SQL file. Payment keys and the signing key inside it stay encrypted with the key in app/config.php: keep a copy of config.php somewhere safe as well, or the backup cannot be read. Restore with phpMyAdmin → Import into an empty database.</p>
    <?= View::partial('admin/_code') ?>
    <p><button class="btn small" type="submit">Download backup</button></p>
  </form>
  <form method="post" action="/admin/system/update" enctype="multipart/form-data" class="form box" data-confirm="Update the portal with this package? A copy of the current code is kept.">
    <?= csrf_field() ?>
    <h2>Update the portal</h2>
    <?php if (! $zip): ?><p class="flash bad">This server's PHP has no zip extension. Turn it on in the hosting panel, or upload the new files with the file manager.</p><?php endif ?>
    <p class="small muted">Upload the new sham-portal-x.y.z.zip exactly as published. Only app/ and public/ files are copied; app/config.php, the storage folder and your uploads are never touched. The current code is kept to go back to. Largest upload: <?= e((string) $maxUpload) ?>.</p>
    <label>Package <input type="file" name="package" accept=".zip,application/zip" required></label>
    <label class="check"><input type="checkbox" name="downgrade" value="1"> <span>Allow an older version</span></label>
    <?= View::partial('admin/_code') ?>
    <p><button class="btn small" type="submit"<?= $zip ? '' : ' disabled' ?>>Upload and update</button></p>
  </form>
</div>

<?php if ($backups !== []): ?>
<h2>Previous code</h2>
<p class="small muted">Made before each update (the five newest are kept). Going back does not undo database upgrades; they only ever add, so older code keeps working.</p>
<div class="scroll"><table class="table compact">
  <thead><tr><th scope="col">Copy</th><th scope="col">Made</th><th scope="col">Size</th><th scope="col">Go back</th></tr></thead>
  <tbody><?php foreach ($backups as $b): ?>
    <tr><td class="mono"><?= e($b['name']) ?></td><td><?= e(gmdate('Y-m-d H:i', $b['at'])) ?> UTC</td><td><?= e(number_format($b['bytes'] / 1048576, 1)) ?> MB</td>
      <td><form method="post" action="/admin/system/rollback" class="inline-actions" data-confirm="Put this code back?"><?= csrf_field() ?>
        <input type="hidden" name="backup" value="<?= e($b['name']) ?>"><input name="confirm_code" inputmode="numeric" maxlength="6" placeholder="code" aria-label="Authenticator code" required>
        <button class="btn small ghost" type="submit">Restore</button></form></td></tr>
  <?php endforeach ?></tbody>
</table></div>
<?php endif ?>

<h2>Where things are</h2>
<dl class="facts">
  <dt>Application</dt><dd class="mono"><?= e($appDir) ?></dd>
  <dt>Public files</dt><dd class="mono"><?= e($publicDir) ?></dd>
  <dt>Uploads and releases</dt><dd class="mono"><?= e($appDir) ?>/storage</dd>
</dl>

<h2>Database tables</h2>
<div class="scroll"><table class="table compact">
  <thead><tr><th scope="col">Table</th><th scope="col">Rows (about)</th><th scope="col">Size</th></tr></thead>
  <tbody><?php foreach ($tables as $t): ?><tr><td class="mono"><?= e($t['name']) ?></td><td><?= (int) $t['est_rows'] ?></td><td><?= e(number_format((int) $t['bytes'] / 1024, 0)) ?> KB</td></tr><?php endforeach ?></tbody>
</table></div>

<h2>Latest PHP errors</h2>
<?php if ($errors === []): ?><p class="muted">None logged.</p><?php else: ?><pre class="log"><?= e(implode("\n", $errors)) ?></pre><?php endif ?>
