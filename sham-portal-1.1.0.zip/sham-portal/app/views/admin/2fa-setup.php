<?php if (is_array($codes)): ?>
<h1>Two-step sign-in is on</h1>
<p>Save these recovery codes somewhere safe, away from your phone (printed, or in a password manager). Each one signs you in once if you lose your phone. They are shown only now.</p>
<ol class="codes mono"><?php foreach ($codes as $c): ?><li><?= e($c) ?></li><?php endforeach ?></ol>
<p><button class="btn ghost" type="button" data-print>Print</button> <a class="btn" href="/admin">I have saved them, continue</a></p>
<?php else: ?>
<h1>Set up two-step sign-in</h1>
<p>Every admin signs in with a password and a code from an authenticator app (Google Authenticator, Microsoft Authenticator, 1Password, Aegis…).</p>
<ol>
  <li>In the app, add an account and scan this code, or choose "enter a setup key" and type the key below.</li>
  <li>Enter the 6-digit code the app shows.</li>
</ol>
<div class="qr" data-qr="<?= e($uri) ?>" aria-hidden="true"></div>
<p>Setup key: <strong class="mono key-inline"><?= e(trim(chunk_split($secret, 4, ' '))) ?></strong><br><span class="muted small">Type: time-based, 6 digits, 30 seconds.</span></p>
<?php if ($error): ?><p class="flash bad" role="alert"><?= e($error) ?></p><?php endif ?>
<form method="post" class="form">
  <?= csrf_field() ?>
  <label>Code from the app <input name="code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required autofocus></label>
  <button class="btn" type="submit">Turn on</button>
</form>
<?php endif ?>
<script src="/assets/admin.js?v=<?= e(SHAM_VERSION) ?>" nonce="<?= e($nonce) ?>" defer></script>
