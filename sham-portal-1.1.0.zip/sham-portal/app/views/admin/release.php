<?php
$d = $data;
$when = str_replace(' ', 'T', substr((string) $d['released_at'], 0, 16));
?>
<p class="crumbs"><a href="/admin/releases">Releases</a></p>
<h1><?= e($rel === null ? 'New release' : 'Release '.$rel['version']) ?></h1>
<form method="post" class="form wide-form" action="/admin/releases/<?= $rel === null ? 'new' : (int) $rel['id'] ?>" novalidate>
  <?= csrf_field() ?>
  <div class="row3">
    <label>Product <select name="product_id"<?= aria_error($errors, 'product_id') ?>><?php foreach ($products as $p): ?><option value="<?= (int) $p['id'] ?>"<?= (int) $d['product_id'] === (int) $p['id'] ? ' selected' : '' ?>><?= e($p['name']) ?></option><?php endforeach ?></select></label>
    <label>Version <input name="version" required maxlength="40" class="mono" placeholder="2.2.0" value="<?= e($d['version']) ?>"<?= aria_error($errors, 'version') ?>></label>
    <label>Channel <select name="channel"><option value="stable"<?= $d['channel'] === 'stable' ? ' selected' : '' ?>>Stable</option><option value="beta"<?= $d['channel'] === 'beta' ? ' selected' : '' ?>>Beta (only installations that ask for beta)</option></select></label>
  </div>
  <?= field_error($errors, 'product_id') ?><?= field_error($errors, 'version') ?>
  <label>Title <span class="opt">(optional)</span> <input name="title" maxlength="200" value="<?= e($d['title']) ?>" placeholder="Single sign-on with SAML"></label>
  <label>What changed (Markdown) <textarea name="notes" rows="14" class="mono"><?= e($d['notes']) ?></textarea></label>
  <div class="row3">
    <label>Release date (UTC) <input type="datetime-local" name="released_at" value="<?= e($when) ?>"></label>
    <label>Who may download <select name="access"><option value="licensed"<?= $d['access'] !== 'public' ? ' selected' : '' ?>>Licences with updates</option><option value="public"<?= $d['access'] === 'public' ? ' selected' : '' ?>>Everyone (free)</option></select></label>
    <label>Status <select name="status"><option value="draft"<?= $d['status'] !== 'published' ? ' selected' : '' ?>>Draft</option><option value="published"<?= $d['status'] === 'published' ? ' selected' : '' ?>>Published</option></select></label>
  </div>
  <label>Download from another address instead <span class="opt">(optional, https://)</span> <input name="external_url" maxlength="1000" value="<?= e((string) $d['external_url']) ?>"<?= aria_error($errors, 'external_url') ?>></label>
  <?= field_error($errors, 'external_url') ?>
  <label class="check"><input type="checkbox" name="critical" value="1"<?= (int) $d['critical'] === 1 ? ' checked' : '' ?>> <span>Security update: installations show it as urgent</span></label>
  <p><button class="btn" type="submit">Save</button></p>
</form>
<?php if ($rel !== null): ?>
<div class="row2">
  <form method="post" action="/admin/releases/<?= (int) $rel['id'] ?>/file" enctype="multipart/form-data" class="form box">
    <?= csrf_field() ?>
    <h2>The file</h2>
    <?php if ($rel['file_name'] !== null): ?>
      <p class="small"><span class="mono"><?= e($rel['file_name']) ?></span>, <?= e(number_format((int) $rel['file_bytes'] / 1048576, 1)) ?> MB<br>SHA-256 <span class="mono"><?= e($rel['sha256']) ?></span></p>
    <?php else: ?><p class="small muted">No file yet.</p><?php endif ?>
    <label>Upload <span class="opt">(up to <?= e((string) $maxUpload) ?>)</span> <input type="file" name="file"></label>
    <?php if ($incoming !== []): ?>
    <label>Or a file uploaded to app/storage/releases/incoming <select name="incoming"><option value="">—</option><?php foreach ($incoming as $in): ?><option value="<?= e($in['name']) ?>"><?= e($in['name']) ?> (<?= e(number_format($in['bytes'] / 1048576, 1)) ?> MB)</option><?php endforeach ?></select></label>
    <?php else: ?>
    <p class="small muted">Larger than the upload limit? Put the file in app/storage/releases/incoming with the hosting file manager or FTP, then reload this page.</p>
    <?php endif ?>
    <p><button class="btn small" type="submit">Attach</button></p>
  </form>
  <form method="post" action="/admin/releases/<?= (int) $rel['id'] ?>/delete" class="form box danger-box" data-confirm="Delete this release and its file?">
    <?= csrf_field() ?>
    <h2>Delete</h2>
    <p class="small muted">Removes the release and its file. Installations stop being offered it.</p>
    <p><button class="btn small danger" type="submit">Delete release</button></p>
  </form>
</div>
<h2>Latest downloads</h2>
<?php if ($log === []): ?><p class="muted">None yet.</p><?php else: ?>
<div class="scroll"><table class="table compact"><thead><tr><th scope="col">When</th><th scope="col">Licence</th><th scope="col">How</th></tr></thead><tbody>
<?php foreach ($log as $lg): ?><tr><td><?= e($lg['created_at']) ?></td><td class="mono"><?= $lg['licence_id'] !== null ? '<a href="/admin/licences/'.e($lg['licence_id']).'">'.e($lg['licence_id']).'</a>' : '—' ?></td><td><?= e($lg['via']) ?></td></tr><?php endforeach ?>
</tbody></table></div>
<?php endif ?>
<?php endif ?>
