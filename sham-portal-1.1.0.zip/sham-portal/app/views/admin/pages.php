<h1>Pages</h1>
<p class="muted">The about page, the legal texts and any other company page. Product pages are edited on each product. Words in [CAPITALS] such as [TIN] are filled in from Settings → Company when the page is shown.</p>
<div class="scroll"><table class="table">
  <thead><tr><th scope="col">Page</th><th scope="col">Address</th><th scope="col">Shown in</th><th scope="col">Updated</th><th scope="col">Status</th></tr></thead>
  <tbody><?php foreach ($rows as $pg): ?>
    <tr><td><a href="/admin/pages/<?= (int) $pg['id'] ?>"><?= e($pg['title']) ?></a></td><td class="mono small"><?= $pg['slug'] === 'about' ? '/about' : '/legal/'.e($pg['slug']) ?></td>
      <td><?= e(implode(', ', array_filter([(int) ($pg['in_nav'] ?? 0) === 1 ? 'menu' : '', (int) ($pg['in_footer'] ?? 0) === 1 ? 'footer' : '']))) ?></td>
      <td><?= e(date_human((string) $pg['updated_at'])) ?></td><td><span class="status s-<?= e($pg['status']) ?>"><?= e($pg['status']) ?></span></td></tr>
  <?php endforeach ?></tbody>
</table></div>
<form method="post" class="form inline">
  <?= csrf_field() ?>
  <label>New page address <input name="slug" pattern="[a-z0-9-]{2,60}" required placeholder="cookie-notice"></label>
  <button class="btn small ghost" type="submit">Create</button>
</form>
