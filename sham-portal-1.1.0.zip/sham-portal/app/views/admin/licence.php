<?php
$usage = json_in((string) $l['last_usage_json']);
$hosts = json_in((string) $l['last_hosts_json']);
$limits = json_in((string) $l['limits_json']);
?>
<p class="crumbs"><a href="/admin/licences">Licences</a></p>
<h1><span class="mono"><?= e($l['id']) ?></span> <span class="status s-<?= e($l['status']) ?>"><?= e($l['status']) ?></span></h1>
<div class="grid2">
  <dl class="facts">
    <dt>Licensee</dt><dd><?= e($l['customer_name']) ?><br><a href="mailto:<?= e($l['customer_email']) ?>"><?= e($l['customer_email']) ?></a><?= $l['customer_country'] ? ' · '.e($l['customer_country']) : '' ?></dd>
    <dt>Product</dt><dd><?= e($l['product_name']) ?> <?= e($l['edition']) ?>, <?= e($l['term']) ?><?= (int) $l['offline'] === 1 ? ' · <span class="tag">offline</span>' : '' ?></dd>
    <dt>Domains</dt><dd><?= e(implode(', ', json_in((string) $l['domains_json']))) ?></dd>
    <dt>Limits</dt><dd><?php foreach ($limits as $k => $v): ?><?= e($k) ?> <?= $v === null ? '∞' : (int) $v ?>; <?php endforeach ?></dd>
    <dt>Issued</dt><dd><?= e($l['issued_at']) ?> UTC</dd>
    <dt>Expires</dt><dd><?= e($l['expires_at'] ?? 'never') ?></dd>
    <dt>Updates until</dt><dd><?= e($l['updates_until'] ?? '—') ?></dd>
    <?php if ($l['revoked_reason']): ?><dt>Revoked because</dt><dd><?= e($l['revoked_reason']) ?></dd><?php endif ?>
    <dt>Installation</dt><dd><?= $l['installation_id'] ? '<span class="mono small">'.e($l['installation_id']).'</span> since '.e($l['bound_at']) : 'not bound yet' ?></dd>
    <dt>Last check-in</dt><dd><?= e($l['last_check_in_at'] ?? 'never') ?><?= $l['last_version'] ? ' · version '.e($l['last_version']) : '' ?> · <?= (int) $l['check_ins'] ?> in total</dd>
    <?php if ($hosts !== []): ?><dt>Seen on</dt><dd><?= e(implode(', ', array_map('strval', $hosts))) ?></dd><?php endif ?>
    <?php if ($usage !== []): ?><dt>Usage reported</dt><dd><?php foreach ($usage as $k => $v): ?><?= e($k) ?> <?= e(is_scalar($v) ? (string) $v : json_out($v)) ?>; <?php endforeach ?></dd><?php endif ?>
    <?php if ($l['notes']): ?><dt>Notes</dt><dd><?= e($l['notes']) ?></dd><?php endif ?>
  </dl>
  <div class="actions-col">
    <form method="post" action="/admin/licences/<?= e($l['id']) ?>/extend" class="form box">
      <?= csrf_field() ?>
      <h2>Extend</h2>
      <div class="row2">
        <label>Months of use <input type="number" name="months" min="0" max="120" value="<?= $l['term'] === 'perpetual' ? 0 : 12 ?>"<?= $l['term'] === 'perpetual' ? ' readonly' : '' ?>></label>
        <label>Months of updates <input type="number" name="update_months" min="0" max="120" value="12"></label>
      </div>
      <button class="btn" type="submit">Extend</button>
    </form>
    <form method="post" action="/admin/licences/<?= e($l['id']) ?>/resend"><?= csrf_field() ?><button class="btn ghost" type="submit">E-mail the key</button></form>
    <?php if ($l['installation_id']): ?>
    <form method="post" action="/admin/licences/<?= e($l['id']) ?>/release" data-confirm="Release this licence from its installation? Use this when the customer moves to a new server."><?= csrf_field() ?><button class="btn ghost" type="submit">Release for a new server</button></form>
    <?php endif ?>
    <?php if ($l['status'] === 'active'): ?>
    <form method="post" action="/admin/licences/<?= e($l['id']) ?>/revoke" class="form box danger-box">
      <?= csrf_field() ?>
      <h2>Revoke</h2>
      <p class="small">The newsroom becomes read-only at the next check-in. The public website keeps running.</p>
      <label>Reason (kept in the audit log) <input name="reason" required maxlength="240"></label>
      <?= \Sham\View::partial('admin/_code') ?>
      <button class="btn danger" type="submit">Revoke the licence</button>
    </form>
    <?php else: ?>
    <form method="post" action="/admin/licences/<?= e($l['id']) ?>/reinstate"><?= csrf_field() ?><button class="btn" type="submit">Reinstate</button></form>
    <?php endif ?>
  </div>
</div>
<h2>Key</h2>
<textarea id="key" class="mono key" rows="5" readonly><?= e($l['token']) ?></textarea>
<p><button class="btn small ghost" type="button" data-copy="key">Copy</button></p>
<h2>Orders</h2>
<?php if ($orders === []): ?><p class="muted">Issued by hand.</p><?php else: ?>
<ul class="plain"><?php foreach ($orders as $o): ?><li><a href="/admin/orders/<?= e($o['id']) ?>"><?= e($o['created_at']) ?></a> · <?= e(money((int) $o['total_minor'], (string) $o['currency'])) ?> · <?= e($o['status']) ?><?= $o['renews_licence_id'] === $l['id'] ? ' · renewal' : '' ?></li><?php endforeach ?></ul>
<?php endif ?>
