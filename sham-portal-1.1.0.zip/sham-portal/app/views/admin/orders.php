<h1>Orders</h1>
<form method="get" class="filters">
  <label>Search <input name="q" value="<?= e($q) ?>" placeholder="e-mail, name, receipt, order ID"></label>
  <label>Status <select name="status"><option value="">All</option>
    <?php foreach (['pending', 'review', 'paid', 'fulfilled', 'failed', 'cancelled', 'refunded'] as $s): ?><option<?= $status === $s ? ' selected' : '' ?>><?= e($s) ?></option><?php endforeach ?>
  </select></label>
  <button class="btn small" type="submit">Show</button>
</form>
<?= \Sham\View::partial('admin/_orders', ['rows' => $rows]) ?>
