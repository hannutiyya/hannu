<?php if ($rows === []): ?><p class="muted">No orders.</p><?php else: ?>
<div class="scroll"><table class="table">
  <thead><tr><th scope="col">Placed</th><th scope="col">Buyer</th><th scope="col">Product</th><th scope="col">Total</th><th scope="col">Method</th><th scope="col">Status</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $o): ?>
    <tr>
      <td><a href="/admin/orders/<?= e($o['id']) ?>"><?= e(substr((string) $o['created_at'], 0, 16)) ?></a></td>
      <td><?= e($o['customer_name']) ?><br><span class="muted small"><?= e($o['customer_email']) ?></span></td>
      <td><?= e($o['product_name']) ?> <?= e($o['edition']) ?><span class="muted small"> · <?= e($o['term']) ?><?= $o['renews_licence_id'] !== null ? ' · renewal' : '' ?></span></td>
      <td><?= e(money((int) $o['total_minor'], (string) $o['currency'])) ?><?= (int) $o['test_mode'] === 1 ? ' <span class="tag">test</span>' : '' ?></td>
      <td><?= e($o['provider']) ?></td>
      <td><span class="status s-<?= e($o['status']) ?>"><?= e($o['status']) ?></span></td>
    </tr>
  <?php endforeach ?>
  </tbody>
</table></div>
<?php endif ?>
