<label class="code">Fresh authenticator code <input name="confirm_code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required></label>
