<?php use Sham\Settings; ?>
<h1>Settings</h1>
<nav class="tabs" aria-label="Settings sections"><?php foreach ($sections as $k => [$lbl]): ?><a href="/admin/settings/<?= e($k) ?>"<?= $k === $section ? ' aria-current="page"' : '' ?>><?= e($lbl) ?></a><?php endforeach ?></nav>
<form method="post" class="form wide-form" autocomplete="off">
  <?= csrf_field() ?>
  <?php $hasSecret = false; foreach ($fields as [$key, $label, $type, $help]): $name = 'f_'.str_replace('.', '__', $key); $val = str_starts_with($type, 'secret') ? '' : Settings::get($key); ?>
    <?php if (str_ends_with($key, '.enabled') && $key !== 'stripe.enabled' && $section === 'payments'): ?><hr><?php endif ?>
    <?php if ($type === 'bool'): ?>
      <label class="check"><input type="checkbox" name="<?= e($name) ?>" value="1"<?= Settings::bool($key) ? ' checked' : '' ?>> <span><strong><?= e($label) ?></strong><?= $help !== '' ? '<br><span class="small muted">'.e($help).'</span>' : '' ?></span></label>
    <?php elseif (str_starts_with($type, 'select:')): ?>
      <label><?= e($label) ?> <select name="<?= e($name) ?>"><?php foreach (explode(',', substr($type, 7)) as $opt): ?><option<?= $val === $opt ? ' selected' : '' ?>><?= e($opt) ?></option><?php endforeach ?></select></label>
    <?php elseif (str_starts_with($type, 'secret')): $hasSecret = true; $hint = Settings::hint($key); ?>
      <div class="secret">
        <label><?= e($label) ?> <span class="opt"><?= $hint !== '' ? 'set ('.e($hint).'); leave empty to keep' : 'not set' ?></span>
          <?php if ($type === 'secret-area'): ?><textarea name="<?= e($name) ?>" rows="4" class="mono" spellcheck="false"></textarea>
          <?php else: ?><input type="password" name="<?= e($name) ?>" autocomplete="new-password" spellcheck="false"><?php endif ?></label>
        <?php if ($hint !== ''): ?><label class="check small"><input type="checkbox" name="<?= e($name) ?>__clear" value="1"> <span>Remove the stored value</span></label><?php endif ?>
      </div>
    <?php elseif ($type === 'textarea'): ?>
      <label><?= e($label) ?> <textarea name="<?= e($name) ?>" rows="3"><?= e($val) ?></textarea></label>
    <?php else: ?>
      <label><?= e($label) ?> <input type="<?= $type === 'number' ? 'number" step="any' : ($type === 'email' ? 'email' : 'text') ?>" name="<?= e($name) ?>" value="<?= e($val) ?>"></label>
    <?php endif ?>
    <?php if ($help !== '' && $type !== 'bool'): ?><p class="small muted help"><?= e($help) ?></p><?php endif ?>
  <?php endforeach ?>
  <?php if ($hasSecret): ?>
    <p class="small">Changing or removing a key or password also needs a fresh code:</p>
    <label class="code">Authenticator code <input name="confirm_code" inputmode="numeric" autocomplete="one-time-code" maxlength="6"></label>
  <?php endif ?>
  <button class="btn" type="submit">Save</button>
</form>
<?php if ($section === 'mail'): ?>
<form method="post" class="form inline"><?= csrf_field() ?><input type="hidden" name="test_mail" value="1"><button class="btn ghost" type="submit">Send a test e-mail to me</button></form>
<?php endif ?>
