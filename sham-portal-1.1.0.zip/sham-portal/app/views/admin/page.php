<p class="crumbs"><a href="/admin/pages">Pages</a></p>
<h1><?= e($page['title']) ?></h1>
<?php if ($page['status'] === 'published' && isset($url)): ?><p>Live at <a href="<?= e($url) ?>"><?= e($url) ?></a></p><?php endif ?>
<form method="post" class="form wide-form">
  <?= csrf_field() ?>
  <label>Title <input name="title" maxlength="160" value="<?= e($page['title']) ?>"></label>
  <label>Text (Markdown) <textarea name="body" rows="28" class="mono"><?= e($page['body']) ?></textarea></label>
  <label>Status <select name="status">
    <option value="published"<?= $page['status'] === 'published' ? ' selected' : '' ?>>Published</option>
    <option value="draft"<?= $page['status'] !== 'published' ? ' selected' : '' ?>>Draft</option>
  </select></label>
  <label class="check"><input type="checkbox" name="in_nav" value="1"<?= (int) ($page['in_nav'] ?? 0) === 1 ? ' checked' : '' ?>> <span>Show in the main menu of sham.et</span></label>
  <label class="check"><input type="checkbox" name="in_footer" value="1"<?= (int) ($page['in_footer'] ?? 0) === 1 ? ' checked' : '' ?>> <span>Show in the footer of every site</span></label>
  <button class="btn" type="submit">Save</button>
</form>
<p class="muted small">Legal texts were drafted for Ethiopian law and should be read by your lawyer before you rely on them. Changes take effect for new orders from the moment you save.</p>
