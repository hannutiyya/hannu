<h1>Licences</h1>
<p><a class="btn" href="/admin/licences/new">Issue a licence by hand</a></p>
<form method="get" class="filters">
  <label>Search <input name="q" value="<?= e($q) ?>" placeholder="licence ID, e-mail, name, domain"></label>
  <button class="btn small" type="submit">Search</button>
</form>
<?php if ($rows === []): ?><p class="muted">No licences.</p><?php else: ?>
<div class="scroll"><table class="table">
  <thead><tr><th scope="col">Licence</th><th scope="col">Licensee</th><th scope="col">Edition</th><th scope="col">Expires</th><th scope="col">Last check-in</th><th scope="col">Status</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $l): $expired = $l['expires_at'] !== null && strtotime($l['expires_at'].' UTC') < time(); ?>
    <tr>
      <td><a class="mono small" href="/admin/licences/<?= e($l['id']) ?>"><?= e($l['id']) ?></a><br><span class="muted small"><?= e(implode(', ', json_in((string) $l['domains_json']))) ?></span></td>
      <td><?= e($l['customer_name']) ?><br><span class="muted small"><?= e($l['customer_email']) ?></span></td>
      <td><?= e($l['product_name']) ?> <?= e($l['edition']) ?><span class="muted small"> · <?= e($l['term']) ?></span></td>
      <td><?= $l['expires_at'] === null ? 'never' : e(date_human((string) $l['expires_at'])) ?></td>
      <td><?= $l['last_check_in_at'] === null ? '<span class="muted">never</span>' : e(date_human((string) $l['last_check_in_at'])).' <span class="muted small">v'.e($l['last_version']).'</span>' ?></td>
      <td><span class="status s-<?= e($expired && $l['status'] === 'active' ? 'expired' : $l['status']) ?>"><?= e($expired && $l['status'] === 'active' ? 'expired' : $l['status']) ?></span></td>
    </tr>
  <?php endforeach ?>
  </tbody>
</table></div>
<?php endif ?>
