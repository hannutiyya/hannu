<section class="wrap narrow block">
  <p class="eyebrow">Error <?= (int) $status ?></p>
  <h1><?= e($title) ?></h1>
  <p class="lead"><?= e($message) ?></p>
  <p><a class="btn" href="/">Go to the start page</a></p>
</section>
