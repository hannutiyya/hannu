<?php
use Sham\Content;

$byCat = [];
foreach ($products as $p) {
    $byCat[($p['category'] ?? '') !== '' ? $p['category'] : 'Other'][] = $p;
}
?>
<section class="hero">
  <div class="wrap">
    <h1>Products</h1>
    <p class="lead">Everything we make, by field. Each product has its own pages, news and team.</p>
  </div>
</section>
<section class="wrap block">
  <?php foreach ($byCat as $cat => $list): ?>
  <h2 class="cat"><?= e($cat) ?></h2>
  <div class="cards">
    <?php foreach ($list as $p): $u = Content::productUrl($p); ?>
    <article class="card ac-<?= e(strtolower(ltrim((string) $p['accent'], '#'))) ?>">
      <p class="dot" aria-hidden="true"></p>
      <h3><a href="<?= e($u) ?>"><?= e($p['name']) ?></a></h3>
      <p class="tagline"><?= e($p['tagline']) ?></p>
      <p><?= e($p['summary']) ?></p>
      <p><a class="more" href="<?= e($u) ?>">Learn more <span class="sr">about <?= e($p['name']) ?></span><span aria-hidden="true">→</span></a></p>
    </article>
    <?php endforeach ?>
  </div>
  <?php endforeach ?>
  <?php if ($products === []): ?><p class="muted">Our products will be listed here soon.</p><?php endif ?>
</section>
