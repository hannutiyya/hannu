<?php $old = $old ?? []; $v = fn (string $k): string => (string) ($old[$k] ?? ''); ?>
<section class="wrap narrow block">
  <h1><?= e($title) ?><?= is_array($product) ? ': '.e($product['name']) : '' ?></h1>
  <?php if ($sent): ?>
    <div class="notice ok" role="status">
      <p><strong>Thank you. Your message is with our team.</strong></p>
      <p>We reply within two business days, from an @<?= e(substr((string) strrchr(\Sham\Settings::get('company.sales_email'), '@'), 1)) ?> address.</p>
    </div>
  <?php else: ?>
  <p class="lead"><?= $kind === 'quote' ? 'Tell us about your organisation and what you need. We will send a written quotation.' : 'Write to us and the right person will reply within two business days.' ?></p>
  <form method="post" class="form" novalidate>
    <?= csrf_field() ?>
    <input type="hidden" name="stamp" value="<?= e($stamp) ?>">
    <div class="hp" aria-hidden="true"><label>Leave this empty <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
    <label>Your name <input name="name" required maxlength="160" autocomplete="name" value="<?= e($v('name')) ?>"<?= aria_error($errors, 'name') ?>></label>
    <?= field_error($errors, 'name') ?>
    <label>E-mail <input type="email" name="email" required maxlength="190" autocomplete="email" value="<?= e($v('email')) ?>"<?= aria_error($errors, 'email') ?>></label>
    <?= field_error($errors, 'email') ?>
    <label>Organisation <span class="opt">(optional)</span> <input name="organisation" maxlength="190" autocomplete="organization" value="<?= e($v('organisation')) ?>"></label>
    <div class="row2">
      <label>Country code <span class="opt">(e.g. ET)</span> <input name="country" maxlength="2" autocomplete="country" value="<?= e($v('country')) ?>"></label>
      <label>Phone <span class="opt">(optional)</span> <input type="tel" name="phone" maxlength="40" autocomplete="tel" value="<?= e($v('phone')) ?>"></label>
    </div>
    <?php if (! is_array($product) && $products !== []): ?>
    <label>About <select name="product"><option value="">General question</option>
      <?php foreach ($products as $p): ?><option value="<?= e($p['slug']) ?>"<?= $v('product') === $p['slug'] ? ' selected' : '' ?>><?= e($p['name']) ?></option><?php endforeach ?>
    </select></label>
    <?php endif ?>
    <?php if (($edition ?? '') !== ''): ?><p class="muted">Edition: <?= e($edition) ?></p><?php endif ?>
    <label>Message <textarea name="message" required rows="7" maxlength="5000"<?= aria_error($errors, 'message') ?>><?= e($v('message')) ?></textarea></label>
    <?= field_error($errors, 'message') ?>
    <p class="muted small">We use these details only to answer you. See our <a href="/legal/privacy">privacy policy</a>.</p>
    <button class="btn" type="submit">Send</button>
  </form>
  <?php endif ?>
</section>
