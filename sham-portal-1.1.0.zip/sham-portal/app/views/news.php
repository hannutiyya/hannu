<?php
use Sham\Config;
use Sham\Content;
use Sham\View;

$base = $base ?? '';
$isProduct = is_array($product ?? null);
$self = $isProduct ? $base.'/news' : '/news';
$link = fn (array $q): string => $self.($q !== [] ? '?'.http_build_query($q) : '');
?>
<section class="wrap block">
  <h1><?= e($title) ?></h1>
  <ul class="tabs" aria-label="Kinds of posts">
    <li><a href="<?= e($self) ?>"<?= $kind === '' ? ' aria-current="page"' : '' ?>>All</a></li>
    <?php foreach (Content::POST_KINDS as $k => $label): ?><li><a href="<?= e($link(['kind' => $k])) ?>"<?= $kind === $k ? ' aria-current="page"' : '' ?>><?= e($label) ?></a></li><?php endforeach ?>
  </ul>
  <?php if ($posts === []): ?>
    <p class="muted">Nothing here yet.</p>
  <?php else: ?>
    <?= View::partial('_post-cards', ['posts' => $posts, 'showProduct' => ! $isProduct]) ?>
  <?php endif ?>
  <?php if ($pages > 1): ?>
  <nav class="pager" aria-label="Pages">
    <?php if ($pageNo > 1): ?><a href="<?= e($link(array_filter(['kind' => $kind, 'page' => $pageNo - 1]))) ?>">← Newer</a><?php endif ?>
    <span class="muted">Page <?= (int) $pageNo ?> of <?= (int) $pages ?></span>
    <?php if ($pageNo < $pages): ?><a href="<?= e($link(array_filter(['kind' => $kind, 'page' => $pageNo + 1]))) ?>">Older →</a><?php endif ?>
  </nav>
  <?php endif ?>
</section>
<section class="band" id="subscribe">
  <div class="wrap narrow">
    <h2>News by e-mail</h2>
    <?php if (! $isProduct): ?>
    <p>New products, updates and announcements, a few times a month. We send a link to confirm first, and every message has a link to stop.</p>
    <form method="post" action="/subscribe" class="form">
      <?= csrf_field() ?>
      <label>E-mail address <input type="email" name="email" required maxlength="190" autocomplete="email"></label>
      <?php if (! empty($products)): ?>
      <fieldset>
        <legend>Only about <span class="opt">(leave all empty for everything)</span></legend>
        <?php foreach ($products as $p): ?><label class="check"><input type="checkbox" name="products[]" value="<?= e($p['slug']) ?>"> <span><?= e($p['name']) ?></span></label><?php endforeach ?>
      </fieldset>
      <?php endif ?>
      <span class="hp" aria-hidden="true"><label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label></span>
      <p><button class="btn" type="submit">Subscribe</button></p>
    </form>
    <?php else: ?>
    <p><a class="btn" href="<?= e(Config::url('company', '/news')) ?>#subscribe">Subscribe to our news</a> · <a href="<?= e($base) ?>/feed.xml">RSS feed</a></p>
    <?php endif ?>
  </div>
</section>
