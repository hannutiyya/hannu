<?php
use Sham\Content;
use Sham\Media;

$base = $base ?? '';
$isProduct = is_array($product ?? null);
?>
<article class="wrap narrow block prose">
  <p class="eyebrow"><a href="<?= e($isProduct ? $base.'/news' : '/news') ?>"><?= e(Content::POST_KINDS[$post['kind']] ?? 'News') ?></a><?= ! $isProduct && $post['product_name'] !== null ? ' · '.e($post['product_name']) : '' ?></p>
  <h1><?= e($post['title']) ?></h1>
  <p class="meta"><time datetime="<?= e(gmdate('c', (int) strtotime($post['published_at'].' UTC'))) ?>"><?= e(date_human((string) $post['published_at'])) ?></time></p>
  <?php if ($post['cover_uid'] !== null): ?><img class="cover" src="<?= e(Media::url(['uid' => $post['cover_uid'], 'filename' => $post['cover_filename']])) ?>" alt="<?= e($post['cover_alt'] ?? '') ?>"><?php endif ?>
  <?php if ($post['summary'] !== ''): ?><p class="lead"><?= e($post['summary']) ?></p><?php endif ?>
  <?= $body ?>
  <hr>
  <p><a href="<?= e($isProduct ? $base.'/news' : '/news') ?>">← All news</a> · <a href="<?= e(\Sham\Config::url('company', '/news')) ?>#subscribe">Get news by e-mail</a></p>
</article>
