<article class="wrap narrow block prose">
  <h1><?= e($page['title']) ?></h1>
  <?= $body ?>
  <p class="muted small">Last updated <?= e(date_human((string) $page['updated_at'])) ?>.</p>
</article>
