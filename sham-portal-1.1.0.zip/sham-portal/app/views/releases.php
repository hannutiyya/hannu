<?php
use Sham\Config;
use Sham\Markdown;

$base = $base ?? '';
?>
<section class="wrap narrow block">
  <p class="eyebrow"><a href="<?= e($base) ?>/"><?= e($product['name']) ?></a></p>
  <h1>Releases</h1>
  <p class="lead">What changed in each version. Customers download from <a href="<?= e(Config::url('store', '/account')) ?>">their account</a>; installations are told about new versions by themselves.</p>
  <?php if ($releases === []): ?><p class="muted">No releases published yet.</p><?php endif ?>
  <?php foreach ($releases as $rl): ?>
  <article class="release" id="v<?= e($rl['version']) ?>">
    <h2><?= e($product['name']) ?> <?= e($rl['version']) ?>
      <?php if ($rl['channel'] === 'beta'): ?><span class="badge">beta</span><?php endif ?>
      <?php if ((int) $rl['critical'] === 1): ?><span class="badge warn">security update</span><?php endif ?>
      <?php if ($rl['access'] === 'public'): ?><span class="badge ok">free download</span><?php endif ?></h2>
    <p class="meta"><?= e(date_human((string) $rl['released_at'])) ?><?= $rl['title'] !== '' ? ' · '.e($rl['title']) : '' ?></p>
    <div class="prose"><?= Markdown::render((string) $rl['notes']) ?></div>
    <?php if ($rl['access'] === 'public' && ($rl['file_path'] !== null || $rl['external_url'] !== null)): ?>
    <p><a class="btn small" href="<?= e(Config::url('licensing', '/dl/'.\Sham\Content::downloadToken((int) $rl['id'], null, 7200))) ?>" rel="nofollow">Download<?= $rl['file_bytes'] !== null ? ' ('.e(number_format((int) $rl['file_bytes'] / 1048576, 1)).' MB)' : '' ?></a></p>
    <?php endif ?>
    <?php if ($rl['sha256'] !== null): ?><p class="small muted">SHA-256 <span class="mono"><?= e($rl['sha256']) ?></span></p><?php endif ?>
  </article>
  <?php endforeach ?>
</section>
