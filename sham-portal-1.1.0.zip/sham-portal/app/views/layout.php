<?php
use Sham\Config;
use Sham\Settings;
use Sham\Store\Catalogue;

/** @var string $content */
$site = $site ?? 'company';
$product = $product ?? null;
$short = Settings::get('company.short', 'Sham');
$brand = $site === 'product' && is_array($product) ? (string) $product['name'] : $short;
$home = $site === 'product' && is_array($product) ? '/' : Config::url('company', '/');
$pageTitle = isset($title) && $title !== null && $title !== $brand ? $title.' · '.$brand : $brand.' · '.Settings::get('company.tagline');
$desc = $description ?? Settings::get('company.tagline');
$accentCss = accent_href($accent ?? null);
try {
    $all = Catalogue::products();
} catch (\Throwable) {
    $all = [];
}
$productUrl = fn (array $p): string => ($p['host'] ?? '') !== '' ? Config::get('scheme', 'https').'://'.$p['host'].'/' : Config::url('store', '/buy/'.$p['slug']);
$own = $site === 'product' ? '' : Config::url('company');
$isProduct = $site === 'product' && is_array($product);
// A product without its own host lives under sham.et/products/{slug}.
$base = $base ?? ($isProduct && ($product['host'] ?? '') === '' ? '/products/'.$product['slug'] : '');
if ($isProduct) {
    $home = $base.'/';
}
// Pages marked for the menu and the footer, and the announcement bar (all set in the admin).
try {
    $navPages = \Sham\Db::all("SELECT slug, title FROM pages WHERE status = 'published' AND in_nav = 1 ORDER BY title");
    $footPages = \Sham\Db::all("SELECT slug, title FROM pages WHERE status = 'published' AND in_footer = 1 ORDER BY title");
    $hasReleases = $isProduct && \Sham\Content::releases((int) $product['id'], null, 1) !== [];
} catch (\Throwable) {
    $navPages = $footPages = [];
    $hasReleases = false;
}
$pageUrl = fn (string $slug): string => Config::url('company', $slug === 'about' ? '/about' : '/legal/'.$slug);
$announce = Settings::get('site.announcement');
$announceLink = Settings::get('site.announcement_link');
$announceLink = preg_match('#^(https://|/(?!/))#', $announceLink) === 1 ? $announceLink : '';
$social = [];
foreach (['facebook' => 'Facebook', 'x' => 'X', 'linkedin' => 'LinkedIn', 'youtube' => 'YouTube', 'telegram' => 'Telegram'] as $k => $label) {
    $u = Settings::get('social.'.$k);
    if (str_starts_with($u, 'https://') && filter_var($u, FILTER_VALIDATE_URL) !== false) {
        $social[$label] = $u;
    }
}
$feed = $isProduct ? $base.'/feed.xml' : Config::url('company', '/feed.xml');
try {
    $subNav = $isProduct ? (isset($nav) && is_array($nav) ? $nav : \Sham\Content::productPages((int) $product['id'], true)) : [];
} catch (\Throwable) {
    $subNav = [];
}
$here = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$cur = fn (string $href): string => rtrim((string) (parse_url($href, PHP_URL_PATH) ?: '/'), '/') === rtrim($here, '/') && (parse_url($href, PHP_URL_HOST) === null || parse_url($href, PHP_URL_HOST) === ($_SERVER['HTTP_HOST'] ?? '')) ? ' aria-current="page"' : '';
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?></title>
<meta name="description" content="<?= e(str_limit((string) $desc, 300)) ?>">
<meta property="og:title" content="<?= e($pageTitle) ?>">
<meta property="og:description" content="<?= e(str_limit((string) $desc, 300)) ?>">
<meta name="theme-color" content="#14181f">
<link rel="stylesheet" href="/assets/site.css?v=<?= e(SHAM_VERSION) ?>">
<?php if ($accentCss !== ''): ?><link rel="stylesheet" href="<?= e($accentCss) ?>"><?php endif ?>
<?php if ($site === 'company'): foreach ($all as $p): if (($h = accent_href($p['accent'], false)) !== ''): ?><link rel="stylesheet" href="<?= e($h) ?>"><?php endif; endforeach; endif ?>
<link rel="icon" href="/assets/icon.svg" type="image/svg+xml">
<link rel="alternate" type="application/rss+xml" title="<?= e($brand) ?> news" href="<?= e($feed) ?>">
<?php if (isset($canonical) && is_string($canonical)): ?><link rel="canonical" href="<?= e($canonical) ?>"><?php endif ?>
</head>
<body class="site-<?= e($site) ?>">
<a class="skip" href="#main">Skip to content</a>
<?php if ($announce !== ''): ?>
<p class="announce"><?php if ($announceLink !== ''): ?><a href="<?= e($announceLink) ?>"><?= e($announce) ?></a><?php else: ?><?= e($announce) ?><?php endif ?></p>
<?php endif ?>
<header class="top">
  <div class="wrap top-in">
    <a class="brand" href="<?= e($home) ?>"><span class="mark" aria-hidden="true"></span><?= e($brand) ?></a>
    <nav aria-label="Main">
      <ul>
        <?php if ($isProduct): ?>
          <?php foreach ($subNav as $sp): ?><li><a href="<?= e($base.'/'.$sp['slug']) ?>"<?= $cur($base.'/'.$sp['slug']) ?>><?= e($sp['title']) ?></a></li><?php endforeach ?>
          <li><a href="<?= e($base) ?>/news"<?= $cur($base.'/news') ?>>News</a></li>
          <?php if ($hasReleases): ?><li><a href="<?= e($base) ?>/releases"<?= $cur($base.'/releases') ?>>Releases</a></li><?php endif ?>
          <?php if (($product['licence_kind'] ?? '') === 'mediaos'): ?><li><a href="<?= e(Config::url('store', '/buy/'.$product['slug'])) ?>">Buy</a></li><?php endif ?>
          <li><a href="<?= e($base) ?>/contact"<?= $cur($base.'/contact') ?>>Contact</a></li>
          <li><a href="<?= e(Config::url('company', '/')) ?>"><?= e($short) ?></a></li>
        <?php else: ?>
          <li><a href="<?= e(Config::url('company', '/products')) ?>"<?= $cur(Config::url('company', '/products')) ?>>Products</a></li>
          <li><a href="<?= e(Config::url('company', '/news')) ?>"<?= $cur(Config::url('company', '/news')) ?>>News</a></li>
          <?php foreach ($navPages as $np): ?><li><a href="<?= e($pageUrl((string) $np['slug'])) ?>"<?= $cur($pageUrl((string) $np['slug'])) ?>><?= e($np['title']) ?></a></li><?php endforeach ?>
          <li><a href="<?= e(Config::url('store', '/')) ?>"<?= $site === 'store' ? $cur(Config::url('store', '/')) : '' ?>>Store</a></li>
          <li><a href="<?= e(Config::url('company', '/contact')) ?>"<?= $cur(Config::url('company', '/contact')) ?>>Contact</a></li>
          <?php if ($site === 'store'): ?><li><a href="<?= e(Config::url('store', '/account')) ?>"<?= $cur(Config::url('store', '/account')) ?>>Your licences</a></li><?php endif ?>
        <?php endif ?>
      </ul>
    </nav>
  </div>
</header>
<main id="main">
<?= $content ?>
</main>
<footer class="foot">
  <div class="wrap foot-in">
    <div>
      <p class="foot-brand"><?= e(Settings::get('company.name')) ?></p>
      <p><?= e(Settings::get('company.address')) ?></p>
      <p><a href="mailto:<?= e(Settings::get('company.sales_email')) ?>"><?= e(Settings::get('company.sales_email')) ?></a></p>
    </div>
    <?php if ($all !== []): ?>
    <div>
      <p class="foot-h">Products</p>
      <ul><?php foreach ($all as $p): ?><li><a href="<?= e($productUrl($p)) ?>"><?= e($p['name']) ?></a></li><?php endforeach ?></ul>
    </div>
    <?php endif ?>
    <div>
      <p class="foot-h">Company</p>
      <ul>
        <li><a href="<?= e(Config::url('company', '/news')) ?>">News and updates</a></li>
        <li><a href="<?= e(Config::url('store', '/account')) ?>">Your licences and downloads</a></li>
        <?php foreach ($footPages as $fp): ?><li><a href="<?= e($pageUrl((string) $fp['slug'])) ?>"><?= e($fp['title']) ?></a></li><?php endforeach ?>
        <li><a href="<?= e($feed) ?>">RSS feed</a></li>
      </ul>
    </div>
    <div>
      <p class="foot-h">News by e-mail</p>
      <?php if ($site === 'company'): ?>
      <form method="post" action="<?= e(Config::url('company', '/subscribe')) ?>" class="sub">
        <?= csrf_field() ?>
        <label class="sr" for="sub-email">E-mail address</label>
        <input id="sub-email" type="email" name="email" required maxlength="190" placeholder="you@example.com" autocomplete="email">
        <span class="hp" aria-hidden="true"><input type="text" name="website" tabindex="-1" autocomplete="off"></span>
        <button class="btn small" type="submit">Subscribe</button>
      </form>
      <?php else: ?>
      <p><a href="<?= e(Config::url('company', '/news')) ?>#subscribe">Subscribe to our news</a></p>
      <?php endif ?>
      <?php if ($social !== []): ?>
      <ul class="social"><?php foreach ($social as $label => $u): ?><li><a href="<?= e($u) ?>" rel="noopener noreferrer me"><?= e($label) ?></a></li><?php endforeach ?></ul>
      <?php endif ?>
    </div>
  </div>
  <div class="wrap foot-small">© <?= gmdate('Y') ?> <?= e(Settings::get('company.name')) ?></div>
</footer>
</body>
</html>
