<section class="wrap narrow block">
  <h1><?= e($title ?? 'Notice') ?></h1>
  <div class="notice"><p><?= e($message) ?></p></div>
  <?php if (! empty($action)): ?>
  <form method="post" action="<?= e($action) ?>">
    <?= csrf_field() ?>
    <button class="btn" type="submit"><?= e($button !== '' ? $button : 'Continue') ?></button>
  </form>
  <?php else: ?>
  <p><a href="<?= e(\Sham\Config::url('company', '/')) ?>">Back to the home page</a></p>
  <?php endif ?>
</section>
