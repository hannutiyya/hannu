<?php

declare(strict_types=1);

/*
 * Optional cron job (the portal also runs this work by itself after visits). For exact timing add, every 10 minutes:
 *   /usr/local/bin/php /home/USER/sham-portal/app/cron.php >/dev/null 2>&1
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
require __DIR__.'/bootstrap.php';
if (! Sham\Config::installed()) {
    fwrite(STDERR, "Not installed yet.\n");
    exit(1);
}
foreach (Sham\Cron::run('cron') as $line) {
    fwrite(STDOUT, gmdate('c').' '.$line."\n");
}
