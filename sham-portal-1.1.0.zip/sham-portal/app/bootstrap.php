<?php

declare(strict_types=1);

/*
 * Sham portal bootstrap: sham.et (company), product sites (media.sham.et, taligaa.sham.et, …), store.sham.et (store and
 * admin) and licensing.sham.et (licence check-ins), from one PHP 8.1+ / MySQL application.
 *
 * Layout on the server:  <home>/sham-portal/app   (this folder: code, config.php, storage — never web-served)
 *                        <home>/public_html        (or each subdomain's document root) = the contents of public/
 */

define('SHAM_APP', __DIR__);
define('SHAM_VERSION', '1.1.0');

spl_autoload_register(static function (string $class): void {
    if (str_starts_with($class, 'Sham\\')) {
        $file = SHAM_APP.'/src/'.str_replace('\\', '/', substr($class, 5)).'.php';
        if (is_file($file)) {
            require $file;
        }
    }
});

require SHAM_APP.'/src/helpers.php';

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
if (is_dir(SHAM_APP.'/storage/logs') || @mkdir(SHAM_APP.'/storage/logs', 0700, true)) {
    ini_set('error_log', SHAM_APP.'/storage/logs/php-error.log');
}
date_default_timezone_set('UTC');
mb_internal_encoding('UTF-8');

Sham\Config::load(getenv('SHAM_CONFIG') ?: SHAM_APP.'/config.php');
