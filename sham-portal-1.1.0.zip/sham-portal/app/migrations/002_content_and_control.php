<?php

declare(strict_types=1);

use Sham\Migrator;

// 1.1: news and updates, product sub-pages, media library, releases and downloads, customer accounts, subscribers,
// a mail queue, editor role, product categories and navigation flags on pages.
return function (PDO $pdo): void {
    $t = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $pdo->exec("CREATE TABLE IF NOT EXISTS media (
      id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      uid CHAR(24) NOT NULL UNIQUE,
      filename VARCHAR(190) NOT NULL,
      mime VARCHAR(80) NOT NULL,
      bytes BIGINT UNSIGNED NOT NULL,
      width INT NULL, height INT NULL,
      alt VARCHAR(255) NOT NULL DEFAULT '',
      kind VARCHAR(20) NOT NULL DEFAULT 'image',
      sha256 CHAR(64) NOT NULL,
      created_by VARCHAR(190) NULL,
      created_at DATETIME NOT NULL
    ) {$t}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS posts (
      id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      product_id INT UNSIGNED NULL,
      kind VARCHAR(20) NOT NULL DEFAULT 'news',
      slug VARCHAR(140) NOT NULL UNIQUE,
      title VARCHAR(200) NOT NULL,
      summary VARCHAR(500) NOT NULL DEFAULT '',
      body MEDIUMTEXT NOT NULL,
      cover_media_id INT UNSIGNED NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'draft',
      published_at DATETIME NULL,
      mailed_at DATETIME NULL,
      author VARCHAR(190) NULL,
      created_at DATETIME NOT NULL,
      updated_at DATETIME NOT NULL,
      KEY posts_live (status, published_at),
      KEY posts_product (product_id, status, published_at)
    ) {$t}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS product_pages (
      id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      product_id INT UNSIGNED NOT NULL,
      slug VARCHAR(80) NOT NULL,
      title VARCHAR(160) NOT NULL,
      body MEDIUMTEXT NOT NULL,
      in_nav TINYINT(1) NOT NULL DEFAULT 1,
      sort INT NOT NULL DEFAULT 0,
      status VARCHAR(20) NOT NULL DEFAULT 'draft',
      updated_at DATETIME NOT NULL,
      UNIQUE KEY product_pages_slug (product_id, slug),
      CONSTRAINT product_pages_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    ) {$t}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS releases (
      id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      product_id INT UNSIGNED NOT NULL,
      version VARCHAR(40) NOT NULL,
      channel VARCHAR(20) NOT NULL DEFAULT 'stable',
      title VARCHAR(200) NOT NULL DEFAULT '',
      notes MEDIUMTEXT NOT NULL,
      released_at DATETIME NOT NULL,
      access VARCHAR(20) NOT NULL DEFAULT 'licensed',
      file_path VARCHAR(255) NULL,
      file_name VARCHAR(190) NULL,
      file_bytes BIGINT UNSIGNED NULL,
      sha256 CHAR(64) NULL,
      external_url TEXT NULL,
      critical TINYINT(1) NOT NULL DEFAULT 0,
      status VARCHAR(20) NOT NULL DEFAULT 'draft',
      downloads INT NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL,
      UNIQUE KEY releases_version (product_id, version),
      KEY releases_live (product_id, status, channel, released_at),
      CONSTRAINT releases_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    ) {$t}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS download_log (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      release_id INT UNSIGNED NOT NULL,
      licence_id VARCHAR(40) NULL,
      via VARCHAR(20) NOT NULL,
      ip_hash CHAR(32) NULL,
      created_at DATETIME NOT NULL,
      KEY download_log_release (release_id, created_at)
    ) {$t}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS login_tokens (
      token_hash CHAR(64) NOT NULL PRIMARY KEY,
      email VARCHAR(190) NOT NULL,
      expires_at DATETIME NOT NULL,
      used_at DATETIME NULL,
      KEY login_tokens_email (email)
    ) {$t}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS subscribers (
      id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      email VARCHAR(190) NOT NULL UNIQUE,
      products_json TEXT NOT NULL,
      token CHAR(32) NOT NULL,
      confirmed_at DATETIME NULL,
      unsubscribed_at DATETIME NULL,
      ip_hash CHAR(32) NULL,
      created_at DATETIME NOT NULL
    ) {$t}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS mail_queue (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      to_email VARCHAR(190) NOT NULL,
      subject VARCHAR(255) NOT NULL,
      body MEDIUMTEXT NOT NULL,
      reply_to VARCHAR(190) NULL,
      attempts INT NOT NULL DEFAULT 0,
      sent_at DATETIME NULL,
      created_at DATETIME NOT NULL,
      KEY mail_queue_todo (sent_at, attempts)
    ) {$t}");
    Migrator::addColumn($pdo, 'products', 'category', "VARCHAR(60) NOT NULL DEFAULT ''");
    Migrator::addColumn($pdo, 'products', 'logo_media_id', 'INT UNSIGNED NULL');
    Migrator::addColumn($pdo, 'products', 'regulatory_note', "VARCHAR(500) NOT NULL DEFAULT ''");
    Migrator::addColumn($pdo, 'pages', 'in_footer', 'TINYINT(1) NOT NULL DEFAULT 0');
    Migrator::addColumn($pdo, 'pages', 'in_nav', 'TINYINT(1) NOT NULL DEFAULT 0');
    $pdo->exec("UPDATE pages SET in_nav = 1 WHERE slug = 'about'");
    $pdo->exec("UPDATE pages SET in_footer = 1 WHERE slug IN ('licence-agreement','terms-of-sale','privacy','acceptable-use')");
    $pdo->exec("UPDATE products SET category = 'Media' WHERE slug = 'mediaos' AND category = ''");
    $pdo->exec("UPDATE products SET category = 'Health' WHERE slug = 'taligaa' AND category = ''");
};
