<?php

declare(strict_types=1);

use Sham\Migrator;

// 1.1: one-click unsubscribe header (RFC 8058) on news e-mails.
return function (PDO $pdo): void {
    Migrator::addColumn($pdo, 'mail_queue', 'unsubscribe_url', 'VARCHAR(255) NULL');
};
