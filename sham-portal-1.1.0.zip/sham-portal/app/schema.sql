-- Sham portal schema (MySQL 5.7+ / MariaDB 10.3+, InnoDB, utf8mb4). Applied by the installer.

CREATE TABLE IF NOT EXISTS settings (
  k VARCHAR(80) NOT NULL PRIMARY KEY,
  v MEDIUMTEXT NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admins (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'staff',
  password_hash VARCHAR(255) NOT NULL,
  totp_secret TEXT NULL,
  totp_last_step BIGINT NOT NULL DEFAULT 0,
  recovery_codes TEXT NULL,
  failed_logins INT NOT NULL DEFAULT 0,
  locked_until DATETIME NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL,
  last_login_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sessions (
  id CHAR(64) NOT NULL PRIMARY KEY,
  data MEDIUMTEXT NOT NULL,
  updated_at DATETIME NOT NULL,
  KEY sessions_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limits (
  k CHAR(64) NOT NULL PRIMARY KEY,
  hits INT NOT NULL,
  reset_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(40) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  host VARCHAR(190) NULL UNIQUE,
  tagline VARCHAR(255) NOT NULL DEFAULT '',
  summary TEXT NOT NULL,
  body MEDIUMTEXT NOT NULL,
  accent CHAR(7) NOT NULL DEFAULT '#C8102E',
  licence_kind VARCHAR(20) NOT NULL DEFAULT 'manual',
  trial_note VARCHAR(255) NOT NULL DEFAULT '',
  status VARCHAR(20) NOT NULL DEFAULT 'draft',
  sort INT NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS editions (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  product_id INT UNSIGNED NOT NULL,
  ekey VARCHAR(40) NOT NULL,
  label VARCHAR(80) NOT NULL,
  blurb VARCHAR(255) NOT NULL DEFAULT '',
  price_usd_year INT NOT NULL DEFAULT 0,
  perpetual_multiple INT NOT NULL DEFAULT 3,
  max_domains INT NOT NULL DEFAULT 1,
  limits_json TEXT NOT NULL,
  features_json TEXT NOT NULL,
  quote_only TINYINT(1) NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  sort INT NOT NULL DEFAULT 0,
  UNIQUE KEY editions_product_key (product_id, ekey),
  CONSTRAINT editions_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(60) NOT NULL UNIQUE,
  title VARCHAR(160) NOT NULL,
  body MEDIUMTEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'published',
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS licences (
  id VARCHAR(40) NOT NULL PRIMARY KEY,
  product_id INT UNSIGNED NOT NULL,
  customer_name VARCHAR(160) NOT NULL,
  customer_email VARCHAR(190) NOT NULL,
  customer_country CHAR(2) NULL,
  edition VARCHAR(40) NOT NULL,
  term VARCHAR(20) NOT NULL,
  domains_json TEXT NOT NULL,
  limits_json TEXT NOT NULL,
  offline TINYINT(1) NOT NULL DEFAULT 0,
  issued_at DATETIME NOT NULL,
  expires_at DATETIME NULL,
  updates_until DATETIME NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  revoked_reason VARCHAR(255) NULL,
  token TEXT NOT NULL,
  installation_id VARCHAR(26) NULL,
  bound_at DATETIME NULL,
  last_check_in_at DATETIME NULL,
  last_hosts_json TEXT NULL,
  last_version VARCHAR(30) NULL,
  last_usage_json TEXT NULL,
  check_ins INT NOT NULL DEFAULT 0,
  reminded_at DATETIME NULL,
  notes VARCHAR(500) NULL,
  created_at DATETIME NOT NULL,
  KEY licences_email (customer_email),
  KEY licences_expires (expires_at),
  CONSTRAINT licences_product FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orders (
  id VARCHAR(26) NOT NULL PRIMARY KEY,
  ref CHAR(32) NOT NULL UNIQUE,
  product_id INT UNSIGNED NOT NULL,
  edition VARCHAR(40) NOT NULL,
  term VARCHAR(20) NOT NULL,
  domains_json TEXT NOT NULL,
  customer_name VARCHAR(160) NOT NULL,
  customer_email VARCHAR(190) NOT NULL,
  customer_country CHAR(2) NULL,
  company_tax_id VARCHAR(40) NULL,
  currency CHAR(3) NOT NULL,
  net_minor BIGINT NOT NULL,
  vat_minor BIGINT NOT NULL,
  total_minor BIGINT NOT NULL,
  provider VARCHAR(20) NOT NULL,
  provider_session VARCHAR(190) NULL,
  provider_reference VARCHAR(190) NULL,
  checkout_url TEXT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  failure_reason VARCHAR(255) NULL,
  test_mode TINYINT(1) NOT NULL DEFAULT 0,
  renews_licence_id VARCHAR(40) NULL,
  licence_id VARCHAR(40) NULL,
  receipt_number VARCHAR(30) NULL UNIQUE,
  ip_hash CHAR(32) NULL,
  created_at DATETIME NOT NULL,
  paid_at DATETIME NULL,
  fulfilled_at DATETIME NULL,
  checked_at DATETIME NULL,
  KEY orders_status (status, created_at),
  KEY orders_session (provider, provider_session),
  KEY orders_email (customer_email),
  CONSTRAINT orders_product FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payment_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  provider VARCHAR(20) NOT NULL,
  event_key VARCHAR(190) NOT NULL,
  type VARCHAR(80) NOT NULL,
  order_id VARCHAR(26) NULL,
  outcome VARCHAR(30) NOT NULL,
  detail VARCHAR(255) NULL,
  created_at DATETIME NOT NULL,
  UNIQUE KEY payment_events_key (provider, event_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS enquiries (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  product_id INT UNSIGNED NULL,
  kind VARCHAR(20) NOT NULL DEFAULT 'contact',
  name VARCHAR(160) NOT NULL,
  email VARCHAR(190) NOT NULL,
  organisation VARCHAR(190) NOT NULL DEFAULT '',
  country CHAR(2) NULL,
  phone VARCHAR(40) NOT NULL DEFAULT '',
  message TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'new',
  ip_hash CHAR(32) NULL,
  created_at DATETIME NOT NULL,
  KEY enquiries_status (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS counters (
  name VARCHAR(40) NOT NULL PRIMARY KEY,
  value BIGINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_log (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  created_at DATETIME NOT NULL,
  actor VARCHAR(190) NULL,
  action VARCHAR(80) NOT NULL,
  subject VARCHAR(190) NULL,
  data TEXT NOT NULL,
  prev_hash CHAR(64) NOT NULL,
  hash CHAR(64) NOT NULL,
  KEY audit_action (action, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS mail_log (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  to_email VARCHAR(190) NOT NULL,
  subject VARCHAR(255) NOT NULL,
  ok TINYINT(1) NOT NULL,
  error VARCHAR(255) NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
