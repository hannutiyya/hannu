<?php

declare(strict_types=1);

namespace Sham;

/**
 * "Install on your server" from the customer's account: one line to paste on a fresh Ubuntu 24.04 server,
 *   curl -fsSL https://licensing.sham.et/install/<code> | sudo bash
 * The code is signed and lasts 24 hours. The script it returns downloads the newest release the licence may have,
 * checks its SHA-256, and runs infra/install.sh with the answers given in the account (host, administrator,
 * organisation, licence key), so nothing is typed on the server.
 */
final class ServerInstall
{
    public const TTL = 86400;

    /** @param array<string, mixed> $licence @return array<string, string>|string answers, or an error */
    public static function answers(array $licence, string $host, string $email, string $org): array|string
    {
        $host = strtolower(trim($host));
        $email = strtolower(trim($email));
        $org = trim((string) preg_replace('/\s+/', ' ', $org));
        if (preg_match('/^(?=.{3,190}$)([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/', $host) !== 1) {
            return 'Enter the web address of the news site, such as news.example.com.';
        }
        $domains = array_map('strtolower', json_in((string) $licence['domains_json']));
        $ok = false;
        foreach ($domains as $d) {
            $d = ltrim((string) $d, '*.');
            $ok = $ok || $host === $d || str_ends_with($host, '.'.$d);
        }
        if ($domains !== [] && ! $ok) {
            return 'This licence is for '.implode(', ', $domains).'. Use one of these addresses.';
        }
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false || preg_match('/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/', $email) !== 1) {
            return 'Enter the e-mail address of the first administrator.';
        }
        if (preg_match('/^[\p{L}\p{N} .,&()\'-]{2,120}$/u', $org) !== 1) {
            return 'Enter the name of the organisation (letters, digits and . , & ( ) \' -).';
        }

        return ['l' => (string) $licence['id'], 'h' => $host, 'a' => $email, 'o' => $org];
    }

    /** @param array<string, string> $answers */
    public static function code(array $answers): string
    {
        $p = b64url(json_out($answers + ['e' => time() + self::TTL]));

        return $p.'.'.b64url(substr(hash_hmac('sha256', $p, Config::key('server-install'), true), 0, 20));
    }

    /** @return array<string, mixed>|null */
    public static function read(string $code): ?array
    {
        [$p, $sig] = array_pad(explode('.', $code, 2), 2, '');
        if ($p === '' || ! hash_equals(b64url(substr(hash_hmac('sha256', $p, Config::key('server-install'), true), 0, 20)), $sig)) {
            return null;
        }
        $d = json_in(unb64url($p));

        return is_int($d['e'] ?? null) && $d['e'] >= time() && is_string($d['l'] ?? null) ? $d : null;
    }

    public static function command(string $code): string
    {
        return 'curl -fsSL '.Config::url('licensing', '/install/'.$code).' | sudo bash';
    }

    /** The script, or a script that explains why it cannot run. */
    public static function script(array $d): string
    {
        $lic = Db::one('SELECT * FROM licences WHERE id = ?', [$d['l']]);
        $product = $lic !== null ? Db::one('SELECT * FROM products WHERE id = ?', [$lic['product_id']]) : null;
        $rel = $product !== null ? Content::latest((int) $product['id']) : null;
        if ($lic === null || $rel === null || ! Content::entitled($rel, $lic) || ($rel['file_path'] === null && $rel['external_url'] === null)) {
            return self::fail('No release is available for this licence right now. Check the licence in your account at '.Config::url('store', '/account').'.');
        }
        $url = $rel['file_path'] !== null ? Config::url('licensing', '/dl/'.Content::downloadToken((int) $rel['id'], (string) $lic['id'], self::TTL)) : (string) $rel['external_url'];
        $q = fn (string $v): string => "'".str_replace("'", "'\\''", $v)."'";
        $sha = (string) ($rel['sha256'] ?? '');
        $version = preg_replace('/[^0-9A-Za-z.+-]/', '', (string) $rel['version']);

        return "#!/usr/bin/env bash\n"
            ."# Sham MediaOS {$version} for {$d['h']}, prepared ".gmdate('Y-m-d H:i')." UTC from the account of licence {$lic['id']}.\n"
            ."# It downloads the release, checks it, and runs infra/install.sh with the answers given in the account.\n"
            ."set -Eeuo pipefail\n"
            ."trap 'echo \"install: stopped at line \$LINENO. Fix the cause and paste the same command again (valid 24 hours).\" >&2' ERR\n"
            ."[ \"\$(id -u)\" = 0 ] || { echo 'Run it with sudo.' >&2; exit 1; }\n"
            .". /etc/os-release 2>/dev/null || true\n"
            ."if [ \"\${ID:-}\" != ubuntu ] || [ \"\${VERSION_ID:-}\" != 24.04 ]; then echo 'This installer is made for Ubuntu 24.04 LTS on a fresh server.' >&2; exit 1; fi\n"
            ."export DEBIAN_FRONTEND=noninteractive\n"
            ."command -v unzip >/dev/null && command -v curl >/dev/null || { apt-get update -qq && apt-get install -y -qq curl unzip ca-certificates >/dev/null; }\n"
            ."DIR=/opt/sham-mediaos/{$version}\n"
            ."ZIP=\$(mktemp /tmp/sham-mediaos.XXXXXX.zip)\n"
            ."echo '==> downloading Sham MediaOS {$version}'\n"
            ."curl -fsSL --retry 3 -o \"\$ZIP\" ".$q($url)."\n"
            .($sha !== '' ? "echo '{$sha}  '\"\$ZIP\" | sha256sum -c --quiet - || { echo 'The download is damaged (checksum).' >&2; exit 1; }\n" : '')
            ."mkdir -p \"\$DIR\" && unzip -q -o \"\$ZIP\" -d \"\$DIR\" && rm -f \"\$ZIP\"\n"
            ."INSTALL=\$(find \"\$DIR\" -maxdepth 4 -path '*/infra/install.sh' | head -1)\n"
            ."[ -n \"\$INSTALL\" ] || { echo 'infra/install.sh is not in the package.' >&2; exit 1; }\n"
            ."export JMN_WEB_HOST=".$q($d['h'])." JMN_ADMIN_EMAIL=".$q($d['a'])." JMN_ORG_NAME=".$q($d['o'])." JMN_LICENCE_KEY=".$q((string) $lic['token'])."\n"
            ."exec bash \"\$INSTALL\"\n";
    }

    private static function fail(string $msg): string
    {
        return "#!/usr/bin/env bash\necho ".escapeshellarg($msg)." >&2\nexit 1\n";
    }
}
