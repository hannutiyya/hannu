<?php

declare(strict_types=1);

namespace Sham\Http;

use Sham\Config;

final class Response
{
    /** @var array<string, string> */
    public array $headers = [];

    public function __construct(public string $body = '', public int $status = 200, array $headers = [])
    {
        $this->headers = $headers + ['Content-Type' => 'text/html; charset=utf-8'];
    }

    public static function html(string $html, int $status = 200): self
    {
        return new self($html, $status);
    }

    /** @param array<mixed> $data */
    public static function json(array $data, int $status = 200): self
    {
        return new self(json_out($data), $status, ['Content-Type' => 'application/json; charset=utf-8', 'Cache-Control' => 'no-store']);
    }

    public static function redirect(string $to, int $status = 303): self
    {
        // Only our own paths or our own hosts.
        if (! str_starts_with($to, '/') || str_starts_with($to, '//')) {
            $host = strtolower((string) parse_url($to, PHP_URL_HOST));
            if (! in_array($host, Hosts::all(), true)) {
                $to = '/';
            }
        }

        return new self('', $status, ['Location' => $to]);
    }

    /** External redirect to a payment provider's https page (already validated by the gateway). */
    /** Streams a file from disk (media, downloads). @param array<string, string> $headers */
    public static function file(string $path, array $headers): self
    {
        $r = new self('', 200, $headers);
        $r->file = $path;

        return $r;
    }

    public ?string $file = null;

    public static function away(string $url): self
    {
        if (! str_starts_with($url, 'https://') && ! Config::local()) {
            return self::html('Bad payment link.', 502);
        }

        return new self('', 303, ['Location' => $url, 'Cache-Control' => 'no-store']);
    }

    public function header(string $k, string $v): self
    {
        $this->headers[$k] = $v;

        return $this;
    }

    public function send(string $nonce): void
    {
        http_response_code($this->status);
        $sec = [
            'X-Content-Type-Options' => 'nosniff',
            'X-Frame-Options' => 'DENY',
            'Referrer-Policy' => 'strict-origin-when-cross-origin',
            'Permissions-Policy' => 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()',
            'Cross-Origin-Opener-Policy' => 'same-origin',
            'Cross-Origin-Resource-Policy' => 'same-origin',
            'Content-Security-Policy' => "default-src 'none'; script-src 'self' 'nonce-{$nonce}'; style-src 'self'; img-src 'self' data:; font-src 'self'; "
                ."connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'; manifest-src 'self'",
        ];
        if (Config::get('scheme') === 'https') {
            $sec['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
        }
        foreach (array_merge($sec, $this->headers) as $k => $v) {
            header($k.': '.str_replace(["\r", "\n"], '', $v));
        }
        header_remove('X-Powered-By');
        if ($this->file !== null) {
            if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'HEAD') {
                while (ob_get_level() > 0) {
                    ob_end_clean();
                }
                readfile($this->file);
            }

            return;
        }
        echo $this->body;
    }
}
