<?php

declare(strict_types=1);

namespace Sham\Http;

use Sham\Config;
use Sham\Db;

/**
 * Which site a host name serves: the company site (sham.et, www.sham.et), the store and admin (store.sham.et), the
 * licence server (licensing.sham.et) or a product site (media.sham.et, taligaa.sham.et … from the products table).
 */
final class Hosts
{
    /** @var array<string, array{site: string, product: array<string, mixed>|null}>|null */
    private static ?array $map = null;

    /** @return array{site: string, product: array<string, mixed>|null}|null */
    public static function resolve(string $host): ?array
    {
        return self::map()[strtolower($host)] ?? null;
    }

    /** @return list<string> */
    public static function all(): array
    {
        return array_keys(self::map());
    }

    public static function reset(): void
    {
        self::$map = null;
    }

    /** @return array<string, array{site: string, product: array<string, mixed>|null}> */
    private static function map(): array
    {
        if (self::$map !== null) {
            return self::$map;
        }
        $company = Config::host('company');
        $m = [
            $company => ['site' => 'company', 'product' => null],
            'www.'.$company => ['site' => 'www', 'product' => null],
            Config::host('store') => ['site' => 'store', 'product' => null],
            Config::host('licensing') => ['site' => 'licensing', 'product' => null],
        ];
        if (Config::installed()) {
            try {
                foreach (Db::all("SELECT * FROM products WHERE host IS NOT NULL AND host <> '' AND status = 'published'") as $p) {
                    $m[strtolower((string) $p['host'])] ??= ['site' => 'product', 'product' => $p];
                }
            } catch (\Throwable) {
                // Database not ready: the core sites still answer.
            }
        }

        return self::$map = $m;
    }
}
