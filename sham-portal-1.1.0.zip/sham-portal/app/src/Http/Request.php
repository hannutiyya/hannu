<?php

declare(strict_types=1);

namespace Sham\Http;

use Sham\Config;

final class Request
{
    /**
     * @param  array<string, mixed>  $query
     * @param  array<string, mixed>  $post
     * @param  array<string, string>  $headers  lower-cased names
     * @param  array<string, string>  $cookies
     */
    public function __construct(
        public readonly string $method,
        public readonly string $host,
        public readonly string $path,
        public readonly array $query,
        public readonly array $post,
        public readonly array $headers,
        public readonly array $cookies,
        public readonly string $body,
        public readonly string $remoteAddr,
    ) {}

    public static function fromGlobals(): self
    {
        $headers = [];
        foreach ($_SERVER as $k => $v) {
            if (str_starts_with((string) $k, 'HTTP_')) {
                $headers[strtolower(str_replace('_', '-', substr((string) $k, 5)))] = (string) $v;
            }
        }
        if (isset($_SERVER['CONTENT_TYPE'])) {
            $headers['content-type'] = (string) $_SERVER['CONTENT_TYPE'];
        }
        $uri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
        $path = rawurldecode((string) parse_url($uri, PHP_URL_PATH));
        $host = strtolower((string) preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? '')));
        $body = (string) file_get_contents('php://input', false, null, 0, 1048576);

        // HEAD is answered as GET; the web server drops the body.
        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

        return new self($method === 'HEAD' ? 'GET' : $method, $host, $path === '' ? '/' : $path,
            $_GET, $_POST, $headers, array_map('strval', $_COOKIE), $body, (string) ($_SERVER['REMOTE_ADDR'] ?? ''));
    }

    public function input(string $key, string $default = ''): string
    {
        $v = $this->post[$key] ?? $this->query[$key] ?? $default;

        return is_string($v) ? $v : $default;
    }

    public function q(string $key, string $default = ''): string
    {
        $v = $this->query[$key] ?? $default;

        return is_string($v) ? $v : $default;
    }

    /** @return list<string> */
    public function list(string $key): array
    {
        $v = $this->post[$key] ?? [];
        if (is_string($v)) {
            $v = preg_split('/[\s,]+/', $v) ?: [];
        }

        return array_values(array_filter(array_map(fn ($x) => is_string($x) ? trim($x) : '', (array) $v), fn ($x) => $x !== ''));
    }

    public function header(string $name): string
    {
        return $this->headers[strtolower($name)] ?? '';
    }

    /** @return array<string, mixed> */
    public function json(): array
    {
        $v = json_decode($this->body, true);

        return is_array($v) ? $v : [];
    }

    /** Client address; proxy headers only from configured proxies (or Cloudflare when switched on). */
    public function ip(): string
    {
        $remote = $this->remoteAddr;
        $trusted = (array) Config::get('trusted_proxies', []);
        if (in_array($remote, $trusted, true) || (Config::get('cloudflare') && self::isCloudflare($remote))) {
            $cf = $this->header('cf-connecting-ip');
            if ($cf !== '' && filter_var($cf, FILTER_VALIDATE_IP)) {
                return $cf;
            }
            $xff = trim(explode(',', $this->header('x-forwarded-for'))[0] ?? '');
            if ($xff !== '' && filter_var($xff, FILTER_VALIDATE_IP)) {
                return $xff;
            }
        }

        return $remote;
    }

    public function isPost(): bool
    {
        return $this->method === 'POST';
    }

    private static function isCloudflare(string $ip): bool
    {
        $ranges = ['173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22', '141.101.64.0/18', '108.162.192.0/18',
            '190.93.240.0/20', '188.114.96.0/20', '197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
            '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22'];
        if (! filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return false;
        }
        $n = ip2long($ip);
        foreach ($ranges as $r) {
            [$net, $bits] = explode('/', $r);
            $mask = -1 << (32 - (int) $bits);
            if (($n & $mask) === (ip2long($net) & $mask)) {
                return true;
            }
        }

        return false;
    }
}
