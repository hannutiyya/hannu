<?php

declare(strict_types=1);

namespace Sham;

/**
 * Release files. Small ones can be uploaded in the admin; large ones (a full platform archive is gigabytes) are put in
 * app/storage/releases/incoming with the hosting File Manager or FTP and picked from a list. Files live outside the web
 * root and are only served through signed, expiring links.
 */
final class Releases
{
    public static function dir(string $sub = ''): string
    {
        $d = SHAM_APP.'/storage/releases'.($sub !== '' ? '/'.$sub : '');
        if (! is_dir($d)) {
            @mkdir($d, 0700, true);
        }

        return $d;
    }

    public static function path(string $stored): string
    {
        return self::dir().'/'.basename($stored);
    }

    /** @return list<array{name: string, bytes: int, modified: int}> files waiting in incoming/ */
    public static function incoming(): array
    {
        $out = [];
        foreach (glob(self::dir('incoming').'/*') ?: [] as $f) {
            if (is_file($f) && ! str_starts_with(basename($f), '.')) {
                $out[] = ['name' => basename($f), 'bytes' => (int) filesize($f), 'modified' => (int) filemtime($f)];
            }
        }

        return $out;
    }

    /**
     * Moves a file (an upload or one from incoming/) into the store and fills file_path, file_name, file_bytes, sha256.
     *
     * @return array{file_path: string, file_name: string, file_bytes: int, sha256: string}
     */
    public static function adopt(string $source, string $originalName, bool $isUpload): array
    {
        $name = Media::cleanName($originalName);
        if (! preg_match('/\.(zip|tar\.gz|tgz|gz|apk|aab|ipa|msix|exe|dmg|pkg|deb|sig|txt|pdf)$/i', $name)) {
            throw new \InvalidArgumentException('Release files must be archives or installers (zip, tar.gz, apk, aab, ipa, msix, exe, dmg, pkg, deb), a signature or a text file.');
        }
        $stored = strtolower(substr(ulid(), 0, 20)).'-'.$name;
        $dest = self::path($stored);
        $ok = $isUpload ? move_uploaded_file($source, $dest) : @rename($source, $dest);
        if (! $ok) {
            throw new \InvalidArgumentException('The file could not be moved into app/storage/releases. Check that the folder is writable.');
        }
        @chmod($dest, 0600);

        return ['file_path' => $stored, 'file_name' => $name, 'file_bytes' => (int) filesize($dest), 'sha256' => (string) hash_file('sha256', $dest)];
    }

    public static function incomingPath(string $name): ?string
    {
        $f = self::dir('incoming').'/'.basename($name);

        return is_file($f) && basename($name) === $name ? $f : null;
    }
}
