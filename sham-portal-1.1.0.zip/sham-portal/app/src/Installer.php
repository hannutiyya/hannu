<?php

declare(strict_types=1);

namespace Sham;

use PDO;
use Sham\Security\Guard;

/**
 * The installation itself, shared by the browser installer (/install with the token) and the one-file setup wizard
 * (sham-setup.php): check the answers, create the tables, the first content and the owner, and write app/config.php.
 */
final class Installer
{
    public const HOST_KEYS = ['company', 'store', 'licensing', 'media', 'taligaa'];

    /** @return array<string, string> the form fields with their defaults for a request to $host */
    public static function defaults(string $host): array
    {
        $host = strtolower((string) preg_replace('/:\d+$/', '', $host));
        $base = (string) preg_replace('/^(www|store|licensing|media|taligaa)\./', '', $host);
        $base = $base !== '' && $base !== 'localhost' && filter_var($base, FILTER_VALIDATE_IP) === false ? $base : 'sham.et';

        return [
            'db_host' => 'localhost', 'db_port' => '3306', 'db_name' => '', 'db_user' => '', 'db_socket' => '',
            'company' => $base, 'store' => 'store.'.$base, 'licensing' => 'licensing.'.$base, 'media' => 'media.'.$base,
            'taligaa' => 'taligaa.'.$base, 'cloudflare' => '', 'name' => '', 'email' => '', 'company_name' => 'Sham Software Systems Development General Trading PLC',
        ];
    }

    /**
     * @param array<string, string> $f trimmed answers
     * @param bool $dbChecks false when the database is created by the wizard itself
     * @return array<string, string> errors by field
     */
    public static function validate(array &$f, string $password, string $password2, bool $dbChecks = true): array
    {
        $errors = [];
        if ($dbChecks) {
            if (! in_array(strtolower($f['db_host']), ['localhost', '127.0.0.1', '::1'], true) && $f['db_socket'] === '') {
                $errors['db_host'] = 'For safety the database must be on this server (localhost or 127.0.0.1).';
            }
            if (preg_match('/^[A-Za-z0-9_]{1,64}$/', $f['db_name']) !== 1) {
                $errors['db_name'] = 'Use the database name from your hosting panel (letters, digits and _).';
            }
            if ($f['db_user'] === '' || strlen($f['db_user']) > 80) {
                $errors['db_user'] = 'Enter the database user.';
            }
            if ($f['db_socket'] !== '' && preg_match('#^/[A-Za-z0-9_./-]+$#', $f['db_socket']) !== 1) {
                $errors['db_socket'] = 'Enter a full socket path, or leave it empty.';
            }
        }
        $base = $f['company'];
        foreach (self::HOST_KEYS as $k) {
            $f[$k] = strtolower($f[$k]);
            if (preg_match('/^(?=.{3,190}$)([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/', $f[$k]) !== 1) {
                $errors[$k] = 'Enter a host name such as '.($k === 'company' ? 'sham.et' : $k.'.'.$base).'.';
            }
        }
        $hosts = array_map(fn ($k) => $f[$k], self::HOST_KEYS);
        if (count(array_unique($hosts)) !== count($hosts)) {
            $errors['taligaa'] = 'Each site needs its own host name.';
        }
        if ($f['name'] === '' || mb_strlen($f['name']) > 120) {
            $errors['name'] = 'Enter your name.';
        }
        if (filter_var($f['email'], FILTER_VALIDATE_EMAIL) === false) {
            $errors['email'] = 'Enter a valid e-mail address.';
        }
        if (($weak = Guard::weakPassword($password, $f['email'])) !== null) {
            $errors['password'] = $weak;
        }
        if ($password !== $password2) {
            $errors['password2'] = 'The two passwords are not the same.';
        }
        if (mb_strlen($f['company_name']) < 2 || mb_strlen($f['company_name']) > 190) {
            $errors['company_name'] = 'Enter the company name.';
        }

        return $errors;
    }

    /** @param array<string, string> $f */
    public static function dsn(array $f): string
    {
        return $f['db_socket'] !== ''
            ? 'mysql:unix_socket='.$f['db_socket'].';dbname='.$f['db_name'].';charset=utf8mb4'
            : 'mysql:host='.$f['db_host'].';port='.(int) $f['db_port'].';dbname='.$f['db_name'].';charset=utf8mb4';
    }

    /** Whether this database already holds a portal with administrators (then it must not be installed over). */
    public static function occupied(PDO $pdo): bool
    {
        $existing = (int) $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'admins'")->fetchColumn();

        return $existing > 0 && (int) $pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn() > 0;
    }

    /**
     * Creates everything and writes the configuration file. Throws on failure; nothing is written to config.php
     * before the database is complete, so a failed run can simply be repeated.
     *
     * @param array<string, string> $f validated answers
     * @param array<string, mixed> $extra more configuration (for example 'public_dirs')
     * @return array<string, mixed> the configuration written
     */
    public static function install(PDO $pdo, array $f, string $dbPass, string $password, string $configPath, array $extra = []): array
    {
        $config = [
            'installed' => true, 'env' => 'production', 'app_secret' => base64_encode(random_bytes(32)),
            'db' => ['host' => $f['db_host'], 'port' => (int) $f['db_port'], 'name' => $f['db_name'], 'user' => $f['db_user'], 'pass' => $dbPass, 'socket' => $f['db_socket']],
            'hosts' => ['company' => $f['company'], 'store' => $f['store'], 'licensing' => $f['licensing']],
            'scheme' => 'https', 'secure_cookies' => true, 'trusted_proxies' => [], 'cloudflare' => ($f['cloudflare'] ?? '') === '1',
        ] + $extra;
        Db::use($pdo);
        Config::set($config);
        Migrator::run($pdo);
        Settings::flush();
        Settings::set('system.schema', SHAM_VERSION.'/'.implode(',', Migrator::available()));
        Seed::run($f['media'], $f['taligaa']);
        Settings::set('company.name', $f['company_name']);
        Db::insert('admins', ['email' => strtolower($f['email']), 'name' => $f['name'], 'role' => 'owner',
            'password_hash' => Guard::hashPassword($password), 'created_at' => now_utc()]);
        Audit::log('install.completed', strtolower($f['email']), null, ['version' => SHAM_VERSION, 'hosts' => array_map(fn ($k) => $f[$k], self::HOST_KEYS)]);
        Config::write($configPath, $config);

        return $config;
    }
}
