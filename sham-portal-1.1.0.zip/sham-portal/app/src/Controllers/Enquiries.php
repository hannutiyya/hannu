<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\Audit;
use Sham\Config;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Security\Guard;
use Sham\Settings;
use Sham\Store\Notifier;
use Sham\View;

/** Contact, demo and quotation requests from every site. Honeypot field, timing check and rate limit against spam. */
final class Enquiries
{
    /** @param array<string, mixed>|null $product */
    public static function form(Request $r, ?array $product, string $site, string $kind = 'contact'): Response
    {
        $vars = ['product' => $product, 'site' => $site, 'title' => $kind === 'quote' ? 'Ask for a quotation' : 'Contact us', 'kind' => $kind,
            'errors' => [], 'old' => [], 'sent' => false, 'accent' => $product['accent'] ?? null, 'products' => \Sham\Store\Catalogue::products(),
            'edition' => $r->q('edition'), 'stamp' => self::stamp()];
        if (! $r->isPost()) {
            return Response::html(View::render('contact', $vars));
        }
        $old = ['name' => str_limit($r->input('name'), 160), 'email' => mb_strtolower(trim($r->input('email'))), 'organisation' => str_limit($r->input('organisation'), 190),
            'country' => strtoupper(trim($r->input('country'))), 'phone' => str_limit($r->input('phone'), 40), 'message' => str_limit($r->input('message'), 5000),
            'product' => $r->input('product')];
        $errors = [];
        if (mb_strlen($old['name']) < 2) {
            $errors['name'] = 'Enter your name.';
        }
        if (! filter_var($old['email'], FILTER_VALIDATE_EMAIL) || strlen($old['email']) > 190) {
            $errors['email'] = 'Enter a valid e-mail address.';
        }
        if (mb_strlen($old['message']) < 10) {
            $errors['message'] = 'Tell us a little more (at least 10 characters).';
        }
        $bot = $r->input('website') !== '' || ! self::stampOk($r->input('stamp'));
        if ($errors !== []) {
            return Response::html(View::render('contact', ['errors' => $errors, 'old' => $old] + $vars), 422);
        }
        if (! Guard::hit('enquiry', $r->ip(), 5, 3600)) {
            return Response::html(View::render('contact', ['errors' => ['message' => 'You have sent several messages already. Please write to '
                .Settings::get('company.sales_email').' instead.'], 'old' => $old] + $vars), 429);
        }
        if (! $bot) {
            $pid = $product['id'] ?? null;
            if ($pid === null && $old['product'] !== '') {
                $pid = Db::value("SELECT id FROM products WHERE slug = ? AND status = 'published'", [$old['product']]);
            }
            Db::insert('enquiries', ['product_id' => $pid, 'kind' => in_array($kind, ['contact', 'quote', 'demo'], true) ? $kind : 'contact',
                'name' => $old['name'], 'email' => $old['email'], 'organisation' => $old['organisation'],
                'country' => preg_match('/^[A-Z]{2}$/', $old['country']) === 1 ? $old['country'] : null, 'phone' => $old['phone'],
                'message' => ($r->q('edition') !== '' ? '[Edition: '.str_limit($r->q('edition'), 40)."]\n" : '').$old['message'],
                'ip_hash' => Guard::ipHash($r->ip()), 'created_at' => now_utc()]);
            Audit::log('enquiry.received', 'visitor', (string) Db::pdo()->lastInsertId(), ['kind' => $kind, 'product' => $pid]);
            Notifier::staff(ucfirst($kind).' from '.$old['name'], "{$old['name']} <{$old['email']}> ({$old['organisation']}, {$old['country']}) wrote:\n\n{$old['message']}");
        }

        return Response::html(View::render('contact', ['sent' => true] + $vars));
    }

    /** A signed timestamp: forms posted within 3 seconds of being shown, or after a day, are treated as bots. */
    private static function stamp(): string
    {
        $t = (string) time();

        return $t.'.'.substr(hash_hmac('sha256', $t, Config::key('form-stamp')), 0, 16);
    }

    private static function stampOk(string $s): bool
    {
        [$t, $sig] = array_pad(explode('.', $s, 2), 2, '');
        if (! ctype_digit($t) || ! hash_equals(substr(hash_hmac('sha256', $t, Config::key('form-stamp')), 0, 16), $sig)) {
            return false;
        }
        $age = time() - (int) $t;

        return $age >= 3 && $age <= 86400;
    }
}
