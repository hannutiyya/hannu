<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\Audit;
use Sham\Config;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Mailer;
use Sham\Security\Guard;
use Sham\Settings;
use Sham\Store\Catalogue;
use Sham\View;

/** News by e-mail: double opt-in subscription, one-click unsubscribe. */
final class Subscriptions
{
    public static function subscribe(Request $r): Response
    {
        $email = mb_strtolower(trim($r->input('email')));
        $msg = 'Check your inbox: we sent a link to confirm your subscription.';
        if ($r->input('website') !== '' || ! filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
            return self::done('Enter a valid e-mail address.', 422);
        }
        if (! Guard::hit('subscribe', $r->ip(), 5, 3600) || ! Guard::hit('subscribe-email', $email, 3, 86400)) {
            return self::done($msg);
        }
        $slugs = array_column(Catalogue::products(), 'slug');
        $want = array_values(array_intersect($r->list('products'), $slugs));
        $row = Db::one('SELECT * FROM subscribers WHERE email = ?', [$email]);
        $token = $row['token'] ?? bin2hex(random_bytes(16));
        if ($row === null) {
            Db::insert('subscribers', ['email' => $email, 'products_json' => json_out($want), 'token' => $token, 'ip_hash' => Guard::ipHash($r->ip()), 'created_at' => now_utc()]);
        } else {
            Db::update('subscribers', ['products_json' => json_out($want), 'unsubscribed_at' => null], ['id' => $row['id']]);
        }
        if ($row === null || $row['confirmed_at'] === null || $row['unsubscribed_at'] !== null) {
            Mailer::send($email, 'Confirm your subscription to '.Settings::get('company.short').' news',
                "Hello,\n\nSomeone (we hope you) asked to receive news and product updates from ".Settings::get('company.name')." at this address.\n\n"
                .'Confirm here: '.Config::url('company', '/subscribe/confirm/'.$token)."\n\nIf it was not you, ignore this message and nothing more will be sent.\n");
        }

        return self::done($msg);
    }

    public static function confirm(string $token): Response
    {
        $row = Db::one('SELECT * FROM subscribers WHERE token = ?', [$token]);
        if ($row === null) {
            return self::done('This link is not valid any more.', 404);
        }
        Db::update('subscribers', ['confirmed_at' => $row['confirmed_at'] ?? now_utc(), 'unsubscribed_at' => null], ['id' => $row['id']]);
        Audit::log('subscriber.confirmed', 'visitor', (string) $row['id']);

        return self::done('Thank you. You will receive our news and product updates. Every message has a link to stop them.');
    }

    /** The link in every e-mail opens a page with one button: link checkers in mail systems open links, people press buttons. */
    public static function unsubscribe(Request $r, string $token): Response
    {
        $row = Db::one('SELECT * FROM subscribers WHERE token = ?', [$token]);
        if (! $r->isPost()) {
            if ($row === null || $row['unsubscribed_at'] !== null) {
                return self::done('This address does not receive our news.');
            }

            return self::done('Stop receiving news and product updates at '.self::mask((string) $row['email']).'?', 200, '/unsubscribe/'.$token, 'Stop the e-mails');
        }
        if ($row !== null && $row['unsubscribed_at'] === null) {
            Db::update('subscribers', ['unsubscribed_at' => now_utc()], ['id' => $row['id']]);
            Audit::log('subscriber.unsubscribed', 'visitor', (string) $row['id']);
        }

        return self::done('You will not receive any more news from us. If this was a mistake, subscribe again on our news page.');
    }

    /** RFC 8058 one-click: the mail program POSTs List-Unsubscribe=One-Click; the token in the address is the authority. */
    public static function oneClick(Request $r, string $token): Response
    {
        if (! $r->isPost()) {
            return self::unsubscribe($r, $token);
        }
        $row = Db::one('SELECT * FROM subscribers WHERE token = ?', [$token]);
        if ($row !== null && $row['unsubscribed_at'] === null) {
            Db::update('subscribers', ['unsubscribed_at' => now_utc()], ['id' => $row['id']]);
            Audit::log('subscriber.unsubscribed', 'one-click', (string) $row['id']);
        }

        return new Response("Unsubscribed.\n", 200, ['Content-Type' => 'text/plain; charset=utf-8', 'Cache-Control' => 'no-store']);
    }

    private static function mask(string $email): string
    {
        [$u, $d] = array_pad(explode('@', $email, 2), 2, '');

        return mb_substr($u, 0, 2).str_repeat('•', max(1, min(6, mb_strlen($u) - 2))).'@'.$d;
    }

    /** Queue a published post for every confirmed subscriber who follows its product (or everything). */
    public static function queuePost(array $post, string $actor): int
    {
        $n = 0;
        $url = \Sham\Content::postUrl($post + ['product_host' => Db::value('SELECT host FROM products WHERE id = ?', [(int) ($post['product_id'] ?? 0)])]);
        $slug = $post['product_id'] !== null ? (string) Db::value('SELECT slug FROM products WHERE id = ?', [(int) $post['product_id']]) : null;
        foreach (Db::all('SELECT * FROM subscribers WHERE confirmed_at IS NOT NULL AND unsubscribed_at IS NULL') as $s) {
            $follows = json_in((string) $s['products_json']);
            if ($slug !== null && $follows !== [] && ! in_array($slug, $follows, true)) {
                continue;
            }
            $body = $post['title']."\n".str_repeat('=', min(70, mb_strlen((string) $post['title'])))."\n\n".($post['summary'] !== '' ? $post['summary']."\n\n" : '')
                .'Read more: '.$url."\n\n--\n".Settings::get('company.name')."\nStop these e-mails: ".Config::url('company', '/unsubscribe/'.$s['token'])."\n";
            Db::insert('mail_queue', ['to_email' => $s['email'], 'subject' => (string) $post['title'], 'body' => $body, 'reply_to' => Settings::get('company.sales_email'),
                'unsubscribe_url' => Config::url('company', '/unsubscribe/'.$s['token'].'/now'), 'created_at' => now_utc()]);
            $n++;
        }
        Db::update('posts', ['mailed_at' => now_utc()], ['id' => $post['id']]);
        Audit::log('post.mailed', $actor, (string) $post['slug'], ['recipients' => $n]);

        return $n;
    }

    private static function done(string $message, int $status = 200, ?string $action = null, string $button = ''): Response
    {
        return Response::html(View::render('notice', ['title' => 'News by e-mail', 'message' => $message, 'site' => 'company', 'action' => $action, 'button' => $button]), $status)
            ->header('Cache-Control', 'no-store')->header('X-Robots-Tag', 'noindex');
    }
}
