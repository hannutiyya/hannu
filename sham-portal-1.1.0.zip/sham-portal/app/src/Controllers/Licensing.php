<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\Audit;
use Sham\Content;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Licensing\CheckIn;
use Sham\Licensing\Codec;
use Sham\Security\Guard;

/**
 * licensing.sham.et, JSON only:
 *  POST /api/v1/licensing/check-in  daily licence check (signed CHK1 answer)
 *  POST /api/v1/updates/check       is there a newer release, and may this installation download it (signed UPD1 answer)
 *  GET  /api/v1/releases/{product}  public release list
 *  GET  /dl/{token}                 a release file, through a signed link that expires after an hour
 */
final class Licensing
{
    public static function handle(Request $r): Response
    {
        $p = rtrim($r->path, '/') ?: '/';
        if ($p === '/api/v1/licensing/check-in') {
            if (! $r->isPost()) {
                return Response::json(['message' => 'Method not allowed.'], 405)->header('Allow', 'POST');
            }
            if (! Guard::hit('checkin', $r->ip(), 30, 60)) {
                return Response::json(['message' => 'Too many requests.'], 429)->header('Retry-After', '60');
            }
            if (! Codec::available()) {
                return Response::json(['message' => 'The licence server is not configured.', 'code' => 'LICENSING_KEY_MISSING'], 503);
            }
            $in = CheckIn::validate(self::body($r));
            if (is_string($in)) {
                return Response::json(['message' => $in, 'code' => 'VALIDATION_FAILED'], 422);
            }

            return Response::json(['data' => ['answer' => CheckIn::answer($in)]]);
        }
        if ($p === '/api/v1/updates/check') {
            return self::updates($r);
        }
        if (preg_match('#^/api/v1/releases/([a-z0-9-]+)$#', $p, $m) === 1 && $r->method === 'GET') {
            return self::releases($m[1]);
        }
        if (preg_match('#^/dl/([A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)$#', $p, $m) === 1 && $r->method === 'GET') {
            return self::download($r, $m[1], 'update-api');
        }
        if (preg_match('#^/install/([A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)$#', $p, $m) === 1 && $r->method === 'GET') {
            $d = \Sham\ServerInstall::read($m[1]);
            $text = match (true) {
                ! Guard::hit('server-install-fetch', $r->ip(), 20, 3600) => "#!/usr/bin/env bash\necho 'Too many attempts. Try again in an hour.' >&2\nexit 1\n",
                $d === null => "#!/usr/bin/env bash\necho 'This install command has expired or is not valid. Make a new one in your account at ".\Sham\Config::url('store', '/account')."' >&2\nexit 1\n",
                default => \Sham\ServerInstall::script($d),
            };
            if ($d !== null) {
                Audit::log('licence.install_script_fetched', 'server', (string) $d['l'], ['host' => $d['h'], 'ip' => Guard::ipHash($r->ip())]);
            }

            return new Response($text, 200, ['Content-Type' => 'text/x-shellscript; charset=utf-8', 'Cache-Control' => 'no-store', 'X-Robots-Tag' => 'noindex']);
        }
        if ($p === '/' || $p === '/health') {
            return Response::json(['service' => 'Sham licence server', 'ok' => true, 'signing' => Codec::available()]);
        }

        return Response::json(['message' => 'Not found.'], 404);
    }

    private static function updates(Request $r): Response
    {
        if (! $r->isPost()) {
            return Response::json(['message' => 'Method not allowed.'], 405)->header('Allow', 'POST');
        }
        if (! Guard::hit('updates', $r->ip(), 30, 60)) {
            return Response::json(['message' => 'Too many requests.'], 429)->header('Retry-After', '60');
        }
        if (! Codec::available()) {
            return Response::json(['message' => 'The licence server is not configured.', 'code' => 'LICENSING_KEY_MISSING'], 503);
        }
        $b = self::body($r);
        $slug = is_string($b['product'] ?? null) ? $b['product'] : 'mediaos';
        $version = is_string($b['version'] ?? null) && preg_match('/^[0-9A-Za-z.+-]{1,40}$/', $b['version']) === 1 ? $b['version'] : '0';
        $channel = ($b['channel'] ?? 'stable') === 'beta' ? 'beta' : 'stable';
        $product = preg_match('/^[a-z0-9-]{1,40}$/', $slug) === 1 ? Db::one("SELECT * FROM products WHERE slug = ? AND status = 'published'", [$slug]) : null;
        if ($product === null) {
            return Response::json(['message' => 'Unknown product.', 'code' => 'VALIDATION_FAILED'], 422);
        }
        $licence = null;
        $id = $b['licence_id'] ?? null;
        $inst = $b['installation_id'] ?? null;
        if (is_string($id) && preg_match('/^LIC-[0-9A-Z]{26}$/', $id) === 1 && is_string($inst) && preg_match('/^[0-9A-Za-z]{26}$/', $inst) === 1) {
            $l = Db::one('SELECT * FROM licences WHERE id = ?', [$id]);
            // Only the installation the licence is bound to gets download links.
            $licence = $l !== null && hash_equals((string) $l['installation_id'], strtoupper($inst)) ? $l : null;
        }
        $latest = Content::latest((int) $product['id'], $channel);
        $payload = ['product' => $product['slug'], 'current' => $version, 'channel' => $channel, 'update_available' => false, 'latest' => null,
            'entitled' => false, 'download_url' => null, 'issued_at' => gmdate('Y-m-d\TH:i:s+00:00')];
        if ($latest !== null) {
            $payload['latest'] = ['version' => $latest['version'], 'released_at' => gmdate('Y-m-d\TH:i:s+00:00', (int) strtotime($latest['released_at'].' UTC')),
                'title' => $latest['title'], 'critical' => (bool) $latest['critical'], 'sha256' => $latest['sha256'], 'bytes' => $latest['file_bytes'] !== null ? (int) $latest['file_bytes'] : null,
                'notes_url' => Content::productUrl($product, '/releases').'#v'.rawurlencode((string) $latest['version'])];
            $payload['update_available'] = version_compare((string) $latest['version'], $version, '>');
            $payload['entitled'] = Content::entitled($latest, $licence);
            if ($payload['entitled'] && ($latest['file_path'] !== null || $latest['external_url'] !== null)) {
                $payload['download_url'] = \Sham\Config::url('licensing', '/dl/'.Content::downloadToken((int) $latest['id'], $licence['id'] ?? null));
            }
        }

        return Response::json(['data' => ['answer' => Codec::sign('UPD1', $payload), 'update' => $payload]]);
    }

    private static function releases(string $slug): Response
    {
        $product = Db::one("SELECT * FROM products WHERE slug = ? AND status = 'published'", [$slug]);
        if ($product === null) {
            return Response::json(['message' => 'Not found.'], 404);
        }
        $out = [];
        foreach (Content::releases((int) $product['id'], null, 30) as $rel) {
            $out[] = ['version' => $rel['version'], 'channel' => $rel['channel'], 'title' => $rel['title'], 'released_at' => gmdate('Y-m-d\TH:i:s+00:00', (int) strtotime($rel['released_at'].' UTC')),
                'critical' => (bool) $rel['critical'], 'access' => $rel['access'], 'sha256' => $rel['sha256']];
        }

        return Response::json(['data' => $out])->header('Cache-Control', 'public, max-age=300');
    }

    /** Serves a release file for a signed link (from the update API or the customer account). */
    public static function download(Request $r, string $token, string $via): Response
    {
        $t = Content::readDownloadToken($token);
        $rel = $t !== null ? Db::one('SELECT * FROM releases WHERE id = ?', [$t['r']]) : null;
        $lic = $t !== null && $t['l'] !== null ? Db::one('SELECT * FROM licences WHERE id = ?', [$t['l']]) : null;
        if ($rel === null || ! Content::entitled($rel, $lic)) {
            return Response::json(['message' => 'This download link is not valid or has expired.'], 403);
        }
        if (! Guard::hit('download', $r->ip(), 20, 3600)) {
            return Response::json(['message' => 'Too many downloads. Try again later.'], 429);
        }
        Db::insert('download_log', ['release_id' => $rel['id'], 'licence_id' => $lic['id'] ?? null, 'via' => $via, 'ip_hash' => Guard::ipHash($r->ip()), 'created_at' => now_utc()]);
        Db::run('UPDATE releases SET downloads = downloads + 1 WHERE id = ?', [$rel['id']]);
        if ($rel['file_path'] !== null && $rel['file_path'] !== '') {
            $file = \Sham\Releases::path((string) $rel['file_path']);
            if (! is_file($file)) {
                Audit::log('release.file_missing', 'system', (string) $rel['version']);

                return Response::json(['message' => 'The file is not available at the moment.'], 404);
            }

            return Response::file($file, ['Content-Type' => 'application/octet-stream', 'Content-Length' => (string) filesize($file), 'Cache-Control' => 'no-store',
                'Content-Disposition' => 'attachment; filename="'.str_replace('"', '', (string) $rel['file_name']).'"', 'X-Checksum-SHA256' => (string) $rel['sha256']]);
        }

        return Response::away((string) $rel['external_url']);
    }

    /** @return array<string, mixed> */
    private static function body(Request $r): array
    {
        return str_contains($r->header('content-type'), 'json') ? $r->json() : $r->post;
    }
}
