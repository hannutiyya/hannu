<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\App;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Payments\BankTransfer;
use Sham\Payments\Gateway;
use Sham\Payments\Registry;
use Sham\Security\Guard;
use Sham\Settings;
use Sham\Store\Catalogue;
use Sham\Store\Checkout;
use Sham\Store\CheckoutError;
use Sham\Store\Ledger;
use Sham\View;

/** store.sham.et: catalogue, buy, order status and receipt, renewals, quotations, downloads. */
final class Store
{
    public static function handle(Request $r): Response
    {
        $p = rtrim($r->path, '/') ?: '/';
        $get = $r->method === 'GET';

        return match (true) {
            $p === '/' && $get => self::home(),
            $p === '/account' || str_starts_with($p, '/account/') => Account::handle($r),
            preg_match('#^/buy/([a-z0-9-]+)$#', $p, $m) === 1 => self::buy($r, $m[1]),
            preg_match('#^/order/([a-f0-9]{32})$#', $p, $m) === 1 && $get => self::order($r, $m[1]),
            preg_match('#^/order/([a-f0-9]{32})/check$#', $p, $m) === 1 && $r->isPost() => self::check($r, $m[1]),
            preg_match('#^/order/([a-f0-9]{32})/pay$#', $p, $m) === 1 && $get => self::pay($m[1]),
            preg_match('#^/order/([a-f0-9]{32})/receipt$#', $p, $m) === 1 && $get => self::receipt($m[1]),
            $p === '/renew' => self::renew($r),
            preg_match('#^/quote/([a-z0-9-]+)$#', $p, $m) === 1 => self::quote($r, $m[1]),
            preg_match('#^/legal/([a-z0-9-]+)$#', $p, $m) === 1 && $get => Site::cmsPage($m[1], 'store'),
            $p === '/robots.txt' => new Response("User-agent: *\nDisallow: /order/\nDisallow: /admin\nDisallow: /account\n", 200, ['Content-Type' => 'text/plain']),
            default => App::error(404),
        };
    }

    private static function home(): Response
    {
        $items = [];
        foreach (Catalogue::products() as $p) {
            $items[] = ['product' => $p, 'editions' => Catalogue::editions((int) $p['id'])];
        }

        return Response::html(View::render('store/home', ['items' => $items, 'currencies' => Catalogue::currencies(), 'title' => 'Store', 'site' => 'store']));
    }

    private static function buy(Request $r, string $slug): Response
    {
        $product = Catalogue::product($slug);
        if ($product === null) {
            return App::error(404);
        }
        $editions = array_values(array_filter(Catalogue::editions((int) $product['id']), [Catalogue::class, 'sellable']));
        $currencies = Catalogue::currencies();
        $rails = [];
        foreach ($currencies as $c) {
            $rails[$c] = array_map(fn (Gateway $g) => ['key' => $g->key(), 'label' => $g->label()], Registry::forCurrency($c));
        }
        $vars = ['product' => $product, 'editions' => $editions, 'currencies' => $currencies, 'rails' => $rails, 'errors' => [],
            'old' => ['edition' => $r->q('edition', $editions[0]['ekey'] ?? ''), 'term' => $r->q('term', 'year'), 'currency' => $r->q('currency', $currencies[0] ?? 'USD')],
            'title' => 'Buy '.$product['name'], 'site' => 'store', 'accent' => $product['accent'], 'renewing' => null];
        if (! $r->isPost()) {
            return Response::html(View::render('store/buy', $vars));
        }
        $in = ['edition' => $r->input('edition'), 'term' => $r->input('term'), 'currency' => $r->input('currency'), 'provider' => $r->input('provider'),
            'domains' => $r->list('domains'), 'name' => $r->input('name'), 'email' => $r->input('email'), 'country' => $r->input('country'),
            'tax_id' => $r->input('tax_id'), 'phone' => $r->input('phone'), 'renews' => $r->input('renews'), 'accept_terms' => $r->input('accept_terms') === '1'];
        if (! Guard::hit('checkout', $r->ip(), 10, 600)) {
            return Response::html(View::render('store/buy', ['errors' => ['form' => 'Too many orders from your connection. Please wait ten minutes.'], 'old' => $in] + $vars), 429);
        }
        try {
            $res = Checkout::create($product, $in, $r->ip());
        } catch (CheckoutError $e) {
            if ($in['renews'] !== '') {
                $vars['renewing'] = Db::one('SELECT * FROM licences WHERE id = ?', [$in['renews']]);
            }

            return Response::html(View::render('store/buy', ['errors' => $e->errors, 'old' => $in] + $vars), 422);
        }

        return Response::redirect('/order/'.$res['order']['ref'].($res['url'] !== null ? '/pay' : ''));
    }

    /** An interstitial on our own domain, so the form never posts across origins (CSP form-action 'self'). */
    private static function pay(string $ref): Response
    {
        $o = Db::one('SELECT * FROM orders WHERE ref = ?', [$ref]);
        if ($o === null || $o['status'] !== 'pending' || ! is_string($o['checkout_url']) || $o['checkout_url'] === '') {
            return Response::redirect('/order/'.$ref);
        }
        $g = Registry::get((string) $o['provider']);

        return Response::html(View::render('store/pay', ['order' => $o, 'gateway' => $g?->label() ?? $o['provider'], 'title' => 'Continue to payment', 'site' => 'store']))
            ->header('Referrer-Policy', 'no-referrer')->header('Cache-Control', 'no-store');
    }

    private static function order(Request $r, string $ref): Response
    {
        $o = Db::one('SELECT * FROM orders WHERE ref = ?', [$ref]);
        if ($o === null) {
            return App::error(404);
        }
        // Coming back from the provider: read the result from its API now (rate limited), never from the redirect.
        if ($o['status'] === 'pending' && $o['provider'] !== 'bank' && Guard::hit('order-refresh', $ref, 20, 600)) {
            Ledger::refresh((string) $o['id']);
            $o = (array) Db::one('SELECT * FROM orders WHERE ref = ?', [$ref]);
        }

        return self::orderPage($o, $r->q('cancelled') === '1');
    }

    private static function check(Request $r, string $ref): Response
    {
        $o = Db::one('SELECT * FROM orders WHERE ref = ?', [$ref]);
        if ($o === null) {
            return App::error(404);
        }
        if (Guard::hit('order-check', $ref, 10, 600)) {
            Ledger::refresh((string) $o['id']);
        }

        return Response::redirect('/order/'.$ref);
    }

    /** @param array<string, mixed> $o */
    private static function orderPage(array $o, bool $cancelled): Response
    {
        $product = (array) Db::one('SELECT * FROM products WHERE id = ?', [(int) $o['product_id']]);
        $edition = Db::one('SELECT * FROM editions WHERE product_id = ? AND ekey = ?', [(int) $o['product_id'], (string) $o['edition']]);
        $licence = $o['licence_id'] !== null ? Db::one('SELECT * FROM licences WHERE id = ?', [$o['licence_id']]) : null;

        return Response::html(View::render('store/order', ['order' => $o, 'product' => $product, 'edition' => $edition, 'licence' => $licence, 'cancelled' => $cancelled,
            'bank' => $o['provider'] === 'bank' && $o['status'] === 'pending' ? BankTransfer::instructions($o) : null, 'title' => 'Your order', 'site' => 'store',
            'accent' => $product['accent'] ?? null]))
            ->header('Cache-Control', 'no-store')->header('Referrer-Policy', 'no-referrer')->header('X-Robots-Tag', 'noindex');
    }

    private static function receipt(string $ref): Response
    {
        $o = Db::one("SELECT * FROM orders WHERE ref = ? AND status IN ('paid', 'fulfilled', 'refunded')", [$ref]);
        if ($o === null) {
            return App::error(404);
        }
        $product = (array) Db::one('SELECT * FROM products WHERE id = ?', [(int) $o['product_id']]);
        $edition = Db::one('SELECT * FROM editions WHERE product_id = ? AND ekey = ?', [(int) $o['product_id'], (string) $o['edition']]);

        return Response::html(View::render('store/receipt', ['order' => $o, 'product' => $product, 'edition' => $edition, 'title' => 'Receipt '.$o['receipt_number'],
            'company' => ['name' => Settings::get('company.name'), 'address' => Settings::get('company.address'), 'tin' => Settings::get('company.tin'),
                'vat_no' => Settings::get('company.vat_no'), 'email' => Settings::get('company.sales_email'), 'phone' => Settings::get('company.phone')]], null))
            ->header('Cache-Control', 'no-store')->header('Referrer-Policy', 'no-referrer')->header('X-Robots-Tag', 'noindex');
    }

    private static function renew(Request $r): Response
    {
        $vars = ['title' => 'Renew a licence', 'site' => 'store', 'errors' => [], 'old' => ['licence' => $r->q('licence'), 'email' => '']];
        if (! $r->isPost()) {
            return Response::html(View::render('store/renew', $vars));
        }
        $id = strtoupper(trim($r->input('licence')));
        $email = mb_strtolower(trim($r->input('email')));
        $vars['old'] = ['licence' => $id, 'email' => $email];
        if (! Guard::hit('renew', $r->ip(), 10, 600)) {
            return Response::html(View::render('store/renew', ['errors' => ['licence' => 'Too many attempts. Please wait ten minutes.']] + $vars), 429);
        }
        $l = preg_match('/^LIC-[0-9A-Z]{26}$/', $id) === 1 ? Db::one("SELECT * FROM licences WHERE id = ? AND status = 'active'", [$id]) : null;
        if ($l === null || ! hash_equals((string) $l['customer_email'], $email)) {
            return Response::html(View::render('store/renew', ['errors' => ['licence' => 'We could not find an active licence with that ID and e-mail address.']] + $vars), 422);
        }
        $product = (array) Db::one('SELECT * FROM products WHERE id = ?', [(int) $l['product_id']]);
        $currencies = Catalogue::currencies();
        $rails = [];
        foreach ($currencies as $c) {
            $rails[$c] = array_map(fn (Gateway $g) => ['key' => $g->key(), 'label' => $g->label()], Registry::forCurrency($c));
        }
        $edition = Catalogue::edition((int) $product['id'], (string) $l['edition']);

        return Response::html(View::render('store/buy', ['product' => $product, 'editions' => $edition !== null ? [$edition] : [], 'currencies' => $currencies, 'rails' => $rails,
            'errors' => [], 'old' => ['edition' => $l['edition'], 'term' => $l['term'] === 'perpetual' ? 'perpetual' : 'year', 'currency' => $currencies[0] ?? 'USD',
                'name' => $l['customer_name'], 'email' => $l['customer_email'], 'country' => $l['customer_country'], 'renews' => $l['id']],
            'renewing' => $l, 'title' => 'Renew '.$product['name'], 'site' => 'store', 'accent' => $product['accent']]));
    }

    private static function quote(Request $r, string $slug): Response
    {
        $product = Catalogue::product($slug);
        if ($product === null) {
            return App::error(404);
        }

        return Enquiries::form($r, $product, 'store', 'quote');
    }
}
