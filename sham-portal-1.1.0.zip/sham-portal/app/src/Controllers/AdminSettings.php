<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\App;
use Sham\Audit;
use Sham\Config;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Licensing\Codec;
use Sham\Mailer;
use Sham\Security\Guard;
use Sham\Security\Session;
use Sham\Settings;

/** Admin: settings (company, store, payments, mail), signing key, admins, own account. */
final class AdminSettings
{
    /** Settings sections: key => [label, fields]. A field is [key, label, type, help]. */
    public static function sections(): array
    {
        $store = Config::url('store');

        return [
            'company' => ['Company', [
                ['company.name', 'Legal name', 'text', ''], ['company.short', 'Short name', 'text', 'Shown in the header.'],
                ['company.tagline', 'Tagline', 'text', ''], ['company.address', 'Address', 'textarea', 'Printed on receipts.'],
                ['company.tin', 'TIN', 'text', 'Printed on receipts.'], ['company.vat_no', 'VAT registration number', 'text', ''],
                ['company.phone', 'Phone', 'text', ''], ['company.sales_email', 'Sales e-mail', 'email', ''],
                ['company.support_email', 'Support e-mail', 'email', 'Shown to customers in licence messages.'],
                ['company.notify_email', 'Notifications to', 'email', 'Where new orders and enquiries are announced.'],
                ['company.reg_no', 'Commercial registration number', 'text', 'Used in the legal pages.'],
                ['company.privacy_email', 'Privacy e-mail', 'email', 'Used in the privacy policy.'], ['company.security_email', 'Security e-mail', 'email', ''],
                ['company.support_channels', 'Support channels and response times', 'text', 'Used in the licence agreement.'],
                ['company.hosting_provider', 'Hosting provider of sham.et', 'text', 'Named in the privacy policy as a processor.'],
                ['company.hosting_country', 'Country where sham.et is hosted', 'text', ''], ['company.email_host', 'E-mail provider', 'text', ''],
                ['company.download_location', 'Where customers download the software', 'text', ''],
            ]],
            'site' => ['Website', [
                ['home.hero_title', 'Home page headline', 'text', 'Empty = the company tagline.'],
                ['home.hero_text', 'Home page introduction', 'textarea', ''],
                ['home.sections', 'More home page text (Markdown)', 'textarea', 'Shown under the products. ## headings, lists, **bold**, [links](https://…) and ![images](/media/…).'],
                ['site.announcement', 'Announcement bar', 'text', 'One line shown at the top of every public page. Empty = none.'],
                ['site.announcement_link', 'Announcement link', 'text', 'Optional address the bar links to.'],
                ['social.facebook', 'Facebook page', 'text', ''], ['social.x', 'X (Twitter)', 'text', ''], ['social.linkedin', 'LinkedIn', 'text', ''],
                ['social.youtube', 'YouTube', 'text', ''], ['social.telegram', 'Telegram', 'text', ''],
            ]],
            'store' => ['Store and prices', [
                ['store.etb_per_usd', 'Birr per US dollar', 'number', 'Prices are set in USD per year; birr prices = USD × this rate (rounded). 0 hides ETB.'],
                ['store.vat_percent', 'VAT %', 'number', ''], ['store.vat_countries', 'VAT applies to buyers in', 'text', 'Country codes, comma separated (ET).'],
                ['store.update_renewal_percent', 'Yearly update renewal for perpetual licences (% of price)', 'number', ''],
                ['store.pending_hours', 'Close unpaid orders after (hours)', 'number', ''],
            ]],
            'payments' => ['Payment methods', [
                ['stripe.enabled', 'Stripe: on', 'bool', 'Cards in USD. Webhook URL: '.$store.'/webhooks/stripe (events: checkout.session.completed, checkout.session.async_payment_succeeded, checkout.session.expired).'],
                ['stripe.secret', 'Stripe secret key', 'secret', 'sk_live_… (or a restricted key with Checkout write and read).'], ['stripe.webhook_secret', 'Stripe webhook signing secret', 'secret', 'whsec_…'],
                ['paypal.enabled', 'PayPal: on', 'bool', 'USD. Webhook URL: '.$store.'/webhooks/paypal (events: CHECKOUT.ORDER.APPROVED, PAYMENT.CAPTURE.*).'],
                ['paypal.mode', 'PayPal mode', 'select:sandbox,live', ''], ['paypal.client_id', 'PayPal client ID', 'text', ''],
                ['paypal.client_secret', 'PayPal client secret', 'secret', ''], ['paypal.webhook_id', 'PayPal webhook ID', 'text', ''],
                ['chapa.enabled', 'Chapa: on', 'bool', 'ETB. Webhook URL: '.$store.'/webhooks/chapa'],
                ['chapa.secret_key', 'Chapa secret key', 'secret', 'CHASECK-…'], ['chapa.webhook_secret', 'Chapa webhook secret', 'secret', ''],
                ['telebirr.enabled', 'telebirr: on', 'bool', 'ETB. Notify URL: '.$store.'/webhooks/telebirr'],
                ['telebirr.test_mode', 'telebirr test environment', 'bool', ''], ['telebirr.base_url', 'telebirr API base URL', 'text', ''],
                ['telebirr.web_base_url', 'telebirr web checkout URL', 'text', ''], ['telebirr.fabric_app_id', 'Fabric app ID', 'text', ''],
                ['telebirr.app_secret', 'App secret', 'secret', ''], ['telebirr.merchant_app_id', 'Merchant app ID', 'text', ''],
                ['telebirr.merchant_code', 'Short code (merchant code)', 'text', ''], ['telebirr.private_key', 'Your RSA private key (PEM)', 'secret-area', ''],
                ['telebirr.public_key', 'telebirr public key (PEM)', 'textarea', ''],
                ['arifpay.enabled', 'ArifPay: on', 'bool', 'ETB.'], ['arifpay.test_mode', 'ArifPay test mode', 'bool', ''], ['arifpay.base_url', 'ArifPay API URL', 'text', ''],
                ['arifpay.api_key', 'ArifPay API key', 'secret', ''], ['arifpay.beneficiary_account', 'Beneficiary account number', 'text', ''],
                ['arifpay.beneficiary_bank', 'Beneficiary bank code', 'text', ''],
                ['bank.enabled', 'Bank transfer: on', 'bool', 'Orders wait until you confirm the money arrived (Orders → Mark paid).'],
                ['bank.currencies', 'Bank transfer currencies', 'text', 'ETB, USD or both.'], ['bank.bank_name', 'Bank', 'text', ''],
                ['bank.account_name', 'Account name', 'text', ''], ['bank.account_number', 'Account number', 'text', ''], ['bank.swift', 'SWIFT (for USD)', 'text', ''],
            ]],
            'mail' => ['E-mail', [
                ['smtp.host', 'SMTP server', 'text', 'From your host (for example mail.sham.et). Empty = PHP mail().'], ['smtp.port', 'Port', 'number', '465 (SSL) or 587 (STARTTLS).'],
                ['smtp.secure', 'Security', 'select:ssl,tls', ''], ['smtp.user', 'User name', 'text', ''], ['smtp.pass', 'Password', 'secret', ''],
                ['smtp.from', 'From address', 'email', ''], ['smtp.from_name', 'From name', 'text', ''],
                ['mail.batch_per_run', 'News e-mails sent per run (every 10 minutes)', 'number', 'Keep under your host\'s hourly limit ÷ 6. Most cPanel hosts allow 100–500 an hour.'],
            ]],
        ];
    }

    public static function settings(Request $r, array $me, string $p): Response
    {
        $section = trim(substr($p, strlen('/admin/settings')), '/') ?: 'company';
        $sections = self::sections();
        if (! isset($sections[$section])) {
            return App::error(404);
        }
        [$label, $fields] = $sections[$section];
        if ($r->isPost() && $r->input('test_mail') === '1') {
            $ok = Mailer::send((string) $me['email'], 'Test e-mail from the Sham store', "This is a test. If you can read it, e-mail from the store works.\n");
            Session::flash($ok ? 'A test e-mail was sent to '.$me['email'].'.' : 'The test e-mail failed. See the mail log entry for the reason.', $ok ? 'ok' : 'bad');

            return Response::redirect('/admin/settings/mail');
        }
        if ($r->isPost()) {
            $secretTouched = false;
            foreach ($fields as [$key, , $type]) {
                // Payment API addresses decide who confirms a payment: changing one counts as changing a secret.
                if (str_ends_with($key, 'base_url') && trim($r->input('f_'.str_replace('.', '__', $key))) !== Settings::get($key)) {
                    $secretTouched = true;
                }
                if (str_starts_with($type, 'secret')) {
                    $v = trim($r->input('f_'.str_replace('.', '__', $key)));
                    if ($v !== '' || $r->input('f_'.str_replace('.', '__', $key).'__clear') === '1') {
                        $secretTouched = true;
                    }
                }
            }
            if ($secretTouched && ! Admin::confirmCode($me, $r->input('confirm_code'))) {
                Session::flash('To change a key or password, also enter a fresh authenticator code. Nothing was saved.', 'bad');

                return Response::redirect('/admin/settings/'.$section);
            }
            $changed = [];
            foreach ($fields as [$key, , $type]) {
                $name = 'f_'.str_replace('.', '__', $key);
                if ($type === 'bool') {
                    $v = $r->input($name) === '1' ? '1' : '0';
                } elseif (str_starts_with($type, 'secret')) {
                    $v = trim($r->input($name));
                    if ($r->input($name.'__clear') === '1') {
                        Settings::set($key, '');
                        $changed[] = $key.' (cleared)';
                    }
                    if ($v === '') {
                        continue;
                    }
                } elseif (str_starts_with($type, 'select:')) {
                    $opts = explode(',', substr($type, 7));
                    $v = in_array($r->input($name), $opts, true) ? $r->input($name) : $opts[0];
                } elseif ($type === 'number') {
                    $v = is_numeric($r->input($name)) ? (string) (0 + $r->input($name)) : '0';
                } elseif ($type === 'email') {
                    $v = trim($r->input($name));
                    if ($v !== '' && ! filter_var($v, FILTER_VALIDATE_EMAIL)) {
                        continue;
                    }
                } else {
                    $v = mb_substr(trim(str_replace("\r\n", "\n", $r->input($name))), 0, 8000);
                }
                if ($v !== Settings::get($key)) {
                    Settings::set($key, $v);
                    $changed[] = $key;
                }
            }
            if ($changed !== []) {
                Audit::log('settings.updated', (string) $me['email'], $section, ['keys' => $changed]);
            }
            Session::flash($changed === [] ? 'Nothing changed.' : 'Saved.');

            return Response::redirect('/admin/settings/'.$section);
        }

        return Admin::view('admin/settings', ['title' => 'Settings: '.$label, 'section' => $section, 'sections' => $sections, 'fields' => $fields]);
    }

    public static function signingKey(Request $r, array $me): Response
    {
        $error = null;
        if ($r->isPost()) {
            if (! Admin::confirmCode($me, $r->input('confirm_code'))) {
                $error = 'Enter a fresh authenticator code.';
            } else {
                try {
                    $pub = Codec::importPem($r->input('pem'));
                    $known = Codec::publicKeys();
                    Audit::log('signing_key.imported', (string) $me['email'], null, ['public_key' => $pub]);
                    Session::flash(in_array($pub, $known, true) ? 'Signing key imported. Its public key matches the one built into Sham MediaOS.'
                        : 'Signing key imported, but its public key ('.$pub.') is NOT one that Sham MediaOS installations trust. Licences signed with it will be refused unless installations add it to LICENSING_PUBLIC_KEYS.',
                        in_array($pub, $known, true) ? 'ok' : 'bad');

                    return Response::redirect('/admin/signing-key');
                } catch (\InvalidArgumentException $e) {
                    $error = $e->getMessage();
                }
            }
        }
        $pub = Codec::publicKey();

        return Admin::view('admin/signing-key', ['title' => 'Signing key', 'available' => Codec::available(), 'public' => $pub !== null ? base64_encode($pub) : null,
            'known' => Codec::publicKeys(), 'error' => $error]);
    }

    public static function admins(Request $r, array $me, string $p): Response
    {
        if ($r->isPost() && $p === '/admin/admins') {
            $email = mb_strtolower(trim($r->input('email')));
            $name = str_limit($r->input('name'), 120);
            $pw = $r->input('password');
            $role = array_key_exists($r->input('role'), Admin::ROLES) ? $r->input('role') : 'staff';
            $weak = Guard::weakPassword($pw, $email);
            if (! filter_var($email, FILTER_VALIDATE_EMAIL) || $name === '' || $weak !== null || Db::one('SELECT id FROM admins WHERE email = ?', [$email]) !== null) {
                Session::flash('Give a new e-mail address, a name and a strong first password. '.($weak ?? ''), 'bad');
            } elseif (! Admin::confirmCode($me, $r->input('confirm_code'))) {
                Session::flash('Enter a fresh authenticator code.', 'bad');
            } else {
                Db::insert('admins', ['email' => $email, 'name' => $name, 'role' => $role, 'password_hash' => Guard::hashPassword($pw), 'created_at' => now_utc()]);
                Audit::log('admin.created', (string) $me['email'], $email, ['role' => $role]);
                Session::flash('Added. They set up their authenticator at first sign-in.');
            }

            return Response::redirect('/admin/admins');
        }
        if ($r->isPost() && preg_match('#^/admin/admins/(\d+)/role$#', $p, $m) === 1) {
            $role = $r->input('role');
            if ((int) $m[1] === (int) $me['id'] || ! array_key_exists($role, Admin::ROLES)) {
                Session::flash('Choose a role for another admin.', 'bad');
            } elseif (! Admin::confirmCode($me, $r->input('confirm_code'))) {
                Session::flash('Enter a fresh authenticator code.', 'bad');
            } else {
                Db::update('admins', ['role' => $role], ['id' => (int) $m[1]]);
                Audit::log('admin.role_changed', (string) $me['email'], $m[1], ['role' => $role]);
                Session::flash('Role changed.');
            }

            return Response::redirect('/admin/admins');
        }
        if ($r->isPost() && preg_match('#^/admin/admins/(\d+)/(deactivate|activate|reset-2fa)$#', $p, $m) === 1) {
            $id = (int) $m[1];
            if ($id === (int) $me['id']) {
                Session::flash('You cannot change your own access here.', 'bad');
            } elseif (! Admin::confirmCode($me, $r->input('confirm_code'))) {
                Session::flash('Enter a fresh authenticator code.', 'bad');
            } else {
                $set = match ($m[2]) {
                    'deactivate' => ['active' => 0], 'activate' => ['active' => 1, 'failed_logins' => 0, 'locked_until' => null],
                    default => ['totp_secret' => null, 'totp_last_step' => 0, 'recovery_codes' => null],
                };
                Db::update('admins', $set, ['id' => $id]);
                Audit::log('admin.'.$m[2], (string) $me['email'], (string) $id);
                Session::flash('Done.');
            }

            return Response::redirect('/admin/admins');
        }

        return Admin::view('admin/admins', ['title' => 'Admins', 'rows' => Db::all('SELECT id, email, name, role, active, last_login_at, totp_secret IS NOT NULL AS has_2fa FROM admins ORDER BY id')]);
    }

    public static function account(Request $r, array $me): Response
    {
        $error = null;
        if ($r->isPost()) {
            $new = $r->input('new_password');
            $weak = Guard::weakPassword($new, (string) $me['email']);
            if (! Guard::hit('password-change', (string) $me['id'], 5, 900)) {
                $error = 'Too many attempts. Wait 15 minutes.';
            } elseif (! password_verify($r->input('current_password'), (string) $me['password_hash'])) {
                $error = 'Your current password is not right.';
            } elseif ($weak !== null) {
                $error = $weak;
            } elseif ($new !== $r->input('new_password2')) {
                $error = 'The two new passwords are different.';
            } else {
                $hash = Guard::hashPassword($new);
                Db::update('admins', ['password_hash' => $hash], ['id' => $me['id']]);
                $_SESSION['admin_pw'] = substr(hash('sha256', $hash), 0, 16);
                Session::regenerate();
                Audit::log('admin.password_changed', (string) $me['email']);
                Session::flash('Password changed. Other sessions are signed out.');

                return Response::redirect('/admin/account');
            }
        }

        return Admin::view('admin/account', ['title' => 'Your account', 'error' => $error]);
    }
}
