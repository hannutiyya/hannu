<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\App;
use Sham\Audit;
use Sham\Config;
use Sham\Content;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Mailer;
use Sham\Security\Guard;
use Sham\Security\Session;
use Sham\Settings;
use Sham\View;

/**
 * store.sham.et/account: customers sign in with a one-time link sent to the e-mail their licences were issued to, and
 * see their licences and keys, orders and receipts, and the downloads their licences entitle them to. No passwords to
 * forget or leak; links last 30 minutes and work once.
 */
final class Account
{
    public static function handle(Request $r): Response
    {
        $p = rtrim($r->path, '/') ?: '/account';
        $res = match (true) {
            $p === '/account' && $r->isPost() => self::sendLink($r),
            $p === '/account' => self::home($r),
            // The e-mailed link shows a button; only pressing it uses the link (mail scanners open links, people press buttons).
            preg_match('#^/account/login/([A-Za-z0-9_-]{43})$#', $p, $m) === 1 => $r->isPost() ? self::login($m[1])
                : Response::html(View::render('account/login', ['title' => 'Your account', 'site' => 'store', 'sent' => false, 'error' => null, 'confirm' => $m[1]])),
            $p === '/account/logout' && $r->isPost() => self::logout(),
            preg_match('#^/account/download/(\d+)/(LIC-[0-9A-Z]{26})$#', $p, $m) === 1 => self::download((int) $m[1], $m[2]),
            preg_match('#^/account/install/(LIC-[0-9A-Z]{26})$#', $p, $m) === 1 => self::serverInstall($r, $m[1]),
            default => App::error(404),
        };

        return $res->header('Cache-Control', 'no-store')->header('X-Robots-Tag', 'noindex')->header('Referrer-Policy', 'no-referrer');
    }

    public static function email(): ?string
    {
        $e = $_SESSION['customer_email'] ?? null;

        return is_string($e) && time() - (int) ($_SESSION['customer_at'] ?? 0) < 43200 ? $e : null;
    }

    private static function home(Request $r): Response
    {
        $email = self::email();
        if ($email === null) {
            return Response::html(View::render('account/login', ['title' => 'Your account', 'site' => 'store', 'sent' => false, 'error' => null]));
        }
        $licences = Db::all('SELECT l.*, p.name AS product_name, p.slug AS product_slug, p.licence_kind FROM licences l JOIN products p ON p.id = l.product_id
            WHERE l.customer_email = ? ORDER BY l.created_at DESC', [$email]);
        $orders = Db::all('SELECT o.*, p.name AS product_name FROM orders o JOIN products p ON p.id = o.product_id WHERE o.customer_email = ? ORDER BY o.created_at DESC LIMIT 100', [$email]);
        $downloads = [];
        foreach ($licences as $l) {
            foreach (Content::releases((int) $l['product_id'], null, 6) as $rel) {
                if (($rel['file_path'] !== null || $rel['external_url'] !== null) && Content::entitled($rel, $l)) {
                    $downloads[$l['id']][] = $rel;
                }
            }
        }

        return Response::html(View::render('account/home', ['title' => 'Your account', 'site' => 'store', 'email' => $email, 'licences' => $licences,
            'orders' => $orders, 'downloads' => $downloads]));
    }

    private static function sendLink(Request $r): Response
    {
        $email = mb_strtolower(trim($r->input('email')));
        $vars = ['title' => 'Your account', 'site' => 'store', 'sent' => false, 'error' => null];
        if (! filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
            return Response::html(View::render('account/login', ['error' => 'Enter a valid e-mail address.'] + $vars), 422);
        }
        if (Guard::hit('account-link', $r->ip(), 10, 3600) && Guard::hit('account-link-email', $email, 4, 3600)) {
            $known = Db::value('SELECT 1 FROM licences WHERE customer_email = ? UNION SELECT 1 FROM orders WHERE customer_email = ? LIMIT 1', [$email, $email]);
            if ($known !== null && $known !== false) {
                $token = b64url(random_bytes(32));
                Db::insert('login_tokens', ['token_hash' => hash('sha256', $token), 'email' => $email, 'expires_at' => gmdate('Y-m-d H:i:s', time() + 1800)]);
                Mailer::send($email, 'Your sign-in link for '.Settings::get('company.short'),
                    "Hello,\n\nUse this link within 30 minutes to see your licences, receipts and downloads:\n\n".Config::url('store', '/account/login/'.$token)
                    ."\n\nThe link works once. If you did not ask for it, ignore this message.\n\n— ".Settings::get('company.name')."\n");
            }
        }

        // The same answer whether or not we know the address.
        return Response::html(View::render('account/login', ['sent' => true] + $vars));
    }

    private static function login(string $token): Response
    {
        $hash = hash('sha256', $token);
        $row = Db::tx(function () use ($hash) {
            $t = Db::one('SELECT * FROM login_tokens WHERE token_hash = ? FOR UPDATE', [$hash]);
            if ($t === null || $t['used_at'] !== null || strtotime($t['expires_at'].' UTC') < time()) {
                return null;
            }
            Db::update('login_tokens', ['used_at' => now_utc()], ['token_hash' => $hash]);

            return $t;
        });
        if ($row === null) {
            return Response::html(View::render('account/login', ['title' => 'Your account', 'site' => 'store', 'sent' => false,
                'error' => 'That link has expired or was already used. Ask for a new one below.']), 410);
        }
        Session::regenerate();
        $_SESSION['customer_email'] = (string) $row['email'];
        $_SESSION['customer_at'] = time();
        Audit::log('customer.signed_in', (string) $row['email']);

        return Response::redirect('/account');
    }

    private static function logout(): Response
    {
        unset($_SESSION['customer_email'], $_SESSION['customer_at']);
        Session::regenerate();

        return Response::redirect('/account');
    }

    private static function download(int $releaseId, string $licenceId): Response
    {
        $email = self::email();
        if ($email === null) {
            return Response::redirect('/account');
        }
        $l = Db::one('SELECT * FROM licences WHERE id = ? AND customer_email = ?', [$licenceId, $email]);
        $rel = Db::one('SELECT * FROM releases WHERE id = ?', [$releaseId]);
        if ($l === null || $rel === null || ! Content::entitled($rel, $l)) {
            return App::error(403, 'This licence does not include that download.');
        }

        return Response::redirect(Config::url('licensing', '/dl/'.Content::downloadToken((int) $rel['id'], (string) $l['id'], 600)));
    }

    /** "Install on your server": a one-line command with the answers built in. */
    private static function serverInstall(Request $r, string $licenceId): Response
    {
        $email = self::email();
        if ($email === null) {
            return Response::redirect('/account');
        }
        $l = Db::one('SELECT l.*, p.name AS product_name, p.licence_kind FROM licences l JOIN products p ON p.id = l.product_id WHERE l.id = ? AND l.customer_email = ?', [$licenceId, $email]);
        if ($l === null || $l['licence_kind'] !== 'mediaos' || $l['status'] !== 'active') {
            return App::error(404);
        }
        $domains = json_in((string) $l['domains_json']);
        $vars = ['title' => 'Install on your server', 'site' => 'store', 'licence' => $l, 'error' => null, 'command' => null,
            'old' => ['host' => (string) ($domains[0] ?? ''), 'admin' => $email, 'org' => (string) $l['customer_name']]];
        if ($r->isPost()) {
            $vars['old'] = ['host' => $r->input('host'), 'admin' => $r->input('admin'), 'org' => $r->input('org')];
            $a = \Sham\ServerInstall::answers($l, $r->input('host'), $r->input('admin'), $r->input('org'));
            if (is_string($a)) {
                $vars['error'] = $a;
            } elseif (! Guard::hit('server-install', $email, 10, 3600)) {
                $vars['error'] = 'You made several commands in the last hour. Use the last one, or wait an hour.';
            } else {
                $vars['command'] = \Sham\ServerInstall::command(\Sham\ServerInstall::code($a));
                Audit::log('licence.install_command', $email, (string) $l['id'], ['host' => $a['h']]);
            }
        }

        return Response::html(View::render('account/install', $vars), $vars['error'] !== null ? 422 : 200);
    }
}
