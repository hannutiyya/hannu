<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\App;
use Sham\Audit;
use Sham\Config;
use Sham\Cron;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Migrator;
use Sham\Security\Session;
use Sham\Settings;

/**
 * Owner only: the health of the installation, database upgrades, scheduled work, a database backup to download, and
 * updating the portal itself from a new sham-portal-x.y.z.zip, all from the browser. An update copies the new code over
 * the old one (never config.php, storage or the install token), keeps a copy of the old code to go back to, and then
 * applies the database changes the new version brings.
 */
final class AdminSystem
{
    /** Folders in a package that an update may write to, and files it must never replace. */
    private const KEEP = ['app/config.php', 'app/install-token.txt'];

    public static function handle(Request $r, array $me, string $p): Response
    {
        if ($r->isPost()) {
            return match ($p) {
                '/admin/system/migrate' => self::migrate($me),
                '/admin/system/cron' => self::cron($me),
                '/admin/system/backup' => self::backup($r, $me),
                '/admin/system/update' => self::update($r, $me),
                '/admin/system/rollback' => self::rollback($r, $me),
                default => App::error(404),
            };
        }
        if ($p !== '/admin/system') {
            return App::error(404);
        }
        $pdo = Db::pdo();
        $checks = self::checks();
        $queue = Db::one('SELECT SUM(sent_at IS NULL AND attempts < 3) AS waiting, SUM(sent_at IS NOT NULL) AS sent, SUM(sent_at IS NULL AND attempts >= 3) AS failed FROM mail_queue');
        $tables = Db::all('SELECT table_name AS name, table_rows AS est_rows, data_length + index_length AS bytes FROM information_schema.tables WHERE table_schema = DATABASE() ORDER BY table_name');

        return Admin::view('admin/system', [
            'title' => 'System', 'version' => SHAM_VERSION, 'php' => PHP_VERSION, 'mysql' => (string) $pdo->query('SELECT VERSION()')->fetchColumn(),
            'available' => Migrator::available(), 'applied' => Migrator::applied($pdo), 'pending' => Migrator::pending($pdo),
            'cronLast' => (int) Settings::get('cron.last_run', '0'), 'cronVia' => Settings::get('cron.via', ''), 'queue' => $queue,
            'checks' => $checks, 'tables' => $tables, 'backups' => self::codeBackups(),
            'appDir' => SHAM_APP, 'publicDir' => self::publicDir(), 'maxUpload' => ini_get('upload_max_filesize'),
            'zip' => class_exists(\ZipArchive::class), 'diskFree' => @disk_free_space(SHAM_APP) ?: null,
            'errors' => self::lastErrors(),
        ]);
    }

    /** @return list<array{0: string, 1: bool, 2: string}> label, ok, detail */
    public static function checks(): array
    {
        $ext = fn (string $e): bool => extension_loaded($e);
        $storage = SHAM_APP.'/storage';
        $config = Config::path();

        return [
            ['PHP 8.1 or newer', version_compare(PHP_VERSION, '8.1.0', '>='), PHP_VERSION],
            ['PDO MySQL', $ext('pdo_mysql'), 'database'],
            ['sodium', $ext('sodium'), 'signing and encrypted secrets'],
            ['curl', $ext('curl'), 'payment providers'],
            ['mbstring', $ext('mbstring'), 'text'],
            ['GD', $ext('gd'), 'image uploads'],
            ['zip', $ext('zip'), 'updates from the browser'],
            ['Storage folder writable', is_dir($storage) && is_writable($storage), $storage],
            ['config.php not writable by others', $config === '' || ! is_file($config) || (fileperms($config) & 0o002) === 0, $config !== '' ? $config : '(environment)'],
            ['Install token removed', ! is_file(Install::tokenFile()), 'app/install-token.txt'],
            ['HTTPS', Config::get('scheme') === 'https', (string) Config::get('scheme')],
            ['Signing key set', \Sham\Licensing\Codec::publicKey() !== null, 'Admin → Signing key'],
            ['Scheduled work ran in the last hour', time() - (int) Settings::get('cron.last_run', '0') < 3600, Settings::get('cron.via', '') !== '' ? 'by '.Settings::get('cron.via', '') : 'never'],
        ];
    }

    private static function migrate(array $me): Response
    {
        $done = Migrator::run(Db::pdo());
        Settings::set('system.schema', SHAM_VERSION.'/'.implode(',', Migrator::available()));
        Audit::log('system.migrated', (string) $me['email'], SHAM_VERSION, ['migrations' => $done]);
        Session::flash($done === [] ? 'The database is up to date.' : 'Applied: '.implode(', ', $done).'.');

        return Response::redirect('/admin/system');
    }

    private static function cron(array $me): Response
    {
        Settings::set('cron.last_run', '0');
        $log = Cron::run('admin');
        Audit::log('system.cron_run', (string) $me['email'], null, ['log' => array_slice($log, 0, 20)]);
        Session::flash($log === [] ? 'Scheduled work ran. Nothing needed doing.' : 'Scheduled work ran: '.implode('; ', array_slice($log, 0, 8)).(count($log) > 8 ? ' …' : ''));

        return Response::redirect('/admin/system');
    }

    /** A gzip SQL dump of the whole database. Secrets inside stay encrypted with the key in config.php. */
    private static function backup(Request $r, array $me): Response
    {
        if (! Admin::confirmCode($me, $r->input('confirm_code'))) {
            Session::flash('That authenticator code is not right.', 'bad');

            return Response::redirect('/admin/system');
        }
        @set_time_limit(300);
        $pdo = Db::pdo();
        $out = fopen('php://temp/maxmemory:'.(8 * 1048576), 'w+b');
        fwrite($out, '-- Sham portal '.SHAM_VERSION.' database backup, '.gmdate('Y-m-d H:i:s')." UTC\n-- Restore into an empty database (phpMyAdmin → Import), then upload config.php from your own backup.\n"
            ."SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\nSET time_zone = '+00:00';\n\n");
        $skip = ['sessions', 'rate_limits'];
        foreach ($pdo->query("SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE' ORDER BY table_name")->fetchAll(\PDO::FETCH_COLUMN) as $t) {
            $t = (string) $t;
            if (preg_match('/^[A-Za-z0-9_]+$/', $t) !== 1) {
                continue;
            }
            $create = $pdo->query('SHOW CREATE TABLE `'.$t.'`')->fetch(\PDO::FETCH_NUM)[1];
            fwrite($out, "DROP TABLE IF EXISTS `{$t}`;\n{$create};\n\n");
            if (in_array($t, $skip, true)) {
                continue;
            }
            $st = $pdo->query('SELECT * FROM `'.$t.'`', \PDO::FETCH_ASSOC);
            $batch = [];
            $cols = null;
            foreach ($st as $row) {
                $cols ??= '(`'.implode('`, `', array_keys($row)).'`)';
                $batch[] = '('.implode(', ', array_map(fn ($v) => $v === null ? 'NULL' : $pdo->quote((string) $v), array_values($row))).')';
                if (count($batch) >= 200) {
                    fwrite($out, "INSERT INTO `{$t}` {$cols} VALUES\n".implode(",\n", $batch).";\n");
                    $batch = [];
                }
            }
            if ($batch !== []) {
                fwrite($out, "INSERT INTO `{$t}` {$cols} VALUES\n".implode(",\n", $batch).";\n");
            }
            fwrite($out, "\n");
        }
        fwrite($out, "SET FOREIGN_KEY_CHECKS = 1;\n");
        rewind($out);
        $sql = (string) stream_get_contents($out);
        fclose($out);
        Audit::log('system.backup_downloaded', (string) $me['email'], null, ['bytes' => strlen($sql)]);
        $body = function_exists('gzencode') ? (string) gzencode($sql, 6) : $sql;
        $name = 'sham-portal-db-'.gmdate('Y-m-d-His').(function_exists('gzencode') ? '.sql.gz' : '.sql');

        return new Response($body, 200, ['Content-Type' => function_exists('gzencode') ? 'application/gzip' : 'application/sql',
            'Content-Disposition' => 'attachment; filename="'.$name.'"', 'Cache-Control' => 'no-store']);
    }

    /**
     * Updates the code from an uploaded package: sham-portal-x.y.z.zip as published, with app/ and public/ inside (a
     * single top folder is allowed). It is checked before anything is written: only app/ and public/ files, no paths
     * that leave the folder, a bootstrap.php with a version, and no older version unless the owner says so.
     */
    private static function update(Request $r, array $me): Response
    {
        if (! Admin::confirmCode($me, $r->input('confirm_code'))) {
            Session::flash('That authenticator code is not right.', 'bad');

            return Response::redirect('/admin/system');
        }
        if (! class_exists(\ZipArchive::class)) {
            Session::flash('This server has no PHP zip extension. Turn it on in the hosting panel (Select PHP version → extensions), or upload the files with the file manager.', 'bad');

            return Response::redirect('/admin/system');
        }
        $f = $_FILES['package'] ?? null;
        if (! is_array($f) || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || ! is_uploaded_file((string) $f['tmp_name'])) {
            Session::flash('Choose the package file (sham-portal-x.y.z.zip). The largest upload this server accepts is '.ini_get('upload_max_filesize').'.', 'bad');

            return Response::redirect('/admin/system');
        }
        @set_time_limit(300);
        try {
            $plan = self::inspect((string) $f['tmp_name']);
            if (version_compare($plan['version'], SHAM_VERSION, '<') && $r->input('downgrade') !== '1') {
                throw new \InvalidArgumentException("The package is version {$plan['version']}, older than this installation (".SHAM_VERSION.'). Tick "allow an older version" to go back on purpose.');
            }
            $backup = self::snapshot();
            $written = self::apply((string) $f['tmp_name'], $plan);
        } catch (\InvalidArgumentException|\RuntimeException $e) {
            Session::flash($e->getMessage(), 'bad');

            return Response::redirect('/admin/system');
        }
        Audit::log('system.updated', (string) $me['email'], $plan['version'], ['from' => SHAM_VERSION, 'files' => $written, 'backup' => basename($backup),
            'sha256' => hash_file('sha256', (string) $f['tmp_name'])]);
        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }
        Session::flash("Updated to {$plan['version']} ({$written} files). The database changes are applied on the next page. A copy of the previous code is kept: ".basename($backup).'.');

        return Response::redirect('/admin/system');
    }

    /** Goes back to a code copy made before an update. The database is not touched: upgrades only ever add. */
    private static function rollback(Request $r, array $me): Response
    {
        $name = basename($r->input('backup'));
        $path = self::backupDir().'/'.$name;
        if (preg_match('/^code-[0-9A-Za-z.+-]+-\d{8}-\d{6}\.zip$/', $name) !== 1 || ! is_file($path)) {
            return App::error(404);
        }
        if (! Admin::confirmCode($me, $r->input('confirm_code'))) {
            Session::flash('That authenticator code is not right.', 'bad');

            return Response::redirect('/admin/system');
        }
        try {
            $plan = self::inspect($path);
            self::snapshot();
            $written = self::apply($path, $plan);
        } catch (\InvalidArgumentException|\RuntimeException $e) {
            Session::flash($e->getMessage(), 'bad');

            return Response::redirect('/admin/system');
        }
        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }
        Audit::log('system.rolled_back', (string) $me['email'], $plan['version'], ['from' => SHAM_VERSION, 'backup' => $name, 'files' => $written]);
        Session::flash("The code is back at {$plan['version']} ({$written} files).");

        return Response::redirect('/admin/system');
    }

    /**
     * @return array{version: string, prefix: string, entries: list<array{index: int, target: string, dest: string}>}
     */
    public static function inspect(string $zipPath): array
    {
        $zip = new \ZipArchive();
        if ($zip->open($zipPath) !== true) {
            throw new \InvalidArgumentException('That file is not a zip package.');
        }
        try {
            // The package may hold app/ and public/ at the top, or inside one folder (sham-portal/app, …).
            $prefix = null;
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $n = (string) $zip->getNameIndex($i);
                if (preg_match('#^(?:([^/]+)/)?app/bootstrap\.php$#', $n, $m) === 1) {
                    $prefix = isset($m[1]) && $m[1] !== '' ? $m[1].'/' : '';
                    break;
                }
            }
            if ($prefix === null) {
                throw new \InvalidArgumentException('This is not a Sham portal package: app/bootstrap.php is missing.');
            }
            $boot = (string) $zip->getFromName($prefix.'app/bootstrap.php');
            if (preg_match("/define\('SHAM_VERSION', '(\d+\.\d+\.\d+(?:-[0-9A-Za-z.]+)?)'\)/", $boot, $vm) !== 1) {
                throw new \InvalidArgumentException('The package has no version number.');
            }
            $publics = self::publicDirs();
            $entries = [];
            $total = 0;
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $st = $zip->statIndex($i);
                $n = (string) $st['name'];
                if (str_ends_with($n, '/')) {
                    continue;
                }
                if (str_contains($n, '\\') || str_contains($n, "\0") || preg_match('#(^|/)\.\.(/|$)#', $n) === 1 || str_starts_with($n, '/')) {
                    throw new \InvalidArgumentException('The package holds a file with an unsafe name ('.substr($n, 0, 80).'). Nothing was changed.');
                }
                if ($prefix !== '' && ! str_starts_with($n, $prefix)) {
                    continue;
                }
                $rel = substr($n, strlen($prefix));
                if (preg_match('#^(app|public)/(.+)$#', $rel, $pm) !== 1) {
                    continue; // INSTALL.md and other papers next to the code
                }
                if (in_array($rel, self::KEEP, true) || str_starts_with($rel, 'app/storage/')) {
                    continue;
                }
                $total += (int) $st['size'];
                // Public files go to every document root the sites are served from.
                foreach ($pm[1] === 'app' ? [SHAM_APP] : $publics as $root) {
                    $entries[] = ['index' => $i, 'target' => $rel, 'dest' => $root.'/'.$pm[2]];
                }
            }
            if ($entries === [] || $total > 200 * 1048576) {
                throw new \InvalidArgumentException('The package is empty or too large.');
            }

            return ['version' => $vm[1], 'prefix' => $prefix, 'entries' => $entries];
        } finally {
            $zip->close();
        }
    }

    /** @param array{version: string, prefix: string, entries: list<array{index: int, target: string, dest: string}>} $plan */
    private static function apply(string $zipPath, array $plan): int
    {
        $zip = new \ZipArchive();
        if ($zip->open($zipPath) !== true) {
            throw new \RuntimeException('The package could not be opened.');
        }
        // First every file to a temporary name beside its place, then all renames: a failure halfway leaves the old code.
        $staged = [];
        try {
            foreach ($plan['entries'] as $en) {
                $dir = dirname($en['dest']);
                if (! is_dir($dir) && ! @mkdir($dir, 0755, true)) {
                    throw new \RuntimeException('Could not create the folder '.$dir.'. Check the folder permissions.');
                }
                $tmp = $en['dest'].'.upd'.bin2hex(random_bytes(3));
                $data = $zip->getFromIndex($en['index']);
                if ($data === false || file_put_contents($tmp, $data) === false) {
                    throw new \RuntimeException('Could not write '.$en['target'].'. Check the folder permissions.');
                }
                @chmod($tmp, 0644);
                $staged[] = [$tmp, $en['dest']];
            }
        } catch (\RuntimeException $e) {
            foreach ($staged as [$tmp]) {
                @unlink($tmp);
            }
            $zip->close();
            throw $e;
        }
        $zip->close();
        foreach ($staged as [$tmp, $dest]) {
            if (! @rename($tmp, $dest)) {
                @unlink($tmp);
                throw new \RuntimeException('Could not replace '.$dest.'. Some files may be new and some old: upload the package again.');
            }
            if (function_exists('opcache_invalidate') && str_ends_with($dest, '.php')) {
                @opcache_invalidate($dest, true);
            }
        }

        return count($staged);
    }

    /** A zip of the current code (app/ without config, storage and token; public/), to roll back to. */
    private static function snapshot(): string
    {
        $dir = self::backupDir();
        if (! is_dir($dir) && ! @mkdir($dir, 0700, true)) {
            throw new \RuntimeException('Could not create '.$dir.' for the code backup.');
        }
        $path = $dir.'/code-'.SHAM_VERSION.'-'.gmdate('Ymd-His').'.zip';
        $zip = new \ZipArchive();
        if ($zip->open($path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new \RuntimeException('Could not write the code backup.');
        }
        foreach (['app' => SHAM_APP, 'public' => self::publicDir()] as $top => $root) { // the other roots hold the same public files
            $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS));
            foreach ($it as $file) {
                /** @var \SplFileInfo $file */
                $rel = $top.'/'.str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
                if (! $file->isFile() || in_array($rel, self::KEEP, true) || str_starts_with($rel, 'app/storage/') || str_contains($rel, '.upd')
                    || ($top === 'public' && ! self::ours($rel))) {
                    continue;
                }
                $zip->addFile($file->getPathname(), $rel);
            }
        }
        $zip->close();
        // Keep the five newest.
        $all = glob($dir.'/code-*.zip') ?: [];
        usort($all, fn ($a, $b) => filemtime($b) <=> filemtime($a));
        foreach (array_slice($all, 5) as $old) {
            @unlink($old);
        }

        return $path;
    }

    /** In a shared public_html, only our own files go into the code backup. */
    private static function ours(string $rel): bool
    {
        return in_array($rel, ['public/index.php', 'public/.htaccess', 'public/robots.txt', 'public/favicon.ico'], true) || str_starts_with($rel, 'public/assets/');
    }

    /** @return list<array{name: string, bytes: int, at: int}> */
    private static function codeBackups(): array
    {
        $out = [];
        foreach (glob(self::backupDir().'/code-*.zip') ?: [] as $f) {
            $out[] = ['name' => basename($f), 'bytes' => (int) filesize($f), 'at' => (int) filemtime($f)];
        }
        usort($out, fn ($a, $b) => $b['at'] <=> $a['at']);

        return $out;
    }

    private static function backupDir(): string
    {
        return SHAM_APP.'/storage/backups';
    }

    /** @return list<string> the current document root and any others the setup wizard recorded */
    public static function publicDirs(): array
    {
        $dirs = [self::publicDir()];
        foreach ((array) Config::get('public_dirs', []) as $d) {
            if (is_string($d) && is_file($d.'/index.php') && is_file($d.'/.sham-app')) {
                $dirs[] = rtrim($d, '/');
            }
        }

        return array_values(array_unique(array_map(fn ($d) => (string) (realpath($d) ?: $d), $dirs)));
    }

    public static function publicDir(): string
    {
        if (defined('SHAM_PUBLIC')) {
            return (string) constant('SHAM_PUBLIC');
        }
        $script = (string) ($_SERVER['SCRIPT_FILENAME'] ?? '');

        return $script !== '' && basename($script) === 'index.php' ? dirname($script) : dirname(SHAM_APP).'/public';
    }

    /** @return list<string> the last lines of the PHP error log, without anything that looks like a secret */
    private static function lastErrors(): array
    {
        $log = SHAM_APP.'/storage/logs/php-error.log';
        if (! is_file($log)) {
            return [];
        }
        $fh = @fopen($log, 'rb');
        if ($fh === false) {
            return [];
        }
        $size = filesize($log);
        fseek($fh, max(0, $size - 16384));
        $tail = (string) stream_get_contents($fh);
        fclose($fh);
        $lines = array_slice(array_filter(explode("\n", $tail)), -25);

        return array_map(fn ($l) => str_limit((string) preg_replace('/(sk_(live|test)_|whsec_|password|pass=)[^\s,;]*/i', '$1…', $l), 400), $lines);
    }
}
