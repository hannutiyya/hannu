<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\App;
use Sham\Config;
use Sham\Content;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Markdown;
use Sham\Settings;
use Sham\Store\Catalogue;
use Sham\View;

/**
 * sham.et (the company, all products, news, pages) and each product's site — on its own host (media.sham.et) or, for a
 * product without one, under sham.et/products/{slug}. Same pages either way: $base is '' or '/products/{slug}'.
 */
final class Site
{
    public static function company(Request $r): Response
    {
        $p = rtrim($r->path, '/') ?: '/';
        $postOk = $r->isPost() && (in_array($p, ['/contact', '/subscribe'], true) || str_starts_with($p, '/unsubscribe/'));
        if ($r->method !== 'GET' && ! $postOk) {
            return App::error(405);
        }
        if (preg_match('#^/products/([a-z0-9-]+)(/.*)?$#', $p, $m) === 1) {
            $product = Catalogue::product($m[1]);
            if ($product === null) {
                return App::error(404);
            }
            if (($product['host'] ?? '') !== '') {
                return Response::redirect(Content::productUrl($product, $m[2] ?? '/'), 301);
            }

            return self::productSite($r, $product, '/products/'.$m[1], $m[2] ?? '/');
        }

        return match (true) {
            $p === '/' => self::home(),
            $p === '/products' => self::page('products', ['products' => Catalogue::products(), 'title' => 'Products', 'site' => 'company']),
            $p === '/contact' => Enquiries::form($r, null, 'company'),
            $p === '/news' => self::news($r, null, ''),
            preg_match('#^/news/([a-z0-9-]+)$#', $p, $m) === 1 => self::post($m[1], null, ''),
            $p === '/feed.xml' => self::feed(null),
            $p === '/subscribe' => Subscriptions::subscribe($r),
            preg_match('#^/subscribe/confirm/([a-f0-9]{32})$#', $p, $m) === 1 => Subscriptions::confirm($m[1]),
            preg_match('#^/unsubscribe/([a-f0-9]{32})$#', $p, $m) === 1 => Subscriptions::unsubscribe($r, $m[1]),
            preg_match('#^/unsubscribe/([a-f0-9]{32})/now$#', $p, $m) === 1 => Subscriptions::oneClick($r, $m[1]),
            $p === '/robots.txt' => self::robots(),
            $p === '/sitemap.xml' => self::sitemap(),
            $p === '/about' => self::cmsPage('about', 'company'),
            preg_match('#^/legal/([a-z0-9-]+)$#', $p, $m) === 1 => self::cmsPage($m[1], 'company'),
            preg_match('#^/([a-z0-9-]+)$#', $p, $m) === 1 => self::cmsPage($m[1], 'company'),
            default => App::error(404),
        };
    }

    /** @param array<string, mixed> $product */
    public static function product(Request $r, array $product): Response
    {
        $p = rtrim($r->path, '/') ?: '/';
        if ($p === '/robots.txt') {
            return self::robots();
        }

        return self::productSite($r, $product, '', $p);
    }

    /** @param array<string, mixed> $product */
    private static function productSite(Request $r, array $product, string $base, string $p): Response
    {
        $p = rtrim($p, '/') ?: '/';
        if ($r->method !== 'GET' && ! ($r->isPost() && $p === '/contact')) {
            return App::error(405);
        }
        $pid = (int) $product['id'];
        $common = ['product' => $product, 'site' => 'product', 'accent' => $product['accent'], 'base' => $base, 'nav' => Content::productPages($pid, true)];

        return match (true) {
            $p === '/' => self::page('product', $common + [
                'editions' => Catalogue::editions($pid), 'body' => Markdown::render((string) $product['body']),
                'currencies' => Catalogue::currencies(), 'title' => $product['name'], 'description' => $product['summary'],
                'news' => Content::posts($pid, 1, 3)['rows'], 'latest' => Content::latest($pid),
            ]),
            $p === '/contact' => Enquiries::form($r, $product, 'product'),
            $p === '/news' => self::news($r, $product, $base),
            preg_match('#^/news/([a-z0-9-]+)$#', $p, $m) === 1 => self::post($m[1], $product, $base),
            $p === '/feed.xml' => self::feed($product),
            $p === '/releases' => self::page('releases', $common + ['releases' => Content::releases($pid), 'title' => 'Releases: '.$product['name']]),
            preg_match('#^/legal/([a-z0-9-]+)$#', $p, $m) === 1 => self::cmsPage($m[1], 'product', $product, $base),
            preg_match('#^/([a-z0-9-]+)$#', $p, $m) === 1 => self::productPage($product, $m[1], $common),
            default => App::error(404),
        };
    }

    private static function home(): Response
    {
        return self::page('home', ['products' => Catalogue::products(), 'title' => null, 'site' => 'company',
            'news' => Content::posts(null, 1, 3)['rows'], 'sections' => Markdown::render(Settings::get('home.sections'))]);
    }

    /** @param array<string, mixed>|null $product */
    private static function news(Request $r, ?array $product, string $base): Response
    {
        $page = max(1, (int) $r->q('page', '1'));
        $kind = $r->q('kind');
        $res = Content::posts($product !== null ? (int) $product['id'] : null, $page, 12, $kind !== '' ? $kind : null);
        $vars = ['posts' => $res['rows'], 'pages' => $res['pages'], 'pageNo' => $page, 'kind' => $kind, 'base' => $base,
            'title' => $product !== null ? 'News: '.$product['name'] : 'News and updates', 'product' => $product];
        if ($product !== null) {
            $vars += ['site' => 'product', 'accent' => $product['accent'], 'nav' => Content::productPages((int) $product['id'], true)];
        } else {
            $vars += ['site' => 'company', 'products' => Catalogue::products()];
        }

        return self::page('news', $vars);
    }

    /** @param array<string, mixed>|null $product */
    private static function post(string $slug, ?array $product, string $base): Response
    {
        $post = Content::post($slug, $product !== null ? (int) $product['id'] : null);
        if ($post === null) {
            return App::error(404);
        }
        if ($product === null && ($post['product_host'] ?? '') !== '') {
            return Response::redirect(Content::postUrl($post), 301); // one address per post
        }
        $vars = ['post' => $post, 'body' => Markdown::render((string) $post['body']), 'title' => $post['title'], 'description' => $post['summary'], 'base' => $base,
            'product' => $product, 'canonical' => Content::postUrl($post)];
        if ($product !== null) {
            $vars += ['site' => 'product', 'accent' => $product['accent'], 'nav' => Content::productPages((int) $product['id'], true)];
        } else {
            $vars += ['site' => 'company'];
        }

        return self::page('post', $vars);
    }

    /** @param array<string, mixed> $product @param array<string, mixed> $common */
    private static function productPage(array $product, string $slug, array $common): Response
    {
        $pg = Content::productPage((int) $product['id'], $slug);
        if ($pg === null) {
            return App::error(404);
        }

        return self::page('page', $common + ['page' => $pg, 'body' => Markdown::render(self::fill((string) $pg['body'])), 'title' => $pg['title'].' · '.$product['name']]);
    }

    /** @param array<string, mixed>|null $product */
    private static function feed(?array $product): Response
    {
        $rows = Content::posts($product !== null ? (int) $product['id'] : null, 1, 30)['rows'];
        $site = $product !== null ? Content::productUrl($product) : Config::url('company', '/');
        $title = $product !== null ? $product['name'] : Settings::get('company.short');
        $x = '<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>'.e($title.' news').'</title><link>'.e($site).'</link><description>'
            .e($product['tagline'] ?? Settings::get('company.tagline')).'</description><language>en</language>';
        foreach ($rows as $p) {
            $u = Content::postUrl($p);
            $x .= '<item><title>'.e($p['title']).'</title><link>'.e($u).'</link><guid isPermaLink="true">'.e($u).'</guid><pubDate>'
                .gmdate(DATE_RSS, (int) strtotime($p['published_at'].' UTC')).'</pubDate><description>'.e($p['summary']).'</description></item>';
        }

        return new Response($x.'</channel></rss>', 200, ['Content-Type' => 'application/rss+xml; charset=utf-8', 'Cache-Control' => 'public, max-age=600']);
    }

    /** @param array<string, mixed> $vars */
    private static function page(string $view, array $vars): Response
    {
        return Response::html(View::render($view, $vars))->header('Cache-Control', 'public, max-age=120');
    }

    /** @param array<string, mixed>|null $product */
    public static function cmsPage(string $slug, string $site, ?array $product = null, string $base = ''): Response
    {
        $page = $slug !== '' ? Db::one("SELECT * FROM pages WHERE slug = ? AND status = 'published'", [$slug]) : null;
        if ($page === null) {
            return App::error(404);
        }
        $vars = ['page' => $page, 'body' => Markdown::render(self::fill((string) $page['body'])), 'title' => $page['title'], 'site' => $site,
            'product' => $product, 'accent' => $product['accent'] ?? null, 'base' => $base];
        if ($product !== null) {
            $vars['nav'] = Content::productPages((int) $product['id'], true);
        }

        return self::page('page', $vars);
    }

    /** Company details in the legal texts ([TIN], [REGISTERED ADDRESS] …) come from Settings → Company. */
    public static function fill(string $md): string
    {
        $map = ['REGISTERED ADDRESS' => 'company.address', 'PRIVACY E-MAIL' => 'company.privacy_email', 'TIN' => 'company.tin',
            'COMMERCIAL REGISTRATION NO.' => 'company.reg_no', 'VAT NO.' => 'company.vat_no', 'SUPPORT CHANNELS AND RESPONSE TIMES' => 'company.support_channels',
            'PHONE' => 'company.phone', 'HOSTING PROVIDER' => 'company.hosting_provider', 'E-MAIL HOST' => 'company.email_host',
            'DOWNLOAD LOCATION' => 'company.download_location', 'COUNTRY OF HOSTING' => 'company.hosting_country', 'BANK NAME' => 'bank.bank_name',
            'SECURITY E-MAIL' => 'company.security_email'];

        return (string) preg_replace_callback('/\[([A-Z][A-Z0-9 .,\/\'&()-]*)\]/', function ($m) use ($map) {
            if (! isset($map[$m[1]])) {
                return $m[0];
            }
            $v = Settings::get($map[$m[1]]);

            return $v !== '' ? str_replace(["\n", '[', ']'], [', ', '(', ')'], $v) : 'available on request';
        }, $md);
    }

    private static function robots(): Response
    {
        return new Response("User-agent: *\nDisallow: /admin\nDisallow: /order/\nDisallow: /account\nSitemap: ".Config::url('company', '/sitemap.xml')."\n", 200,
            ['Content-Type' => 'text/plain; charset=utf-8']);
    }

    private static function sitemap(): Response
    {
        $urls = [Config::url('company', '/'), Config::url('company', '/products'), Config::url('company', '/news'), Config::url('company', '/contact'), Config::url('store', '/')];
        foreach (Catalogue::products() as $p) {
            $urls[] = Content::productUrl($p);
            $urls[] = Content::productUrl($p, '/releases');
            foreach (Content::productPages((int) $p['id']) as $pg) {
                $urls[] = Content::productUrl($p, '/'.$pg['slug']);
            }
        }
        foreach (Db::all("SELECT slug FROM pages WHERE status = 'published'") as $pg) {
            $urls[] = Config::url('company', $pg['slug'] === 'about' ? '/about' : '/legal/'.$pg['slug']);
        }
        foreach (Content::posts(null, 1, 500)['rows'] as $post) {
            $urls[] = Content::postUrl($post);
        }
        $xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
        foreach (array_unique($urls) as $u) {
            $xml .= '<url><loc>'.e($u).'</loc></url>';
        }

        return new Response($xml.'</urlset>', 200, ['Content-Type' => 'application/xml; charset=utf-8']);
    }
}
