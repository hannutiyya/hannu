<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\Config;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Installer;
use Sham\View;

/**
 * One-time installer, reachable only while app/config.php does not say installed. Whoever runs it must paste the token
 * from app/install-token.txt, which only someone with access to the hosting account's files can read. The token file is
 * deleted when the installation is complete, and the installer is gone for good.
 */
final class Install
{
    public static function tokenFile(): string
    {
        return SHAM_APP.'/install-token.txt';
    }

    public static function handle(Request $r): Response
    {
        if (($r->path !== '/' && $r->path !== '/install') || ! in_array($r->method, ['GET', 'POST'], true)) {
            return Response::redirect('/install');
        }
        $token = is_file(self::tokenFile()) ? trim((string) file_get_contents(self::tokenFile())) : '';
        if (strlen($token) < 32) {
            return self::view(['blocked' => 'The installer is locked. Upload app/install-token.txt from the package (or create it with 32 or more random letters and digits) and reload this page.'], 503);
        }
        $f = ['token' => ''] + Installer::defaults($r->host);
        if (! $r->isPost()) {
            return self::view(['f' => $f, 'errors' => []]);
        }
        foreach (array_keys($f) as $k) {
            $f[$k] = trim($r->input($k));
        }
        $pass = $r->input('db_pass');
        $password = $r->input('password');
        if (! hash_equals($token, $f['token'])) {
            usleep(random_int(400000, 900000));

            return self::view(['f' => ['token' => ''] + $f, 'errors' => ['token' => 'That is not the token in app/install-token.txt.']], 403);
        }
        $errors = Installer::validate($f, $password, $r->input('password2'));
        if ($errors !== []) {
            return self::view(['f' => $f, 'errors' => $errors], 422);
        }
        try {
            $pdo = Db::connect(Installer::dsn($f), $f['db_user'], $pass);
        } catch (\PDOException $e) {
            error_log('sham install: database connection failed: '.$e->getMessage());

            return self::view(['f' => $f, 'errors' => ['db_name' => 'Could not connect to the database with these details. Check the name, user and password in your hosting panel.']], 422);
        }
        if (Installer::occupied($pdo)) {
            return self::view(['f' => $f, 'errors' => ['db_name' => 'This database already holds a Sham portal with administrators. Use an empty database, or restore config.php from your backup.']], 409);
        }
        try {
            Installer::install($pdo, $f, $pass, $password, Config::path() !== '' ? Config::path() : SHAM_APP.'/config.php');
        } catch (\Throwable $e) {
            error_log('sham install: '.get_class($e).': '.$e->getMessage());

            return self::view(['f' => $f, 'errors' => ['db_name' => 'The installation stopped: '.(Config::local() ? $e->getMessage() : 'see app/storage/logs/php-error.log.')]], 500);
        }
        @unlink(self::tokenFile());

        return self::view(['done' => true, 'admin' => 'https://'.$f['store'].'/admin', 'tokenLeft' => is_file(self::tokenFile())]);
    }

    /** @param array<string, mixed> $vars */
    private static function view(array $vars, int $status = 200): Response
    {
        return Response::html(View::render('install', $vars + ['title' => 'Install the Sham portal', 'f' => [], 'errors' => []], 'admin/bare'), $status)
            ->header('Cache-Control', 'no-store')->header('X-Robots-Tag', 'noindex');
    }
}
