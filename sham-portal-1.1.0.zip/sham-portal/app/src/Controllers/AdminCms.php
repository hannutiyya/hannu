<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\App;
use Sham\Audit;
use Sham\Content;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Media;
use Sham\Releases;
use Sham\Security\Session;

/** Admin: news and updates, the media library, releases, product sub-pages and subscribers. */
final class AdminCms
{
    // News and updates ----------------------------------------------------------------------------------------------

    public static function posts(Request $r, array $me, string $p): Response
    {
        if ($p === '/admin/posts') {
            $where = [];
            $args = [];
            if (($pid = $r->q('product')) !== '' && ctype_digit($pid)) {
                $where[] = 'p.product_id = ?';
                $args[] = (int) $pid;
            }
            if (in_array($r->q('status'), ['draft', 'published'], true)) {
                $where[] = 'p.status = ?';
                $args[] = $r->q('status');
            }
            $rows = Db::all('SELECT p.id, p.slug, p.title, p.kind, p.status, p.published_at, p.mailed_at, p.updated_at, pr.name AS product_name FROM posts p
                LEFT JOIN products pr ON pr.id = p.product_id'.($where !== [] ? ' WHERE '.implode(' AND ', $where) : '').' ORDER BY COALESCE(p.published_at, p.created_at) DESC LIMIT 300', $args);

            return Admin::view('admin/posts', ['title' => 'News and updates', 'rows' => $rows, 'products' => self::products(), 'filter' => ['product' => $r->q('product'), 'status' => $r->q('status')]]);
        }
        if (preg_match('#^/admin/posts/(new|\d+)(?:/(delete|mail))?$#', $p, $m) !== 1) {
            return App::error(404);
        }
        $post = $m[1] === 'new' ? null : Db::one('SELECT * FROM posts WHERE id = ?', [(int) $m[1]]);
        if ($m[1] !== 'new' && $post === null) {
            return App::error(404);
        }
        $action = $m[2] ?? '';
        if ($r->isPost() && $action === 'delete' && $post !== null) {
            Db::run('DELETE FROM posts WHERE id = ?', [$post['id']]);
            Audit::log('post.deleted', (string) $me['email'], (string) $post['slug']);
            Session::flash('Deleted.');

            return Response::redirect('/admin/posts');
        }
        if ($r->isPost() && $action === 'mail' && $post !== null) {
            if ($post['status'] !== 'published' || strtotime((string) $post['published_at'].' UTC') > time()) {
                Session::flash('Publish the post before sending it.', 'bad');
            } elseif ($post['mailed_at'] !== null && $r->input('again') !== '1') {
                Session::flash('This post was already sent on '.$post['mailed_at'].'. Tick "send again" to repeat.', 'bad');
            } else {
                $n = Subscriptions::queuePost($post, (string) $me['email']);
                Session::flash('Queued for '.$n.' subscriber'.($n === 1 ? '' : 's').'. It goes out in small batches with the scheduled work.');
            }

            return Response::redirect('/admin/posts/'.$post['id']);
        }
        $errors = [];
        $data = $post ?? ['title' => '', 'slug' => '', 'summary' => '', 'body' => '', 'kind' => 'news', 'product_id' => null, 'status' => 'draft',
            'published_at' => null, 'cover_media_id' => null];
        if ($r->isPost() && $action === '') {
            $title = str_limit($r->input('title'), 200);
            $slug = $r->input('slug') !== '' ? Content::slugify($r->input('slug')) : Content::slugify($title);
            $pid = ctype_digit($r->input('product_id')) ? (int) $r->input('product_id') : null;
            $when = trim($r->input('published_at'));
            $ts = $when !== '' ? strtotime(str_replace('T', ' ', $when).' UTC') : false;
            $cover = ctype_digit($r->input('cover_media_id')) ? (int) $r->input('cover_media_id') : null;
            $data = ['title' => $title, 'slug' => $slug, 'summary' => str_limit($r->input('summary'), 500), 'body' => mb_substr(str_replace("\r\n", "\n", $r->input('body')), 0, 200000),
                'kind' => array_key_exists($r->input('kind'), Content::POST_KINDS) ? $r->input('kind') : 'news',
                'product_id' => $pid !== null && Db::one('SELECT id FROM products WHERE id = ?', [$pid]) !== null ? $pid : null,
                'status' => $r->input('status') === 'published' ? 'published' : 'draft',
                'published_at' => $ts !== false ? gmdate('Y-m-d H:i:s', $ts) : ($r->input('status') === 'published' ? now_utc() : null),
                'cover_media_id' => $cover !== null && Db::one("SELECT id FROM media WHERE id = ? AND kind = 'image'", [$cover]) !== null ? $cover : null];
            if ($title === '') {
                $errors['title'] = 'Give the post a title.';
            }
            if (Db::one('SELECT id FROM posts WHERE slug = ? AND id <> ?', [$slug, $post['id'] ?? 0]) !== null) {
                $errors['slug'] = 'Another post already uses this address.';
            }
            if ($errors === []) {
                $data['updated_at'] = now_utc();
                if ($post === null) {
                    Db::insert('posts', $data + ['author' => (string) $me['email'], 'created_at' => now_utc()]);
                    $id = (int) Db::pdo()->lastInsertId();
                    Audit::log('post.created', (string) $me['email'], $slug);
                } else {
                    Db::update('posts', $data, ['id' => $post['id']]);
                    $id = (int) $post['id'];
                    Audit::log('post.updated', (string) $me['email'], $slug, ['status' => $data['status']]);
                }
                Session::flash($data['status'] === 'published' ? (strtotime((string) $data['published_at'].' UTC') > time() ? 'Saved. It appears on '.$data['published_at'].' UTC.' : 'Published.') : 'Saved as a draft.');

                return Response::redirect('/admin/posts/'.$id);
            }
        }
        $live = $post !== null && $post['status'] === 'published' && strtotime((string) $post['published_at'].' UTC') <= time();

        return Admin::view('admin/post', ['title' => $post === null ? 'New post' : $post['title'], 'post' => $post, 'data' => $data, 'errors' => $errors,
            'products' => self::products(), 'images' => self::images(), 'live' => $live,
            'url' => $post !== null ? Content::postUrl($post + ['product_host' => Db::value('SELECT host FROM products WHERE id = ?', [(int) $post['product_id']])]) : null,
            'subscribers' => (int) Db::value('SELECT COUNT(*) FROM subscribers WHERE confirmed_at IS NOT NULL AND unsubscribed_at IS NULL')], $errors === [] ? 200 : 422);
    }

    // Media library -------------------------------------------------------------------------------------------------

    public static function media(Request $r, array $me, string $p): Response
    {
        if ($p === '/admin/media' && $r->isPost()) {
            try {
                $row = Media::store((array) ($_FILES['file'] ?? []), $r->input('alt'), (string) $me['email'], $r->input('kind') === 'file' ? 25 * 1048576 : Media::MAX_IMAGE);
                Session::flash('Uploaded. Use it in Markdown as ![description]('.Media::url($row).')');
            } catch (\InvalidArgumentException $e) {
                Session::flash($e->getMessage(), 'bad');
            }

            return Response::redirect('/admin/media');
        }
        if (preg_match('#^/admin/media/(\d+)/(delete|alt)$#', $p, $m) === 1 && $r->isPost()) {
            $row = Db::one('SELECT * FROM media WHERE id = ?', [(int) $m[1]]);
            if ($row !== null && $m[2] === 'delete') {
                Media::delete($row, (string) $me['email']);
                Session::flash('Deleted. Pages that still show it will have a broken image until you edit them.');
            } elseif ($row !== null) {
                Db::update('media', ['alt' => str_limit($r->input('alt'), 255)], ['id' => $row['id']]);
                Session::flash('Description saved.');
            }

            return Response::redirect('/admin/media');
        }
        if ($p !== '/admin/media') {
            return App::error(404);
        }

        return Admin::view('admin/media', ['title' => 'Media library', 'rows' => Db::all('SELECT * FROM media ORDER BY id DESC LIMIT 500'),
            'maxUpload' => ini_get('upload_max_filesize')]);
    }

    // Releases ------------------------------------------------------------------------------------------------------

    public static function releases(Request $r, array $me, string $p): Response
    {
        if ($p === '/admin/releases') {
            $rows = Db::all('SELECT rl.*, pr.name AS product_name FROM releases rl JOIN products pr ON pr.id = rl.product_id ORDER BY rl.released_at DESC, rl.id DESC LIMIT 300');

            return Admin::view('admin/releases', ['title' => 'Releases', 'rows' => $rows]);
        }
        if (preg_match('#^/admin/releases/(new|\d+)(?:/(delete|file))?$#', $p, $m) !== 1) {
            return App::error(404);
        }
        $rel = $m[1] === 'new' ? null : Db::one('SELECT * FROM releases WHERE id = ?', [(int) $m[1]]);
        if ($m[1] !== 'new' && $rel === null) {
            return App::error(404);
        }
        $action = $m[2] ?? '';
        if ($r->isPost() && $action === 'delete' && $rel !== null) {
            if ($rel['file_path'] !== null) {
                @unlink(Releases::path((string) $rel['file_path']));
            }
            Db::run('DELETE FROM releases WHERE id = ?', [$rel['id']]);
            Audit::log('release.deleted', (string) $me['email'], (string) $rel['version']);
            Session::flash('Release deleted.');

            return Response::redirect('/admin/releases');
        }
        if ($r->isPost() && $action === 'file' && $rel !== null) {
            try {
                if (($_FILES['file']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
                    $f = Releases::adopt((string) $_FILES['file']['tmp_name'], (string) $_FILES['file']['name'], true);
                } elseif (($src = Releases::incomingPath($r->input('incoming'))) !== null) {
                    $f = Releases::adopt($src, basename($src), false);
                } elseif (in_array($_FILES['file']['error'] ?? 0, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)) {
                    throw new \InvalidArgumentException('The file is larger than this server accepts ('.ini_get('upload_max_filesize').'). Put it in app/storage/releases/incoming with the file manager or FTP and choose it here.');
                } else {
                    throw new \InvalidArgumentException('Upload a file or choose one from the incoming folder.');
                }
                if ($rel['file_path'] !== null) {
                    @unlink(Releases::path((string) $rel['file_path']));
                }
                Db::update('releases', $f, ['id' => $rel['id']]);
                Audit::log('release.file_set', (string) $me['email'], (string) $rel['version'], ['sha256' => $f['sha256'], 'bytes' => $f['file_bytes']]);
                Session::flash('File attached. SHA-256 '.$f['sha256']);
            } catch (\InvalidArgumentException $e) {
                Session::flash($e->getMessage(), 'bad');
            }

            return Response::redirect('/admin/releases/'.$rel['id']);
        }
        $errors = [];
        $data = $rel ?? ['product_id' => (int) (Db::value("SELECT id FROM products WHERE licence_kind = 'mediaos' ORDER BY sort LIMIT 1") ?: 0), 'version' => '', 'channel' => 'stable',
            'title' => '', 'notes' => '', 'released_at' => now_utc(), 'access' => 'licensed', 'external_url' => '', 'critical' => 0, 'status' => 'draft'];
        if ($r->isPost() && $action === '') {
            $ts = strtotime(str_replace('T', ' ', trim($r->input('released_at'))).' UTC');
            $ext = trim($r->input('external_url'));
            $data = ['product_id' => (int) $r->input('product_id'), 'version' => trim($r->input('version')), 'channel' => $r->input('channel') === 'beta' ? 'beta' : 'stable',
                'title' => str_limit($r->input('title'), 200), 'notes' => mb_substr(str_replace("\r\n", "\n", $r->input('notes')), 0, 100000),
                'released_at' => $ts !== false ? gmdate('Y-m-d H:i:s', $ts) : now_utc(), 'access' => $r->input('access') === 'public' ? 'public' : 'licensed',
                'external_url' => $ext !== '' ? $ext : null, 'critical' => $r->input('critical') === '1' ? 1 : 0, 'status' => $r->input('status') === 'published' ? 'published' : 'draft'];
            if (Db::one('SELECT id FROM products WHERE id = ?', [$data['product_id']]) === null) {
                $errors['product_id'] = 'Choose a product.';
            }
            if (preg_match('/^\d+\.\d+(\.\d+)?([.+-][0-9A-Za-z.-]+)?$/', $data['version']) !== 1) {
                $errors['version'] = 'Use a version number such as 2.1.0 or 2.2.0-beta.1.';
            } elseif (Db::one('SELECT id FROM releases WHERE product_id = ? AND version = ? AND id <> ?', [$data['product_id'], $data['version'], $rel['id'] ?? 0]) !== null) {
                $errors['version'] = 'This version already exists for the product.';
            }
            if ($ext !== '' && (! str_starts_with($ext, 'https://') || filter_var($ext, FILTER_VALIDATE_URL) === false)) {
                $errors['external_url'] = 'Give a full https:// address, or leave it empty and attach a file.';
            }
            if ($errors === []) {
                if ($rel === null) {
                    Db::insert('releases', $data + ['created_at' => now_utc()]);
                    $id = (int) Db::pdo()->lastInsertId();
                    Audit::log('release.created', (string) $me['email'], $data['version']);
                } else {
                    Db::update('releases', $data, ['id' => $rel['id']]);
                    $id = (int) $rel['id'];
                    Audit::log('release.updated', (string) $me['email'], $data['version'], ['status' => $data['status']]);
                }
                Session::flash('Saved.');

                return Response::redirect('/admin/releases/'.$id);
            }
        }

        return Admin::view('admin/release', ['title' => $rel === null ? 'New release' : 'Release '.$rel['version'], 'rel' => $rel, 'data' => $data, 'errors' => $errors,
            'products' => self::products(), 'incoming' => Releases::incoming(), 'maxUpload' => ini_get('upload_max_filesize'),
            'log' => $rel !== null ? Db::all('SELECT * FROM download_log WHERE release_id = ? ORDER BY id DESC LIMIT 50', [$rel['id']]) : []], $errors === [] ? 200 : 422);
    }

    // Product sub-pages ---------------------------------------------------------------------------------------------

    public static function productPages(Request $r, array $me, string $p): Response
    {
        if (preg_match('#^/admin/product-pages/(new|\d+)(?:/delete)?$#', $p, $m) !== 1) {
            return App::error(404);
        }
        $pg = $m[1] === 'new' ? null : Db::one('SELECT * FROM product_pages WHERE id = ?', [(int) $m[1]]);
        if ($m[1] !== 'new' && $pg === null) {
            return App::error(404);
        }
        $productId = (int) ($pg['product_id'] ?? $r->q('product', $r->input('product_id')));
        $product = Db::one('SELECT * FROM products WHERE id = ?', [$productId]);
        if ($product === null) {
            return App::error(404);
        }
        if ($r->isPost() && str_ends_with($p, '/delete') && $pg !== null) {
            Db::run('DELETE FROM product_pages WHERE id = ?', [$pg['id']]);
            Audit::log('product_page.deleted', (string) $me['email'], $product['slug'].'/'.$pg['slug']);
            Session::flash('Page deleted.');

            return Response::redirect('/admin/products/'.$product['id'].'#subpages');
        }
        $errors = [];
        $data = $pg ?? ['title' => '', 'slug' => '', 'body' => '', 'in_nav' => 1, 'sort' => 10, 'status' => 'draft'];
        if ($r->isPost()) {
            $title = str_limit($r->input('title'), 160);
            $slug = Content::slugify($r->input('slug') !== '' ? $r->input('slug') : $title);
            $data = ['title' => $title, 'slug' => $slug, 'body' => mb_substr(str_replace("\r\n", "\n", $r->input('body')), 0, 200000), 'in_nav' => $r->input('in_nav') === '1' ? 1 : 0,
                'sort' => (int) $r->input('sort'), 'status' => $r->input('status') === 'published' ? 'published' : 'draft', 'updated_at' => now_utc()];
            if ($title === '') {
                $errors['title'] = 'Give the page a title.';
            }
            if (in_array($slug, ['news', 'releases', 'contact', 'legal', 'feed', 'robots', 'sitemap', 'media', 'account', 'admin'], true)
                || Db::one('SELECT id FROM product_pages WHERE product_id = ? AND slug = ? AND id <> ?', [$product['id'], $slug, $pg['id'] ?? 0]) !== null) {
                $errors['slug'] = 'That address is taken. Choose another.';
            }
            if ($errors === []) {
                if ($pg === null) {
                    Db::insert('product_pages', $data + ['product_id' => $product['id']]);
                    $id = (int) Db::pdo()->lastInsertId();
                } else {
                    Db::update('product_pages', $data, ['id' => $pg['id']]);
                    $id = (int) $pg['id'];
                }
                Audit::log('product_page.saved', (string) $me['email'], $product['slug'].'/'.$slug, ['status' => $data['status']]);
                Session::flash('Saved.');

                return Response::redirect('/admin/product-pages/'.$id);
            }
        }

        return Admin::view('admin/product-page', ['title' => ($pg === null ? 'New page' : $pg['title']).' · '.$product['name'], 'pg' => $pg, 'data' => $data,
            'product' => $product, 'errors' => $errors, 'url' => $pg !== null ? Content::productUrl($product, '/'.$pg['slug']) : null], $errors === [] ? 200 : 422);
    }

    // Subscribers ---------------------------------------------------------------------------------------------------

    public static function subscribers(Request $r, array $me, string $p): Response
    {
        if ($p === '/admin/subscribers/export') {
            Audit::log('subscribers.exported', (string) $me['email']);
            $csv = "email,products,confirmed_at,subscribed_at\n";
            foreach (Db::all('SELECT * FROM subscribers WHERE confirmed_at IS NOT NULL AND unsubscribed_at IS NULL ORDER BY id') as $s) {
                $csv .= implode(',', array_map(fn ($v) => '"'.str_replace('"', '""', ltrim((string) $v, '=+-@')).'"',
                    [$s['email'], implode(' ', json_in((string) $s['products_json'])), $s['confirmed_at'], $s['created_at']]))."\n";
            }

            return new Response($csv, 200, ['Content-Type' => 'text/csv; charset=utf-8', 'Content-Disposition' => 'attachment; filename="subscribers-'.gmdate('Y-m-d').'.csv"']);
        }
        if (preg_match('#^/admin/subscribers/(\d+)/remove$#', $p, $m) === 1 && $r->isPost()) {
            Db::run('DELETE FROM subscribers WHERE id = ?', [(int) $m[1]]);
            Audit::log('subscriber.removed', (string) $me['email'], $m[1]);
            Session::flash('Removed.');

            return Response::redirect('/admin/subscribers');
        }
        $stats = Db::one('SELECT SUM(confirmed_at IS NOT NULL AND unsubscribed_at IS NULL) AS active, SUM(confirmed_at IS NULL) AS pending, SUM(unsubscribed_at IS NOT NULL) AS gone FROM subscribers');
        $queue = Db::one('SELECT SUM(sent_at IS NULL AND attempts < 3) AS waiting, SUM(sent_at IS NOT NULL) AS sent, SUM(sent_at IS NULL AND attempts >= 3) AS failed FROM mail_queue');

        return Admin::view('admin/subscribers', ['title' => 'Subscribers', 'stats' => $stats, 'queue' => $queue,
            'rows' => Db::all('SELECT * FROM subscribers ORDER BY id DESC LIMIT 300')]);
    }

    /** @return list<array<string, mixed>> */
    private static function products(): array
    {
        return Db::all('SELECT id, name, slug FROM products ORDER BY sort, name');
    }

    /** @return list<array<string, mixed>> */
    private static function images(): array
    {
        return Db::all("SELECT id, uid, filename, alt FROM media WHERE kind = 'image' ORDER BY id DESC LIMIT 200");
    }
}
