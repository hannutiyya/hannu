<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Payments\Registry;
use Sham\Security\Guard;
use Sham\Store\Ledger;

/**
 * POST /webhooks/{provider}: signature or token checked by the gateway, stored once per event key (idempotent), and the
 * order re-read from the provider's API — the body is never trusted for amounts. GET /webhooks/chapa?trx_ref= is
 * Chapa's browser callback: it only triggers the same server-side verify.
 */
final class Webhooks
{
    public static function handle(Request $r, string $provider): Response
    {
        $g = Registry::get($provider);
        if ($g === null || $provider === 'bank') {
            return Response::json(['message' => 'Not found.'], 404);
        }
        if (! Guard::hit('webhook:'.$provider, $r->ip(), 120, 60)) {
            return Response::json(['message' => 'Too many requests.'], 429);
        }
        if ($r->method === 'GET' && $provider === 'chapa') {
            $ref = $r->q('trx_ref', $r->q('tx_ref'));
            $o = preg_match('/^[a-f0-9]{32}$/', $ref) === 1 ? Db::one("SELECT id FROM orders WHERE ref = ? AND provider = 'chapa'", [$ref]) : null;
            if ($o !== null) {
                Ledger::refresh((string) $o['id']);
            }

            return Response::json(['ok' => true]);
        }
        if (! $r->isPost()) {
            return Response::json(['message' => 'Method not allowed.'], 405);
        }
        $v = $g->verifyWebhook($r->body, $r->headers, $r->query);
        if ($v === null) {
            return Response::json(['message' => 'Signature check failed.'], 401);
        }
        $order = null;
        if (isset($v['ref']) && $v['ref'] !== '') {
            $order = Db::one('SELECT id FROM orders WHERE provider = ? AND ref = ?', [$provider, $v['ref']]);
        } elseif (isset($v['session']) && $v['session'] !== '') {
            $order = Db::one('SELECT id FROM orders WHERE provider = ? AND provider_session = ?', [$provider, $v['session']]);
        }
        $existing = Db::one('SELECT outcome FROM payment_events WHERE provider = ? AND event_key = ?', [$provider, $v['key']]);
        if ($existing !== null && in_array($existing['outcome'], ['processed', 'ignored'], true)) {
            return Response::json(['ok' => true, 'duplicate' => true]);
        }
        $outcome = 'ignored';
        $detail = null;
        if ($order !== null) {
            $status = Ledger::refresh((string) $order['id']);
            $outcome = 'processed';
            $detail = 'order '.$status;
            // A "success" notice the provider's API does not confirm yet: answer 500 so the provider retries later.
            if ($status === 'pending' && preg_match('/success|completed|paid|approved/i', $v['type']) === 1) {
                $outcome = 'retry';
            }
        } else {
            $detail = 'no matching order';
        }
        Db::run('INSERT INTO payment_events (provider, event_key, type, order_id, outcome, detail, created_at) VALUES (?, ?, ?, ?, ?, ?, UTC_TIMESTAMP())
            ON DUPLICATE KEY UPDATE outcome = VALUES(outcome), detail = VALUES(detail), order_id = VALUES(order_id)',
            [$provider, $v['key'], mb_substr($v['type'], 0, 80), $order['id'] ?? null, $outcome, $detail]);

        return $outcome === 'retry' ? Response::json(['message' => 'Not yet confirmed.'], 500) : Response::json(['ok' => true]);
    }
}
