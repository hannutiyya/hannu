<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\App;
use Sham\Audit;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Licensing\Codec;
use Sham\Licensing\Issuer;
use Sham\Payments\Registry;
use Sham\Security\Session;
use Sham\Settings;
use Sham\Store\Catalogue;
use Sham\Store\Ledger;
use Sham\Store\Notifier;

/** Admin: dashboard, orders, licences, enquiries, audit log. */
final class AdminPages
{
    public static function dashboard(array $me): Response
    {
        $content = [
            'posts' => (int) Db::value("SELECT COUNT(*) FROM posts WHERE status = 'published'"),
            'drafts' => (int) Db::value("SELECT COUNT(*) FROM posts WHERE status = 'draft'"),
            'subscribers' => (int) Db::value('SELECT COUNT(*) FROM subscribers WHERE confirmed_at IS NOT NULL AND unsubscribed_at IS NULL'),
            'releases' => (int) Db::value("SELECT COUNT(*) FROM releases WHERE status = 'published'"),
        ];
        if ($me['role'] === 'editor') {
            return Admin::view('admin/dashboard', ['title' => 'Overview', 'alerts' => [], 'stats' => null, 'revenue' => [], 'recent' => [], 'cstats' => $content,
                'latestPosts' => Db::all('SELECT id, title, status, updated_at FROM posts ORDER BY updated_at DESC LIMIT 8')]);
        }
        $alerts = [];
        if (! Codec::available()) {
            $alerts[] = ['bad', 'No licence signing key yet: the store cannot issue keys and check-ins answer 503.', '/admin/signing-key'];
        }
        if (Registry::currencies() === []) {
            $alerts[] = ['bad', 'No payment method is switched on: the store shows prices but cannot take orders.', '/admin/settings/payments'];
        }
        if (Settings::float('store.etb_per_usd') <= 0) {
            $alerts[] = ['warn', 'No birr rate is set, so prices in ETB (Chapa, telebirr, ArifPay) are hidden.', '/admin/settings/store'];
        }
        if (Settings::get('smtp.host') === '') {
            $alerts[] = ['warn', 'No SMTP server is set; e-mail goes through PHP mail(), which often lands in spam.', '/admin/settings/mail'];
        }
        if (Settings::get('company.tin') === '') {
            $alerts[] = ['warn', 'Your TIN is not set; receipts show it once you add it.', '/admin/settings/company'];
        }
        $chain = Audit::verify();
        if (! $chain['ok']) {
            $alerts[] = ['bad', 'The audit log chain is broken at entry '.$chain['broken_at'].': a record was changed or removed.', '/admin/audit'];
        }
        $stats = [
            'pending' => (int) Db::value("SELECT COUNT(*) FROM orders WHERE status = 'pending' AND created_at > UTC_TIMESTAMP() - INTERVAL 7 DAY"),
            'review' => (int) Db::value("SELECT COUNT(*) FROM orders WHERE status = 'review'"),
            'bank' => (int) Db::value("SELECT COUNT(*) FROM orders WHERE status = 'pending' AND provider = 'bank'"),
            'licences' => (int) Db::value("SELECT COUNT(*) FROM licences WHERE status = 'active' AND (expires_at IS NULL OR expires_at > UTC_TIMESTAMP())"),
            'expiring' => (int) Db::value("SELECT COUNT(*) FROM licences WHERE status = 'active' AND expires_at BETWEEN UTC_TIMESTAMP() AND UTC_TIMESTAMP() + INTERVAL 30 DAY"),
            'enquiries' => (int) Db::value("SELECT COUNT(*) FROM enquiries WHERE status = 'new'"),
            'silent' => (int) Db::value("SELECT COUNT(*) FROM licences WHERE status = 'active' AND offline = 0 AND installation_id IS NOT NULL AND last_check_in_at < UTC_TIMESTAMP() - INTERVAL 7 DAY"),
        ];
        $revenue = Db::all("SELECT currency, SUM(total_minor) AS total, COUNT(*) AS n FROM orders WHERE status IN ('paid','fulfilled') AND test_mode = 0
            AND paid_at >= DATE_FORMAT(UTC_TIMESTAMP(), '%Y-%m-01') GROUP BY currency");
        $recent = Db::all('SELECT o.*, p.name AS product_name FROM orders o JOIN products p ON p.id = o.product_id ORDER BY o.created_at DESC LIMIT 10');

        if ($me['role'] === 'owner' && \Sham\Migrator::pending(Db::pdo()) !== []) {
            $alerts[] = ['warn', 'Database upgrades are waiting.', '/admin/system'];
        }
        if ($me['role'] === 'owner' && is_file(Install::tokenFile())) {
            $alerts[] = ['bad', 'app/install-token.txt is still on the server. Delete it.', '/admin/system'];
        }
        if ($me['role'] !== 'owner') {
            $alerts = array_values(array_filter($alerts, fn ($a) => ! str_starts_with($a[2], '/admin/s')));
        }

        return Admin::view('admin/dashboard', ['title' => 'Overview', 'alerts' => $alerts, 'stats' => $stats, 'revenue' => $revenue, 'recent' => $recent, 'cstats' => $content, 'latestPosts' => []]);
    }

    public static function orders(Request $r, array $me, string $p): Response
    {
        if (preg_match('#^/admin/orders/([0-9A-Z]{26})(?:/([a-z-]+))?$#', $p, $m) === 1) {
            $o = Db::one('SELECT o.*, p.name AS product_name, p.slug AS product_slug FROM orders o JOIN products p ON p.id = o.product_id WHERE o.id = ?', [$m[1]]);
            if ($o === null) {
                return App::error(404);
            }
            $action = $m[2] ?? '';
            if ($r->isPost()) {
                switch ($action) {
                    case 'refresh':
                        $st = Ledger::refresh((string) $o['id']);
                        Session::flash('Checked with '.$o['provider'].': the order is '.$st.'.');
                        break;
                    case 'mark-paid':
                        if (! in_array($o['status'], ['pending', 'failed', 'cancelled', 'review'], true)) {
                            Session::flash('This order is already '.$o['status'].'.', 'bad');
                            break;
                        }
                        $ref = str_limit($r->input('reference'), 120);
                        if ($ref === '' || ! Admin::confirmCode($me, $r->input('confirm_code'))) {
                            Session::flash('Give the bank reference and a fresh authenticator code.', 'bad');
                            break;
                        }
                        if ($o['status'] === 'review') {
                            Db::update('orders', ['status' => 'pending'], ['id' => $o['id']]);
                        }
                        $st = Ledger::markPaidByStaff((string) $o['id'], $ref, (string) $me['email']);
                        Session::flash('Marked as paid; the order is '.$st.' and the buyer has been e-mailed.');
                        break;
                    case 'resend':
                        if (in_array($o['status'], ['fulfilled'], true)) {
                            Notifier::fulfilled((string) $o['id']);
                            Session::flash('The licence e-mail was sent again.');
                        }
                        break;
                    case 'cancel':
                        if ($o['status'] === 'pending') {
                            Db::update('orders', ['status' => 'cancelled', 'failure_reason' => 'Cancelled by '.$me['email']], ['id' => $o['id']]);
                            Audit::log('order.cancelled', (string) $me['email'], (string) $o['id']);
                            Session::flash('Order cancelled.');
                        }
                        break;
                }

                return Response::redirect('/admin/orders/'.$o['id']);
            }
            $events = Db::all('SELECT * FROM payment_events WHERE order_id = ? ORDER BY id DESC LIMIT 50', [$o['id']]);

            return Admin::view('admin/order', ['title' => 'Order '.$o['id'], 'o' => $o, 'events' => $events]);
        }
        $status = $r->q('status');
        $q = trim($r->q('q'));
        $where = [];
        $args = [];
        if (in_array($status, ['pending', 'paid', 'fulfilled', 'failed', 'cancelled', 'review', 'refunded'], true)) {
            $where[] = 'o.status = ?';
            $args[] = $status;
        }
        if ($q !== '') {
            $where[] = '(o.customer_email LIKE ? OR o.customer_name LIKE ? OR o.id = ? OR o.receipt_number = ? OR o.ref LIKE ?)';
            $like = '%'.addcslashes($q, '%_\\').'%';
            array_push($args, $like, $like, $q, $q, strtolower(substr($q, 0, 12)).'%');
        }
        $rows = Db::all('SELECT o.*, p.name AS product_name FROM orders o JOIN products p ON p.id = o.product_id'.($where !== [] ? ' WHERE '.implode(' AND ', $where) : '')
            .' ORDER BY o.created_at DESC LIMIT 200', $args);

        return Admin::view('admin/orders', ['title' => 'Orders', 'rows' => $rows, 'status' => $status, 'q' => $q]);
    }

    public static function licences(Request $r, array $me, string $p): Response
    {
        if ($p === '/admin/licences/new') {
            return self::issue($r, $me);
        }
        if (preg_match('#^/admin/licences/(LIC-[0-9A-Z]{26})(?:/([a-z-]+))?$#', $p, $m) === 1) {
            $l = Db::one('SELECT l.*, p.name AS product_name FROM licences l JOIN products p ON p.id = l.product_id WHERE l.id = ?', [$m[1]]);
            if ($l === null) {
                return App::error(404);
            }
            if ($r->isPost()) {
                $who = (string) $me['email'];
                switch ($m[2] ?? '') {
                    case 'extend':
                        $months = max(0, min(120, (int) $r->input('months')));
                        $upd = max(0, min(120, (int) $r->input('update_months')));
                        if ($months + $upd === 0) {
                            Session::flash('Give a number of months.', 'bad');
                            break;
                        }
                        Issuer::extend((string) $l['id'], $months, $upd, $who);
                        Session::flash('Extended. The installation receives the new key at its next check-in.');
                        break;
                    case 'revoke':
                        $reason = str_limit($r->input('reason'), 240);
                        if ($reason === '' || ! Admin::confirmCode($me, $r->input('confirm_code'))) {
                            Session::flash('Give a reason and a fresh authenticator code.', 'bad');
                            break;
                        }
                        Db::update('licences', ['status' => 'revoked', 'revoked_reason' => $reason], ['id' => $l['id']]);
                        Audit::log('licence.revoked', $who, (string) $l['id'], ['reason' => $reason]);
                        Session::flash('Revoked. The installation becomes read-only at its next check-in.');
                        break;
                    case 'reinstate':
                        Db::update('licences', ['status' => 'active', 'revoked_reason' => null], ['id' => $l['id']]);
                        Audit::log('licence.reinstated', $who, (string) $l['id']);
                        Session::flash('Reinstated.');
                        break;
                    case 'release':
                        Db::update('licences', ['installation_id' => null, 'bound_at' => null], ['id' => $l['id']]);
                        Audit::log('licence.released', $who, (string) $l['id'], ['was' => $l['installation_id']]);
                        Session::flash('Released. The next installation that checks in with this key becomes its home.');
                        break;
                    case 'resend':
                        \Sham\Mailer::send((string) $l['customer_email'], 'Your '.$l['product_name'].' licence key',
                            "Dear {$l['customer_name']},\n\nAs requested, here is your licence key for ".implode(', ', json_in((string) $l['domains_json'])).":\n\n{$l['token']}\n\n— "
                            .Settings::get('company.name')."\n", Settings::get('company.support_email'));
                        Audit::log('licence.resent', $who, (string) $l['id']);
                        Session::flash('The key was e-mailed to '.$l['customer_email'].'.');
                        break;
                }

                return Response::redirect('/admin/licences/'.$l['id']);
            }
            $orders = Db::all('SELECT * FROM orders WHERE licence_id = ? OR renews_licence_id = ? ORDER BY created_at DESC', [$l['id'], $l['id']]);

            return Admin::view('admin/licence', ['title' => 'Licence '.$l['id'], 'l' => $l, 'orders' => $orders]);
        }
        $q = trim($r->q('q'));
        $args = [];
        $where = '';
        if ($q !== '') {
            $like = '%'.addcslashes(mb_strtolower($q), '%_\\').'%';
            $where = ' WHERE l.id = ? OR l.customer_email LIKE ? OR l.customer_name LIKE ? OR l.domains_json LIKE ?';
            $args = [strtoupper($q), $like, $like, $like];
        }
        $rows = Db::all('SELECT l.*, p.name AS product_name FROM licences l JOIN products p ON p.id = l.product_id'.$where.' ORDER BY l.created_at DESC LIMIT 200', $args);

        return Admin::view('admin/licences', ['title' => 'Licences', 'rows' => $rows, 'q' => $q]);
    }

    private static function issue(Request $r, array $me): Response
    {
        $products = Db::all("SELECT * FROM products WHERE licence_kind = 'mediaos' ORDER BY sort");
        $editions = [];
        foreach ($products as $pr) {
            $editions[$pr['id']] = Catalogue::editions((int) $pr['id'], false);
        }
        $vars = ['title' => 'Issue a licence', 'products' => $products, 'editions' => $editions, 'errors' => [], 'old' => ['term' => 'year', 'months' => '12', 'update_months' => '12']];
        if (! $r->isPost()) {
            return Admin::view('admin/licence-new', $vars);
        }
        $old = ['product' => $r->input('product'), 'edition' => $r->input('edition'), 'term' => $r->input('term'), 'months' => $r->input('months'),
            'update_months' => $r->input('update_months'), 'domains' => $r->input('domains'), 'name' => str_limit($r->input('name'), 160),
            'email' => mb_strtolower(trim($r->input('email'))), 'country' => strtoupper(trim($r->input('country'))), 'offline' => $r->input('offline') === '1',
            'notes' => str_limit($r->input('notes'), 400)];
        $errors = [];
        $product = Db::one("SELECT * FROM products WHERE id = ? AND licence_kind = 'mediaos'", [(int) $old['product']]);
        if ($product === null) {
            $errors['product'] = 'Choose a product.';
        }
        if ($product !== null && Db::one('SELECT id FROM editions WHERE product_id = ? AND ekey = ?', [$product['id'], $old['edition']]) === null) {
            $errors['edition'] = 'Choose an edition of that product.';
        }
        if (! in_array($old['term'], ['year', 'perpetual', 'custom'], true)) {
            $errors['term'] = 'Choose a term.';
        }
        if (Issuer::normaliseDomains($r->list('domains')) === []) {
            $errors['domains'] = 'Give at least one domain.';
        }
        if (mb_strlen($old['name']) < 2) {
            $errors['name'] = 'Enter the licensee.';
        }
        if (! filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Enter a valid e-mail address.';
        }
        if (! Codec::available()) {
            $errors['product'] = 'Import the signing key first (Signing key).';
        }
        if (! Admin::confirmCode($me, $r->input('confirm_code'))) {
            $errors['confirm_code'] = 'Enter a fresh authenticator code.';
        }
        if ($errors !== []) {
            return Admin::view('admin/licence-new', ['errors' => $errors, 'old' => $old] + $vars, 422);
        }
        $l = Issuer::issue((int) $product['id'], ['name' => $old['name'], 'email' => $old['email'], 'country' => preg_match('/^[A-Z]{2}$/', $old['country']) === 1 ? $old['country'] : null],
            $old['edition'], $old['term'], $r->list('domains'), $old['term'] === 'custom' ? max(1, min(120, (int) $old['months'])) : null,
            max(1, min(120, (int) $old['update_months'])), null, $old['offline'], (string) $me['email'], $old['notes'] !== '' ? $old['notes'] : 'Issued by '.$me['email']);
        Session::flash('Licence issued. Send the key with "E-mail the key" or copy it.');

        return Response::redirect('/admin/licences/'.$l['id']);
    }

    public static function enquiries(Request $r, array $me, string $p): Response
    {
        if (preg_match('#^/admin/enquiries/(\d+)/(handled|new)$#', $p, $m) === 1 && $r->isPost()) {
            Db::update('enquiries', ['status' => $m[2]], ['id' => (int) $m[1]]);
            Audit::log('enquiry.'.$m[2], (string) $me['email'], $m[1]);

            return Response::redirect('/admin/enquiries');
        }
        $show = $r->q('show') === 'all' ? '' : " WHERE e.status = 'new'";
        $rows = Db::all('SELECT e.*, p.name AS product_name FROM enquiries e LEFT JOIN products p ON p.id = e.product_id'.$show.' ORDER BY e.created_at DESC LIMIT 200');

        return Admin::view('admin/enquiries', ['title' => 'Enquiries', 'rows' => $rows, 'all' => $show === '']);
    }

    public static function audit(array $me): Response
    {
        return Admin::view('admin/audit', ['title' => 'Audit log', 'rows' => Db::all('SELECT * FROM audit_log ORDER BY id DESC LIMIT 300'), 'chain' => Audit::verify()]);
    }
}
