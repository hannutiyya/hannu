<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\App;
use Sham\Audit;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Security\Guard;
use Sham\Security\Session;
use Sham\Security\Totp;
use Sham\View;

/**
 * store.sham.et/admin. Every admin uses a password and an authenticator app (TOTP); there is no way in without both.
 * Sign-in: password (rate limited per address and per account, account lock after repeated failures) → code →
 * session regenerated. Owner-only areas: settings, payment keys, signing key, admins, products and pages. The most
 * sensitive changes ask for a fresh authenticator code again.
 */
final class Admin
{
    /** Which roles may open each admin area. The owner may open everything. */
    public const AREAS = [
        '' => ['staff', 'editor'], 'account' => ['staff', 'editor'], 'audit' => ['staff'],
        'orders' => ['staff'], 'licences' => ['staff'], 'enquiries' => ['staff'], 'subscribers' => ['staff', 'editor'],
        'posts' => ['editor'], 'media' => ['editor'], 'releases' => ['editor'], 'product-pages' => ['editor'], 'pages' => ['editor'], 'products' => ['editor'],
        'settings' => [], 'signing-key' => [], 'admins' => [], 'system' => [],
    ];

    public const ROLES = ['owner' => 'Owner: everything', 'staff' => 'Sales: orders, licences, enquiries', 'editor' => 'Editor: news, pages, products, media, releases'];

    /** @param array<string, mixed>|null $me */
    public static function can(?array $me, string $area): bool
    {
        if ($me === null) {
            return false;
        }

        return $me['role'] === 'owner' || in_array((string) $me['role'], self::AREAS[$area] ?? [], true);
    }

    public static function handle(Request $r): Response
    {
        $p = rtrim($r->path, '/') ?: '/admin';
        $resp = match ($p) {
            '/admin/login' => self::login($r),
            '/admin/2fa' => self::twoFactor($r),
            '/admin/2fa/setup' => self::setup($r),
            '/admin/logout' => self::logout($r),
            default => null,
        };
        if ($resp !== null) {
            return self::noStore($resp);
        }
        $me = self::me();
        if ($me === null) {
            return Response::redirect('/admin/login');
        }
        $area = explode('/', trim(substr($p, 6), '/'))[0] ?? '';
        if (! self::can($me, $area)) {
            return App::error(403, 'Your role does not include this part of the admin. Ask the owner.');
        }
        $resp = match (true) {
            $p === '/admin' => AdminPages::dashboard($me),
            $area === 'orders' => AdminPages::orders($r, $me, $p),
            $area === 'licences' => AdminPages::licences($r, $me, $p),
            $area === 'enquiries' => AdminPages::enquiries($r, $me, $p),
            $area === 'products' => AdminContent::products($r, $me, $p),
            $area === 'pages' => AdminContent::pages($r, $me, $p),
            $area === 'posts' => AdminCms::posts($r, $me, $p),
            $area === 'media' => AdminCms::media($r, $me, $p),
            $area === 'releases' => AdminCms::releases($r, $me, $p),
            $area === 'product-pages' => AdminCms::productPages($r, $me, $p),
            $area === 'subscribers' => AdminCms::subscribers($r, $me, $p),
            $area === 'system' => AdminSystem::handle($r, $me, $p),
            $area === 'settings' => AdminSettings::settings($r, $me, $p),
            $area === 'signing-key' => AdminSettings::signingKey($r, $me),
            $area === 'admins' => AdminSettings::admins($r, $me, $p),
            $area === 'audit' => AdminPages::audit($me),
            $area === 'account' => AdminSettings::account($r, $me),
            default => App::error(404),
        };

        return self::noStore($resp);
    }

    /** @return array<string, mixed>|null */
    public static function me(): ?array
    {
        $id = $_SESSION['admin_id'] ?? null;
        if (! is_int($id)) {
            return null;
        }
        $a = Db::one('SELECT * FROM admins WHERE id = ? AND active = 1', [$id]);
        if ($a === null || ($_SESSION['admin_pw'] ?? '') !== substr(hash('sha256', (string) $a['password_hash']), 0, 16)) {
            // Deactivated, or the password changed elsewhere: this session ends.
            Session::forget();

            return null;
        }

        return $a;
    }

    /** A fresh authenticator code for the most sensitive changes. */
    public static function confirmCode(array $me, string $code): bool
    {
        $secret = Guard::decrypt((string) $me['totp_secret']);
        if ($secret === '' || ! Guard::hit('admin-confirm', (string) $me['id'], 10, 900)) {
            return false;
        }
        $step = Totp::verify($secret, $code, (int) $me['totp_last_step']);
        if ($step === null) {
            return false;
        }
        Db::update('admins', ['totp_last_step' => $step], ['id' => $me['id']]);

        return true;
    }

    /** @param array<string, mixed> $vars */
    public static function view(string $template, array $vars, int $status = 200): Response
    {
        return Response::html(View::render($template, $vars + ['flash' => Session::takeFlash(), 'me' => self::me()], 'admin/layout'), $status);
    }

    private static function noStore(Response $r): Response
    {
        return $r->header('Cache-Control', 'no-store')->header('X-Robots-Tag', 'noindex, nofollow')->header('Referrer-Policy', 'same-origin');
    }

    private static function login(Request $r): Response
    {
        if (self::me() !== null) {
            return Response::redirect('/admin');
        }
        $vars = ['title' => 'Sign in', 'error' => null, 'email' => ''];
        if (! $r->isPost()) {
            return Response::html(View::render('admin/login', $vars, 'admin/bare'));
        }
        $email = mb_strtolower(trim($r->input('email')));
        $password = $r->input('password');
        $vars['email'] = $email;
        $ip = $r->ip();
        if (! Guard::hit('login-ip', $ip, 20, 900) || ! Guard::hit('login-email', $email, 8, 900)) {
            return Response::html(View::render('admin/login', ['error' => 'Too many attempts. Wait 15 minutes and try again.'] + $vars, 'admin/bare'), 429);
        }
        $a = Db::one('SELECT * FROM admins WHERE email = ? AND active = 1', [$email]);
        $locked = $a !== null && $a['locked_until'] !== null && strtotime($a['locked_until'].' UTC') > time();
        // Same work and the same answer whether or not the account exists.
        $ok = password_verify($password, $a !== null ? (string) $a['password_hash'] : Guard::hashPassword(token(8)));
        if ($a === null || ! $ok || $locked) {
            if ($a !== null && ! $locked) {
                $fails = (int) $a['failed_logins'] + 1;
                Db::update('admins', ['failed_logins' => $fails, 'locked_until' => $fails >= 10 ? gmdate('Y-m-d H:i:s', time() + 1800) : null], ['id' => $a['id']]);
            }
            Audit::log('admin.login_failed', $email, null, ['ip' => Guard::ipHash($ip)]);

            return Response::html(View::render('admin/login', ['error' => 'The e-mail address or password is wrong, or the account is locked for a while.'] + $vars, 'admin/bare'), 422);
        }
        if (password_needs_rehash((string) $a['password_hash'], defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT)) {
            Db::update('admins', ['password_hash' => Guard::hashPassword($password)], ['id' => $a['id']]);
        }
        Session::regenerate();
        $_SESSION['pending_admin'] = (int) $a['id'];
        $_SESSION['pending_at'] = time();

        return Response::redirect($a['totp_secret'] !== null && $a['totp_secret'] !== '' ? '/admin/2fa' : '/admin/2fa/setup');
    }

    /** @return array<string, mixed>|null */
    private static function pending(): ?array
    {
        $id = $_SESSION['pending_admin'] ?? null;
        if (! is_int($id) || time() - (int) ($_SESSION['pending_at'] ?? 0) > 600) {
            return null;
        }

        return Db::one('SELECT * FROM admins WHERE id = ? AND active = 1', [$id]);
    }

    private static function twoFactor(Request $r): Response
    {
        $a = self::pending();
        if ($a === null || $a['totp_secret'] === null || $a['totp_secret'] === '') {
            return Response::redirect('/admin/login');
        }
        if (! $r->isPost()) {
            return Response::html(View::render('admin/2fa', ['title' => 'Authenticator code', 'error' => null], 'admin/bare'));
        }
        if (! Guard::hit('2fa', (string) $a['id'], 6, 900)) {
            return Response::html(View::render('admin/2fa', ['title' => 'Authenticator code', 'error' => 'Too many attempts. Wait 15 minutes.'], 'admin/bare'), 429);
        }
        $code = preg_replace('/\s+/', '', $r->input('code')) ?? '';
        $step = Totp::verify(Guard::decrypt((string) $a['totp_secret']), $code, (int) $a['totp_last_step']);
        $usedRecovery = false;
        $recovery = strtoupper(str_replace('-', '', $code));
        if ($step === null && strlen($recovery) === 10) {
            $recovery = substr($recovery, 0, 5).'-'.substr($recovery, 5);
            $codes = json_in((string) $a['recovery_codes']);
            foreach ($codes as $i => $h) {
                if (is_string($h) && password_verify($recovery, $h)) {
                    unset($codes[$i]);
                    Db::update('admins', ['recovery_codes' => json_out(array_values($codes))], ['id' => $a['id']]);
                    $usedRecovery = true;
                    break;
                }
            }
        }
        if ($step === null && ! $usedRecovery) {
            Audit::log('admin.2fa_failed', (string) $a['email']);

            return Response::html(View::render('admin/2fa', ['title' => 'Authenticator code', 'error' => 'That code is not right. Use the newest code in your authenticator app.'], 'admin/bare'), 422);
        }
        self::signIn($a, $step, $usedRecovery ? 'recovery code' : 'authenticator');

        return Response::redirect('/admin');
    }

    private static function setup(Request $r): Response
    {
        $a = self::pending();
        if ($a === null || ($a['totp_secret'] !== null && $a['totp_secret'] !== '')) {
            return Response::redirect('/admin/login');
        }
        if (! is_string($_SESSION['totp_new'] ?? null)) {
            $_SESSION['totp_new'] = Totp::newSecret();
        }
        $secret = $_SESSION['totp_new'];
        $vars = ['title' => 'Set up two-step sign-in', 'secret' => $secret, 'uri' => Totp::uri($secret, (string) $a['email']), 'error' => null, 'codes' => null];
        if (! $r->isPost()) {
            return Response::html(View::render('admin/2fa-setup', $vars, 'admin/bare'));
        }
        if (! Guard::hit('2fa', (string) $a['id'], 6, 900)) {
            return Response::html(View::render('admin/2fa-setup', ['error' => 'Too many attempts. Wait 15 minutes.'] + $vars, 'admin/bare'), 429);
        }
        $step = Totp::verify($secret, $r->input('code'));
        if ($step === null) {
            return Response::html(View::render('admin/2fa-setup', ['error' => 'That code is not right. Check the time on your phone and try the newest code.'] + $vars, 'admin/bare'), 422);
        }
        $codes = [];
        $hashes = [];
        for ($i = 0; $i < 10; $i++) {
            $c = strtoupper(substr(Totp::base32(random_bytes(10)), 0, 5).'-'.substr(Totp::base32(random_bytes(10)), 0, 5));
            $codes[] = $c;
            $hashes[] = password_hash($c, PASSWORD_BCRYPT);
        }
        Db::update('admins', ['totp_secret' => Guard::encrypt($secret), 'totp_last_step' => $step, 'recovery_codes' => json_out($hashes)], ['id' => $a['id']]);
        unset($_SESSION['totp_new']);
        Audit::log('admin.2fa_enrolled', (string) $a['email']);
        $a = (array) Db::one('SELECT * FROM admins WHERE id = ?', [$a['id']]);
        self::signIn($a, $step, 'authenticator (new)');

        return Response::html(View::render('admin/2fa-setup', ['codes' => $codes] + $vars, 'admin/bare'));
    }

    /** @param array<string, mixed> $a */
    private static function signIn(array $a, ?int $step, string $how): void
    {
        Session::regenerate();
        unset($_SESSION['pending_admin'], $_SESSION['pending_at']);
        $_SESSION['admin_id'] = (int) $a['id'];
        $_SESSION['admin_pw'] = substr(hash('sha256', (string) $a['password_hash']), 0, 16);
        $set = ['failed_logins' => 0, 'locked_until' => null, 'last_login_at' => now_utc()];
        if ($step !== null) {
            $set['totp_last_step'] = $step;
        }
        Db::update('admins', $set, ['id' => $a['id']]);
        Guard::clear('login-email', (string) $a['email']);
        Audit::log('admin.signed_in', (string) $a['email'], null, ['with' => $how]);
    }

    private static function logout(Request $r): Response
    {
        if ($r->isPost()) {
            $me = self::me();
            if ($me !== null) {
                Audit::log('admin.signed_out', (string) $me['email']);
            }
            Session::forget();
        }

        return Response::redirect('/admin/login');
    }
}
