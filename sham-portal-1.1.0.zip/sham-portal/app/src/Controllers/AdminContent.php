<?php

declare(strict_types=1);

namespace Sham\Controllers;

use Sham\App;
use Sham\Audit;
use Sham\Db;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Security\Session;

/** Admin (owner): products with their editions and prices, and the text pages (about, legal). */
final class AdminContent
{

    public static function products(Request $r, array $me, string $p): Response
    {
        if ($p === '/admin/products') {
            if ($r->isPost()) {
                $slug = strtolower(trim($r->input('slug')));
                $name = str_limit($r->input('name'), 120);
                if (preg_match('/^[a-z0-9-]{2,40}$/', $slug) !== 1 || $name === '' || Db::one('SELECT id FROM products WHERE slug = ?', [$slug]) !== null) {
                    Session::flash('Give a new product a unique short name (letters, digits, dashes) and a name.', 'bad');

                    return Response::redirect('/admin/products');
                }
                Db::insert('products', ['slug' => $slug, 'name' => $name, 'summary' => '', 'body' => '', 'status' => 'draft', 'sort' => 50, 'updated_at' => now_utc()]);
                Audit::log('product.created', (string) $me['email'], $slug);

                return Response::redirect('/admin/products/'.Db::pdo()->lastInsertId());
            }

            return Admin::view('admin/products', ['title' => 'Products', 'rows' => Db::all('SELECT * FROM products ORDER BY sort, name')]);
        }
        if (preg_match('#^/admin/products/(\d+)(?:/(editions|edition-new))?$#', $p, $m) !== 1) {
            return App::error(404);
        }
        $product = Db::one('SELECT * FROM products WHERE id = ?', [(int) $m[1]]);
        if ($product === null) {
            return App::error(404);
        }
        $errors = [];
        if ($r->isPost() && ($m[2] ?? '') !== '' && $me['role'] !== 'owner') {
            return App::error(403, 'Only the owner can change editions and prices.');
        }
        if ($r->isPost() && ($m[2] ?? '') === '') {
            $host = strtolower(trim($r->input('host')));
            $accent = strtoupper(trim($r->input('accent')));
            $set = [
                'name' => str_limit($r->input('name'), 120), 'host' => $host !== '' ? $host : null, 'tagline' => str_limit($r->input('tagline'), 255),
                'summary' => str_limit($r->input('summary'), 2000), 'body' => mb_substr(str_replace("\r\n", "\n", $r->input('body')), 0, 60000),
                'accent' => preg_match('/^#[0-9A-F]{6}$/', $accent) === 1 ? $accent : '#C8102E',
                'licence_kind' => $me['role'] !== 'owner' ? $product['licence_kind'] : (in_array($r->input('licence_kind'), ['mediaos', 'manual'], true) ? $r->input('licence_kind') : 'manual'),
                'trial_note' => str_limit($r->input('trial_note'), 255), 'category' => str_limit($r->input('category'), 60),
                'regulatory_note' => str_limit($r->input('regulatory_note'), 500),
                'logo_media_id' => ctype_digit($r->input('logo_media_id')) && Db::one("SELECT id FROM media WHERE id = ? AND kind = 'image'", [(int) $r->input('logo_media_id')]) !== null ? (int) $r->input('logo_media_id') : null,
                'status' => in_array($r->input('status'), ['published', 'draft'], true) ? $r->input('status') : 'draft', 'sort' => (int) $r->input('sort'),
                'updated_at' => now_utc(),
            ];
            if ($host !== '' && preg_match('/^([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $host) !== 1) {
                $errors['host'] = 'Give a host name such as media.sham.et, or leave it empty.';
            } elseif ($host !== '' && Db::one('SELECT id FROM products WHERE host = ? AND id <> ?', [$host, $product['id']]) !== null) {
                $errors['host'] = 'Another product already uses that host name.';
            }
            if ($set['name'] === '') {
                $errors['name'] = 'Give the product a name.';
            }
            if ($errors === []) {
                Db::update('products', $set, ['id' => $product['id']]);
                Audit::log('product.updated', (string) $me['email'], (string) $product['slug']);
                Session::flash('Saved.');

                return Response::redirect('/admin/products/'.$product['id']);
            }
            $product = array_merge($product, $set);
        }
        if ($r->isPost() && ($m[2] ?? '') === 'editions') {
            foreach ((array) ($r->post['ed'] ?? []) as $id => $e) {
                if (! is_array($e) || ! ctype_digit((string) $id)) {
                    continue;
                }
                $limits = json_decode((string) ($e['limits'] ?? '{}'), true);
                $features = json_decode((string) ($e['features'] ?? '[]'), true);
                if (! is_array($limits) || ! is_array($features)) {
                    Session::flash('Limits and features must be valid JSON (edition '.(int) $id.' not saved).', 'bad');

                    continue;
                }
                Db::update('editions', [
                    'label' => str_limit((string) ($e['label'] ?? ''), 80), 'blurb' => str_limit((string) ($e['blurb'] ?? ''), 255),
                    'price_usd_year' => max(0, (int) ($e['price'] ?? 0)), 'perpetual_multiple' => max(1, min(10, (int) ($e['multiple'] ?? 3))),
                    'max_domains' => max(1, min(100, (int) ($e['domains'] ?? 1))), 'limits_json' => json_out($limits), 'features_json' => json_out(array_values($features)),
                    'quote_only' => ! empty($e['quote']) ? 1 : 0, 'active' => ! empty($e['active']) ? 1 : 0, 'sort' => (int) ($e['sort'] ?? 0),
                ], ['id' => (int) $id, 'product_id' => $product['id']]);
            }
            Audit::log('editions.updated', (string) $me['email'], (string) $product['slug']);
            Session::flash('Editions saved.');

            return Response::redirect('/admin/products/'.$product['id']);
        }
        if ($r->isPost() && ($m[2] ?? '') === 'edition-new') {
            $key = strtolower(trim($r->input('ekey')));
            if (preg_match('/^[a-z0-9_]{2,40}$/', $key) === 1 && Db::one('SELECT id FROM editions WHERE product_id = ? AND ekey = ?', [$product['id'], $key]) === null) {
                Db::insert('editions', ['product_id' => $product['id'], 'ekey' => $key, 'label' => ucfirst($key), 'limits_json' => '{}', 'features_json' => '[]',
                    'quote_only' => 1, 'sort' => 99]);
                Audit::log('edition.created', (string) $me['email'], $product['slug'].'/'.$key);
            } else {
                Session::flash('Give the new edition a unique key (letters, digits, underscores).', 'bad');
            }

            return Response::redirect('/admin/products/'.$product['id']);
        }

        return Admin::view('admin/product', ['title' => $product['name'], 'product' => $product, 'errors' => $errors, 'owner' => $me['role'] === 'owner',
            'images' => Db::all("SELECT id, uid, filename, alt FROM media WHERE kind = 'image' ORDER BY id DESC LIMIT 200"),
            'subpages' => Db::all('SELECT id, slug, title, status, sort, in_nav FROM product_pages WHERE product_id = ? ORDER BY sort, title', [$product['id']]),
            'editions' => Db::all('SELECT * FROM editions WHERE product_id = ? ORDER BY sort, id', [$product['id']])], $errors === [] ? 200 : 422);
    }

    public static function pages(Request $r, array $me, string $p): Response
    {
        if ($p === '/admin/pages') {
            if ($r->isPost()) {
                $slug = strtolower(trim($r->input('slug')));
                if (preg_match('/^[a-z0-9-]{2,60}$/', $slug) !== 1 || Db::one('SELECT id FROM pages WHERE slug = ?', [$slug]) !== null) {
                    Session::flash('Give the page a unique address (letters, digits, dashes).', 'bad');

                    return Response::redirect('/admin/pages');
                }
                Db::insert('pages', ['slug' => $slug, 'title' => ucfirst(str_replace('-', ' ', $slug)), 'body' => '', 'status' => 'draft', 'updated_at' => now_utc()]);

                return Response::redirect('/admin/pages/'.Db::pdo()->lastInsertId());
            }

            return Admin::view('admin/pages', ['title' => 'Pages', 'rows' => Db::all('SELECT id, slug, title, status, in_nav, in_footer, updated_at FROM pages ORDER BY slug')]);
        }
        if (preg_match('#^/admin/pages/(\d+)$#', $p, $m) !== 1) {
            return App::error(404);
        }
        $page = Db::one('SELECT * FROM pages WHERE id = ?', [(int) $m[1]]);
        if ($page === null) {
            return App::error(404);
        }
        if ($r->isPost()) {
            Db::update('pages', ['title' => str_limit($r->input('title'), 160) ?: $page['title'], 'body' => mb_substr(str_replace("\r\n", "\n", $r->input('body')), 0, 200000),
                'status' => in_array($r->input('status'), ['published', 'draft'], true) ? $r->input('status') : 'draft',
                'in_nav' => $r->input('in_nav') === '1' ? 1 : 0, 'in_footer' => $r->input('in_footer') === '1' ? 1 : 0, 'updated_at' => now_utc()], ['id' => $page['id']]);
            Audit::log('page.updated', (string) $me['email'], (string) $page['slug']);
            Session::flash('Saved.');

            return Response::redirect('/admin/pages/'.$page['id']);
        }

        return Admin::view('admin/page', ['title' => $page['title'], 'page' => $page, 'url' => \Sham\Config::url('company', $page['slug'] === 'about' ? '/about' : '/legal/'.$page['slug'])]);
    }
}
