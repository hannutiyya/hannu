<?php

declare(strict_types=1);

namespace Sham;

use Sham\Security\Guard;

/**
 * Business settings stored in MySQL and edited in the admin: company details, prices and the birr rate, VAT, payment
 * rails, mail. Keys listed in SECRET are stored encrypted with the app secret and never shown back in full.
 */
final class Settings
{
    public const SECRET = [
        'stripe.secret', 'stripe.webhook_secret', 'paypal.client_secret', 'chapa.secret_key', 'chapa.webhook_secret',
        'telebirr.app_secret', 'telebirr.private_key', 'arifpay.api_key', 'smtp.pass', 'licence.private_key',
    ];

    /** @var array<string, string>|null */
    private static ?array $cache = null;

    /** @return array<string, string> */
    public static function defaults(): array
    {
        return [
            'company.name' => 'Sham Software Systems Development General Trading PLC',
            'company.short' => 'Sham',
            'company.tagline' => 'Software and systems for media, health and business, made in Ethiopia.',
            'company.address' => 'Addis Ababa, Ethiopia',
            'company.tin' => '',
            'company.vat_no' => '',
            'company.phone' => '',
            'company.sales_email' => 'sales@sham.et',
            'company.support_email' => 'support@sham.et',
            'company.notify_email' => 'sales@sham.et',
            'company.reg_no' => '',
            'company.privacy_email' => 'privacy@sham.et',
            'company.security_email' => 'security@sham.et',
            'company.support_channels' => 'e-mail to support@sham.et, answered within two working days',
            'company.hosting_provider' => '',
            'company.hosting_country' => '',
            'company.email_host' => '',
            'company.download_location' => 'store.sham.et',
            'store.etb_per_usd' => '0',
            'store.vat_percent' => '15',
            'store.vat_countries' => 'ET',
            'store.update_renewal_percent' => '20',
            'store.pending_hours' => '48',
            'stripe.enabled' => '0', 'stripe.secret' => '', 'stripe.webhook_secret' => '', 'stripe.base_url' => 'https://api.stripe.com/v1',
            'paypal.enabled' => '0', 'paypal.client_id' => '', 'paypal.client_secret' => '', 'paypal.webhook_id' => '', 'paypal.mode' => 'sandbox',
            'chapa.enabled' => '0', 'chapa.secret_key' => '', 'chapa.webhook_secret' => '', 'chapa.base_url' => 'https://api.chapa.co/v1',
            'telebirr.enabled' => '0', 'telebirr.fabric_app_id' => '', 'telebirr.app_secret' => '', 'telebirr.merchant_app_id' => '',
            'telebirr.merchant_code' => '', 'telebirr.private_key' => '', 'telebirr.public_key' => '', 'telebirr.test_mode' => '1',
            'telebirr.base_url' => 'https://developerportal.ethiotelebirr.et:38443/apiaccess/payment/gateway',
            'telebirr.web_base_url' => 'https://developerportal.ethiotelebirr.et:38443/payment/web/paygate?',
            'arifpay.enabled' => '0', 'arifpay.api_key' => '', 'arifpay.beneficiary_account' => '', 'arifpay.beneficiary_bank' => '',
            'arifpay.base_url' => 'https://gateway.arifpay.net', 'arifpay.test_mode' => '1',
            'bank.enabled' => '0', 'bank.bank_name' => '', 'bank.account_name' => '', 'bank.account_number' => '', 'bank.swift' => '',
            'bank.currencies' => 'ETB,USD',
            'smtp.host' => '', 'smtp.port' => '465', 'smtp.secure' => 'ssl', 'smtp.user' => '', 'smtp.pass' => '',
            'smtp.from' => 'no-reply@sham.et', 'smtp.from_name' => 'Sham',
            'licence.private_key' => '',
            'licence.public_keys' => 'E9nhkqzNzxngBfM46AWvlC6ClF8PSzcaHFrMXb+ohCo=',
        ];
    }

    public static function get(string $key, string $default = ''): string
    {
        $all = self::all();
        $v = $all[$key] ?? (self::defaults()[$key] ?? $default);
        if (in_array($key, self::SECRET, true)) {
            return Guard::decrypt($v);
        }

        return $v;
    }

    public static function bool(string $key): bool
    {
        return self::get($key) === '1';
    }

    public static function float(string $key): float
    {
        return (float) self::get($key, '0');
    }

    public static function has(string $key): bool
    {
        return self::get($key) !== '';
    }

    public static function set(string $key, string $value): void
    {
        if (in_array($key, self::SECRET, true)) {
            $value = $value === '' ? '' : Guard::encrypt($value);
        }
        Db::run('INSERT INTO settings (k, v, updated_at) VALUES (?, ?, UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE v = VALUES(v), updated_at = VALUES(updated_at)', [$key, $value]);
        self::$cache = null;
    }

    /** "••••1234" for a stored secret, or "" when none. */
    public static function hint(string $key): string
    {
        $v = self::get($key);

        return $v === '' ? '' : '•••• '.substr($v, -4);
    }

    /** @return array<string, string> */
    private static function all(): array
    {
        if (self::$cache === null) {
            self::$cache = [];
            foreach (Db::all('SELECT k, v FROM settings') as $r) {
                self::$cache[(string) $r['k']] = (string) $r['v'];
            }
        }

        return self::$cache;
    }

    public static function flush(): void
    {
        self::$cache = null;
    }
}
