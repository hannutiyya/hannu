<?php

declare(strict_types=1);

namespace Sham;

/**
 * First content: Sham MediaOS (with the editions, limits and features the platform itself knows), Taligaa, the about
 * page and the legal texts from app/content. Existing rows are never overwritten, so running it again is safe.
 */
final class Seed
{
    /** The editions of Sham MediaOS, matching apps/api/config/licensing.php. */
    public const MEDIAOS_EDITIONS = [
        'starter' => ['Starter', 'For a small news site: newsroom, website, newsletters, local payments and ads.', 490, 2,
            ['editions' => 1, 'languages' => 3, 'staff' => 5, 'studios' => 0], ['newsroom', 'website', 'newsletters', 'local_payments', 'ads'], 0],
        'professional' => ['Professional', 'Adds the paywall, branded apps, the AI desk, analytics, podcasts and elections.', 2990, 3,
            ['editions' => 3, 'languages' => 10, 'staff' => 25, 'studios' => 0],
            ['newsroom', 'website', 'newsletters', 'local_payments', 'ads', 'paywall', 'apps', 'ai', 'analytics', 'podcasts', 'elections'], 0],
        'broadcast' => ['Broadcast', 'Adds rundowns, three studios, live streaming, the interaction centre and syndication.', 9900, 5,
            ['editions' => 5, 'languages' => 15, 'staff' => 75, 'studios' => 3],
            ['newsroom', 'website', 'newsletters', 'local_payments', 'ads', 'paywall', 'apps', 'ai', 'analytics', 'podcasts', 'elections',
                'broadcast', 'live', 'interaction', 'syndication'], 0],
        'enterprise' => ['Enterprise', 'Adds single sign-on, several brands in one installation, legal holds and signed audit export.', 29000, 20,
            ['editions' => null, 'languages' => null, 'staff' => 500, 'studios' => 20],
            ['newsroom', 'website', 'newsletters', 'local_payments', 'ads', 'paywall', 'apps', 'ai', 'analytics', 'podcasts', 'elections',
                'broadcast', 'live', 'interaction', 'syndication', 'sso', 'multi_brand', 'dam_tiers', 'audit_export'], 0],
        'global' => ['Global', 'Unlimited staff and several data centres, for national and international groups. Sold on quotation.', 0, 100,
            ['editions' => null, 'languages' => null, 'staff' => null, 'studios' => null],
            ['newsroom', 'website', 'newsletters', 'local_payments', 'ads', 'paywall', 'apps', 'ai', 'analytics', 'podcasts', 'elections',
                'broadcast', 'live', 'interaction', 'syndication', 'sso', 'multi_brand', 'dam_tiers', 'audit_export', 'multi_region'], 1],
    ];

    public static function run(?string $mediaHost = null, ?string $taligaaHost = null): void
    {
        $dir = SHAM_APP.'/content';
        foreach (['mediaos' => ['mediaos', $mediaHost, 10], 'taligaa' => ['manual', $taligaaHost, 20]] as $slug => [$kind, $host, $sort]) {
            if (Db::one('SELECT id FROM products WHERE slug = ?', [$slug]) !== null) {
                continue;
            }
            [$meta, $body] = self::file($dir.'/products/'.$slug.'.md');
            Db::insert('products', ['slug' => $slug, 'name' => $meta['title'], 'host' => $host ?? $meta['host'], 'tagline' => $meta['tagline'],
                'summary' => $meta['summary'], 'body' => $body, 'accent' => $meta['accent'], 'licence_kind' => $kind,
                'trial_note' => $slug === 'mediaos' ? 'Every installation starts with a free 14-day Professional trial. No key needed.' : '',
                'status' => 'published', 'sort' => $sort, 'updated_at' => now_utc()]);
        }
        $media = (int) Db::value('SELECT id FROM products WHERE slug = ?', ['mediaos']);
        $sort = 0;
        foreach (self::MEDIAOS_EDITIONS as $key => [$label, $blurb, $usd, $domains, $limits, $features, $quote]) {
            $sort += 10;
            if (Db::one('SELECT id FROM editions WHERE product_id = ? AND ekey = ?', [$media, $key]) === null) {
                Db::insert('editions', ['product_id' => $media, 'ekey' => $key, 'label' => $label, 'blurb' => $blurb, 'price_usd_year' => $usd,
                    'perpetual_multiple' => 3, 'max_domains' => $domains, 'limits_json' => json_out($limits), 'features_json' => json_out($features),
                    'quote_only' => $quote, 'active' => 1, 'sort' => $sort]);
            }
        }
        $pages = ['about' => $dir.'/about.md'];
        foreach (glob($dir.'/legal/*.md') ?: [] as $f) {
            $pages[basename($f, '.md')] = $f;
        }
        foreach ($pages as $slug => $file) {
            if (Db::one('SELECT id FROM pages WHERE slug = ?', [$slug]) !== null) {
                continue;
            }
            [$meta, $body] = self::file($file);
            Db::insert('pages', ['slug' => $slug, 'title' => $meta['title'], 'body' => $body, 'status' => 'published', 'updated_at' => now_utc()]);
        }
    }

    /** @return array{0: array<string, string>, 1: string} */
    private static function file(string $path): array
    {
        $raw = (string) file_get_contents($path);
        [$head, $body] = array_pad(explode("\n---\n", $raw, 2), 2, '');
        $meta = ['title' => '', 'tagline' => '', 'summary' => '', 'accent' => '#C8102E', 'host' => ''];
        foreach (explode("\n", $head) as $line) {
            if (preg_match('/^([a-z]+):\s*(.*)$/', $line, $m) === 1) {
                $meta[$m[1]] = trim($m[2]);
            }
        }

        return [$meta, trim($body)."\n"];
    }
}
