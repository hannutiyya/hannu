<?php

declare(strict_types=1);

/** HTML-escape for text and attribute context. */
function e(mixed $v): string
{
    return htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
}

/** Crockford base32 ULID (26 chars, time-ordered). */
function ulid(): string
{
    $alphabet = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
    $ms = (int) floor(microtime(true) * 1000);
    $time = '';
    for ($i = 9; $i >= 0; $i--) {
        $time = $alphabet[$ms % 32].$time;
        $ms = intdiv($ms, 32);
    }
    $rand = '';
    $bytes = random_bytes(16);
    for ($i = 0; $i < 16; $i++) {
        $rand .= $alphabet[ord($bytes[$i]) % 32];
    }

    return $time.$rand;
}

/** 32 hex chars of randomness: order references and other capability tokens. */
function token(int $bytes = 16): string
{
    return bin2hex(random_bytes($bytes));
}

function now_utc(): string
{
    return gmdate('Y-m-d H:i:s');
}

function b64url(string $raw): string
{
    return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
}

function unb64url(string $s): ?string
{
    if ($s === '' || preg_match('/^[A-Za-z0-9_-]+$/', $s) !== 1) {
        return null;
    }
    $raw = base64_decode(strtr($s, '-_', '+/'), true);

    return $raw === false ? null : $raw;
}

function money(int $minor, string $currency, bool $short = false): string
{
    $major = number_format($minor / 100, $short && $minor % 100 === 0 ? 0 : 2, '.', ',');

    return match ($currency) {
        'USD' => 'US$'.$major,
        'ETB' => 'ETB '.$major,
        default => $currency.' '.$major,
    };
}

/** Amount in major units as a plain string for provider APIs ("1234.50"). */
function major(int $minor): string
{
    return number_format($minor / 100, 2, '.', '');
}

/** Minor units from a provider's major-unit value, or null. */
function minor(mixed $v): ?int
{
    if (is_int($v) || is_float($v) || (is_string($v) && is_numeric($v))) {
        return (int) round(((float) $v) * 100);
    }

    return null;
}

function json_out(mixed $v): string
{
    return (string) json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

/** @return array<mixed> */
function json_in(?string $s): array
{
    if ($s === null || $s === '') {
        return [];
    }
    $v = json_decode($s, true);

    return is_array($v) ? $v : [];
}

function str_limit(string $s, int $max): string
{
    $s = trim((string) preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $s));

    return mb_substr($s, 0, $max);
}

function date_human(?string $utc): string
{
    if ($utc === null || $utc === '') {
        return '—';
    }
    $t = strtotime($utc.' UTC');

    return $t === false ? '—' : gmdate('j M Y', $t);
}

/** A field's error message for templates, or nothing. @param array<string, string> $errors */
function field_error(array $errors, string $key): string
{
    return isset($errors[$key]) ? '<p class="field-error" id="err-'.e($key).'">'.e($errors[$key]).'</p>' : '';
}

/** aria attributes for a field that may have an error. @param array<string, string> $errors */
function aria_error(array $errors, string $key): string
{
    return isset($errors[$key]) ? ' aria-invalid="true" aria-describedby="err-'.e($key).'"' : '';
}

function csrf_field(): string
{
    return Sham\Security\Guard::csrfField();
}

/** Stylesheet for a product colour (CSP allows no inline styles). */
function accent_href(?string $hex, bool $root = true): string
{
    $h = strtolower(ltrim((string) $hex, '#'));

    return preg_match('/^[0-9a-f]{6}$/', $h) === 1 ? '/_accent/'.$h.($root ? '-root' : '').'.css' : '';
}
