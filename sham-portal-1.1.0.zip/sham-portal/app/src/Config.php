<?php

declare(strict_types=1);

namespace Sham;

/**
 * Server configuration from app/config.php (written by the installer, never web-served): database, the app secret that
 * encrypts stored secrets and signs tokens, the host names, and cookie security. Business settings (prices, payment
 * keys, mail) live in the database {@see Settings} and are edited in the admin.
 */
final class Config
{
    /** @var array<string, mixed> */
    private static array $c = [];

    private static bool $installed = false;

    private static string $path = '';

    public static function load(string $path): void
    {
        self::$path = $path;
        self::$c = self::defaults();
        if (is_file($path)) {
            $loaded = require $path;
            if (is_array($loaded)) {
                self::$c = array_replace_recursive(self::$c, $loaded);
                self::$installed = (bool) (self::$c['installed'] ?? false);
            }
        }
    }

    /** @return array<string, mixed> */
    private static function defaults(): array
    {
        return [
            'installed' => false,
            'env' => 'production',
            'app_secret' => '',
            'install_token' => '',
            'db' => ['host' => 'localhost', 'port' => 3306, 'name' => '', 'user' => '', 'pass' => '', 'socket' => ''],
            'hosts' => ['company' => 'sham.et', 'store' => 'store.sham.et', 'licensing' => 'licensing.sham.et'],
            'scheme' => 'https',
            'secure_cookies' => true,
            // Remote addresses whose X-Forwarded-For / CF-Connecting-IP is believed (Cloudflare or the host's proxy).
            'trusted_proxies' => [],
            'cloudflare' => false,
        ];
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $v = self::$c;
        foreach (explode('.', $key) as $k) {
            if (! is_array($v) || ! array_key_exists($k, $v)) {
                return $default;
            }
            $v = $v[$k];
        }

        return $v;
    }

    public static function installed(): bool
    {
        return self::$installed;
    }

    public static function path(): string
    {
        return self::$path;
    }

    public static function local(): bool
    {
        return self::get('env') === 'local';
    }

    /** Raw 32-byte application secret. */
    public static function secret(): string
    {
        $raw = base64_decode((string) self::get('app_secret'), true);
        if ($raw === false || strlen($raw) !== 32) {
            throw new \RuntimeException('The application secret is missing from config.php.');
        }

        return $raw;
    }

    /** Derived sub-key, so one secret never serves two purposes. */
    public static function key(string $purpose): string
    {
        return hash_hmac('sha256', 'sham-portal:'.$purpose, self::secret(), true);
    }

    public static function host(string $site): string
    {
        return strtolower((string) self::get('hosts.'.$site, ''));
    }

    public static function url(string $site, string $path = '/'): string
    {
        return self::get('scheme', 'https').'://'.self::host($site).$path;
    }

    /** @param array<string, mixed> $config */
    public static function write(string $path, array $config): void
    {
        $php = "<?php\n\n// Sham portal configuration. Written by the installer. Keep this file private (chmod 600).\n\nreturn ".var_export($config, true).";\n";
        $tmp = $path.'.tmp'.bin2hex(random_bytes(4));
        if (file_put_contents($tmp, $php, LOCK_EX) === false) {
            throw new \RuntimeException('Could not write '.$path);
        }
        @chmod($tmp, 0600);
        if (! rename($tmp, $path)) {
            @unlink($tmp);
            throw new \RuntimeException('Could not write '.$path);
        }
        if (function_exists('opcache_invalidate')) {
            @opcache_invalidate($path, true);
        }
    }

    /** @param array<string, mixed> $override for tests */
    public static function set(array $override): void
    {
        self::$c = array_replace_recursive(self::$c, $override);
        self::$installed = (bool) (self::$c['installed'] ?? false);
    }
}
