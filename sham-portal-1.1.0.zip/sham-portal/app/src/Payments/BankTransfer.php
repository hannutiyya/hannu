<?php

declare(strict_types=1);

namespace Sham\Payments;

use Sham\Settings;

/** Bank transfer: the buyer gets the account details and the order reference; staff confirm the credit in the admin. */
final class BankTransfer implements Gateway
{
    public function key(): string
    {
        return 'bank';
    }

    public function label(): string
    {
        return 'Bank transfer';
    }

    public function configured(): bool
    {
        return Settings::bool('bank.enabled') && Settings::has('bank.account_number');
    }

    public function currencies(): array
    {
        return array_values(array_intersect(['USD', 'ETB'], array_map('trim', explode(',', strtoupper(Settings::get('bank.currencies'))))));
    }

    public function testMode(): bool
    {
        return false;
    }

    public function start(array $order, array $ctx): array
    {
        return ['url' => null, 'session' => null, 'instructions' => self::instructions($order)];
    }

    /** @return array<string, string> */
    public static function instructions(array $order): array
    {
        return array_filter([
            'Bank' => Settings::get('bank.bank_name'), 'Account name' => Settings::get('bank.account_name'),
            'Account number' => Settings::get('bank.account_number'), 'SWIFT' => Settings::get('bank.swift'),
            'Amount' => money((int) $order['total_minor'], (string) $order['currency']),
            'Payment reference' => strtoupper(substr((string) $order['ref'], 0, 12)),
        ], fn ($v) => $v !== '');
    }

    public function verifyWebhook(string $raw, array $headers, array $query): ?array
    {
        return null;
    }

    public function fetch(array $order): ?array
    {
        return null;
    }
}
