<?php

declare(strict_types=1);

namespace Sham\Payments;

use Sham\Settings;

/**
 * Stripe Checkout (cards, Apple Pay, Google Pay) in USD. Webhook: Stripe-Signature t=…,v1=HMAC-SHA256(secret, "t.body")
 * with a 5-minute tolerance; the session is then re-read from Stripe's API before anything is credited.
 */
final class Stripe implements Gateway
{
    public function key(): string
    {
        return 'stripe';
    }

    public function label(): string
    {
        return 'Card (Visa, Mastercard) via Stripe';
    }

    public function configured(): bool
    {
        return Settings::bool('stripe.enabled') && Settings::has('stripe.secret') && Settings::has('stripe.webhook_secret');
    }

    public function currencies(): array
    {
        return ['USD'];
    }

    public function testMode(): bool
    {
        return str_starts_with(Settings::get('stripe.secret'), 'sk_test_') || str_starts_with(Settings::get('stripe.secret'), 'rk_test_');
    }

    public function start(array $order, array $ctx): array
    {
        $res = HttpClient::postForm($this->base().'/checkout/sessions', [
            'mode' => 'payment',
            'client_reference_id' => $order['ref'],
            'success_url' => $ctx['return_url'],
            'cancel_url' => $ctx['cancel_url'],
            'customer_email' => $order['customer_email'],
            'line_items' => [['quantity' => 1, 'price_data' => [
                'currency' => strtolower((string) $order['currency']), 'unit_amount' => (int) $order['total_minor'],
                'product_data' => ['name' => mb_substr($ctx['title'], 0, 120)],
            ]]],
            'metadata' => ['ref' => $order['ref'], 'order_id' => $order['id']],
            'payment_intent_data' => ['metadata' => ['ref' => $order['ref']], 'description' => mb_substr($ctx['title'], 0, 300)],
            'billing_address_collection' => 'auto',
        ], $this->auth() + ['Idempotency-Key' => 'checkout-'.$order['ref']]);
        $url = (string) ($res['json']['url'] ?? '');
        if ($res['status'] < 200 || $res['status'] >= 300 || ! str_starts_with($url, 'https://')) {
            throw new PaymentUnavailable('stripe checkout HTTP '.$res['status']);
        }

        return ['url' => $url, 'session' => (string) ($res['json']['id'] ?? ''), 'instructions' => null];
    }

    public function verifyWebhook(string $raw, array $headers, array $query): ?array
    {
        $secret = Settings::get('stripe.webhook_secret');
        $header = $headers['stripe-signature'] ?? '';
        if ($secret === '' || $header === '') {
            return null;
        }
        $ts = null;
        $sigs = [];
        foreach (explode(',', $header) as $part) {
            [$k, $v] = array_pad(explode('=', trim($part), 2), 2, '');
            if ($k === 't' && ctype_digit($v)) {
                $ts = (int) $v;
            } elseif ($k === 'v1') {
                $sigs[] = strtolower($v);
            }
        }
        if ($ts === null || $sigs === [] || abs(time() - $ts) > 300) {
            return null;
        }
        $expected = hash_hmac('sha256', $ts.'.'.$raw, $secret);
        $ok = false;
        foreach ($sigs as $s) {
            $ok = $ok || hash_equals($expected, $s);
        }
        $d = json_in($raw);
        if (! $ok || ! is_string($d['id'] ?? null) || ! str_starts_with($d['id'], 'evt_')) {
            return null;
        }
        $obj = (array) HttpClient::dig($d, 'data.object', []);
        $type = mb_substr((string) ($d['type'] ?? 'unknown'), 0, 80);
        $out = ['key' => mb_substr($d['id'], 0, 190), 'type' => $type];
        if (str_starts_with($type, 'checkout.session.')) {
            $ref = (string) ($obj['client_reference_id'] ?? HttpClient::dig($obj, 'metadata.ref', ''));
            if ($ref !== '') {
                $out['ref'] = $ref;
            } elseif (is_string($obj['id'] ?? null)) {
                $out['session'] = $obj['id'];
            }
        }

        return $out;
    }

    public function fetch(array $order): ?array
    {
        $sid = (string) ($order['provider_session'] ?? '');
        if ($sid === '') {
            return null;
        }
        $res = HttpClient::get($this->base().'/checkout/sessions/'.rawurlencode($sid), $this->auth());
        if ($res['status'] === 404) {
            return null;
        }
        if ($res['status'] !== 200) {
            throw new PaymentUnavailable('stripe session HTTP '.$res['status']);
        }
        $s = $res['json'];
        if ((string) ($s['client_reference_id'] ?? '') !== (string) $order['ref']) {
            return null;
        }
        $paid = in_array($s['payment_status'] ?? '', ['paid', 'no_payment_required'], true) && ($s['status'] ?? '') === 'complete';

        return [
            'status' => $paid ? 'succeeded' : (($s['status'] ?? '') === 'expired' ? 'cancelled' : 'pending'),
            'amount_minor' => (int) ($s['amount_total'] ?? 0), 'currency' => strtoupper((string) ($s['currency'] ?? '')),
            'reference' => is_string($s['payment_intent'] ?? null) ? $s['payment_intent'] : null,
        ];
    }

    private function base(): string
    {
        return rtrim(Settings::get('stripe.base_url', 'https://api.stripe.com/v1'), '/');
    }

    /** @return array<string, string> */
    private function auth(): array
    {
        return ['Authorization' => 'Bearer '.Settings::get('stripe.secret')];
    }
}
