<?php

declare(strict_types=1);

namespace Sham\Payments;

use Sham\Db;
use Sham\Security\Guard;
use Sham\Settings;

/**
 * PayPal Orders v2 in USD. The buyer approves on PayPal; the order is captured once (PayPal-Request-Id
 * capture-{ref}) when we read it back. Webhooks are verified by PayPal itself (verify-webhook-signature).
 */
final class Paypal implements Gateway
{
    public function key(): string
    {
        return 'paypal';
    }

    public function label(): string
    {
        return 'PayPal';
    }

    public function configured(): bool
    {
        return Settings::bool('paypal.enabled') && Settings::has('paypal.client_id') && Settings::has('paypal.client_secret') && Settings::has('paypal.webhook_id');
    }

    public function currencies(): array
    {
        return ['USD'];
    }

    public function testMode(): bool
    {
        return Settings::get('paypal.mode') !== 'live';
    }

    public function start(array $order, array $ctx): array
    {
        $res = HttpClient::postJson($this->base().'/v2/checkout/orders', [
            'intent' => 'CAPTURE',
            'purchase_units' => [[
                'reference_id' => $order['ref'], 'custom_id' => $order['ref'], 'description' => mb_substr($ctx['title'], 0, 127),
                'amount' => ['currency_code' => $order['currency'], 'value' => major((int) $order['total_minor'])],
            ]],
            'payment_source' => ['paypal' => ['experience_context' => [
                'brand_name' => mb_substr(Settings::get('company.short'), 0, 127), 'shipping_preference' => 'NO_SHIPPING', 'user_action' => 'PAY_NOW',
                'return_url' => $ctx['return_url'], 'cancel_url' => $ctx['cancel_url'],
            ]]],
        ], $this->auth() + ['PayPal-Request-Id' => 'checkout-'.$order['ref']]);
        $url = null;
        foreach ((array) ($res['json']['links'] ?? []) as $l) {
            if (is_array($l) && ($l['rel'] ?? '') === 'payer-action') {
                $url = (string) ($l['href'] ?? '');
            }
        }
        if ($res['status'] < 200 || $res['status'] >= 300 || ! is_string($url) || ! str_starts_with($url, 'https://')) {
            throw new PaymentUnavailable('paypal order HTTP '.$res['status']);
        }

        return ['url' => $url, 'session' => (string) ($res['json']['id'] ?? ''), 'instructions' => null];
    }

    public function verifyWebhook(string $raw, array $headers, array $query): ?array
    {
        $event = json_in($raw);
        $need = ['paypal-auth-algo', 'paypal-cert-url', 'paypal-transmission-id', 'paypal-transmission-sig', 'paypal-transmission-time'];
        foreach ($need as $h) {
            if (($headers[$h] ?? '') === '') {
                return null;
            }
        }
        if (! is_string($event['id'] ?? null)) {
            return null;
        }
        $cert = parse_url((string) $headers['paypal-cert-url']);
        $sent = strtotime((string) $headers['paypal-transmission-time']);
        if (($cert['scheme'] ?? '') !== 'https' || ! in_array($cert['host'] ?? '', ['api.paypal.com', 'api-m.paypal.com', 'api.sandbox.paypal.com', 'api-m.sandbox.paypal.com'], true)
            || $sent === false || abs(time() - $sent) > 600) {
            return null;
        }
        // The event goes back to PayPal exactly as received.
        $envelope = json_out([
            'auth_algo' => $headers['paypal-auth-algo'], 'cert_url' => $headers['paypal-cert-url'], 'transmission_id' => $headers['paypal-transmission-id'],
            'transmission_sig' => $headers['paypal-transmission-sig'], 'transmission_time' => $headers['paypal-transmission-time'],
            'webhook_id' => Settings::get('paypal.webhook_id'), 'webhook_event' => '__EVENT__',
        ]);
        try {
            $res = HttpClient::send('POST', $this->base().'/v1/notifications/verify-webhook-signature',
                ['Content-Type' => 'application/json', 'Accept' => 'application/json'] + $this->auth(), str_replace('"__EVENT__"', trim($raw), $envelope));
        } catch (\Throwable) {
            return null;
        }
        if (($res['json']['verification_status'] ?? '') !== 'SUCCESS') {
            return null;
        }
        $type = mb_substr((string) ($event['event_type'] ?? 'unknown'), 0, 60);
        $resource = (array) ($event['resource'] ?? []);
        $out = ['key' => mb_substr($event['id'], 0, 190), 'type' => $type];
        if ($type === 'CHECKOUT.ORDER.APPROVED' && is_string($resource['id'] ?? null)) {
            $out['session'] = $resource['id'];
        } elseif (is_string($resource['custom_id'] ?? null)) {
            $out['ref'] = $resource['custom_id'];
        }

        return $out;
    }

    public function fetch(array $order): ?array
    {
        $id = (string) ($order['provider_session'] ?? '');
        if ($id === '') {
            return null;
        }
        $res = HttpClient::get($this->base().'/v2/checkout/orders/'.rawurlencode($id), $this->auth());
        if ($res['status'] === 404) {
            return null;
        }
        if ($res['status'] !== 200) {
            throw new PaymentUnavailable('paypal order read HTTP '.$res['status']);
        }
        $o = $res['json'];
        if (($o['status'] ?? '') === 'APPROVED') {
            $res = HttpClient::send('POST', $this->base().'/v2/checkout/orders/'.rawurlencode($id).'/capture',
                ['Content-Type' => 'application/json', 'Accept' => 'application/json', 'PayPal-Request-Id' => 'capture-'.$order['ref']] + $this->auth(), '{}');
            if ($res['status'] < 200 || $res['status'] >= 300) {
                throw new PaymentUnavailable('paypal capture HTTP '.$res['status']);
            }
            $o = $res['json'];
        }
        $unit = (array) ($o['purchase_units'][0] ?? []);
        if ((string) ($unit['custom_id'] ?? ($unit['reference_id'] ?? '')) !== (string) $order['ref']) {
            return null;
        }
        $cap = (array) ($unit['payments']['captures'][0] ?? []);
        if ($cap === []) {
            return ['status' => ($o['status'] ?? '') === 'VOIDED' ? 'cancelled' : 'pending', 'amount_minor' => minor($unit['amount']['value'] ?? null) ?? 0,
                'currency' => strtoupper((string) ($unit['amount']['currency_code'] ?? '')), 'reference' => null];
        }

        return [
            'status' => match ((string) ($cap['status'] ?? '')) {
                'COMPLETED', 'PARTIALLY_REFUNDED' => 'succeeded', 'DECLINED', 'FAILED' => 'failed', 'REFUNDED' => 'refunded', default => 'pending',
            },
            'amount_minor' => minor($cap['amount']['value'] ?? null) ?? 0, 'currency' => strtoupper((string) ($cap['amount']['currency_code'] ?? '')),
            'reference' => isset($cap['id']) ? mb_substr((string) $cap['id'], 0, 190) : null,
        ];
    }

    private function base(): string
    {
        $override = Settings::get('paypal.base_url');
        if ($override !== '') {
            return rtrim($override, '/');
        }

        return $this->testMode() ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';
    }

    /** OAuth client-credentials token, cached in settings until shortly before it expires. @return array<string, string> */
    private function auth(): array
    {
        $cacheKey = 'paypal.token_cache';
        $cached = json_in(Guard::decrypt(Settings::get($cacheKey)));
        if (is_string($cached['t'] ?? null) && (int) ($cached['exp'] ?? 0) > time() + 60 && ($cached['base'] ?? '') === $this->base()) {
            return ['Authorization' => 'Bearer '.$cached['t']];
        }
        $res = HttpClient::send('POST', $this->base().'/v1/oauth2/token', [
            'Content-Type' => 'application/x-www-form-urlencoded', 'Accept' => 'application/json',
            'Authorization' => 'Basic '.base64_encode(Settings::get('paypal.client_id').':'.Settings::get('paypal.client_secret')),
        ], 'grant_type=client_credentials');
        $token = (string) ($res['json']['access_token'] ?? '');
        if ($res['status'] !== 200 || $token === '') {
            throw new PaymentUnavailable('paypal token HTTP '.$res['status']);
        }
        Db::run('INSERT INTO settings (k, v, updated_at) VALUES (?, ?, UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE v = VALUES(v), updated_at = VALUES(updated_at)',
            [$cacheKey, Guard::encrypt(json_out(['t' => $token, 'exp' => time() + max(60, (int) ($res['json']['expires_in'] ?? 3600) - 300), 'base' => $this->base()]))]);
        Settings::flush();

        return ['Authorization' => 'Bearer '.$token];
    }
}
