<?php

declare(strict_types=1);

namespace Sham\Payments;

final class Registry
{
    /** @return array<string, Gateway> */
    public static function all(): array
    {
        $g = [new Stripe(), new Paypal(), new Chapa(), new Telebirr(), new ArifPay(), new BankTransfer()];
        $out = [];
        foreach ($g as $x) {
            $out[$x->key()] = $x;
        }

        return $out;
    }

    public static function get(string $key): ?Gateway
    {
        return self::all()[$key] ?? null;
    }

    /** @return list<Gateway> configured rails for a currency */
    public static function forCurrency(string $currency): array
    {
        return array_values(array_filter(self::all(), fn (Gateway $g) => $g->configured() && in_array($currency, $g->currencies(), true)));
    }

    /** @return list<string> currencies that at least one configured rail collects */
    public static function currencies(): array
    {
        $c = [];
        foreach (self::all() as $g) {
            if ($g->configured()) {
                $c = [...$c, ...$g->currencies()];
            }
        }

        return array_values(array_intersect(['USD', 'ETB'], array_unique($c)));
    }
}
