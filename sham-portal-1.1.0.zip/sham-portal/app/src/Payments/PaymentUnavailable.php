<?php

declare(strict_types=1);

namespace Sham\Payments;

/** The provider refused or could not be reached. The message is for the log only; buyers see a generic sentence. */
final class PaymentUnavailable extends \RuntimeException {}
