<?php

declare(strict_types=1);

namespace Sham\Payments;

use Sham\Db;
use Sham\Security\Guard;
use Sham\Settings;

/**
 * telebirr H5 web checkout (C2B) with Ethio Telecom, ETB. Requests are signed RSA-PSS SHA-256 with the merchant key;
 * notifications are signed by telebirr and verified with its public key; the order is then re-read with queryOrder.
 * merch_order_id is the order ref (letters and digits only).
 */
final class Telebirr implements Gateway
{
    private const UNSIGNED = ['sign', 'sign_type', 'header', 'refund_info', 'openType', 'raw_request', 'biz_content', 'wallet_reference_data'];

    public function key(): string
    {
        return 'telebirr';
    }

    public function label(): string
    {
        return 'telebirr';
    }

    public function configured(): bool
    {
        foreach (['fabric_app_id', 'app_secret', 'merchant_app_id', 'merchant_code', 'private_key', 'public_key'] as $k) {
            if (trim(Settings::get('telebirr.'.$k)) === '') {
                return false;
            }
        }

        return Settings::bool('telebirr.enabled');
    }

    public function currencies(): array
    {
        return ['ETB'];
    }

    public function testMode(): bool
    {
        return Settings::bool('telebirr.test_mode');
    }

    public function start(array $order, array $ctx): array
    {
        $res = $this->request('/payment/v1/merchant/preOrder', 'payment.preorder', [
            'notify_url' => $ctx['notify_url'], 'appid' => $this->cfg('merchant_app_id'), 'merch_code' => $this->cfg('merchant_code'),
            'merch_order_id' => (string) $order['ref'], 'trade_type' => 'Checkout',
            'title' => mb_substr(trim((string) preg_replace('/[^\pL\pN \-_.]/u', '', $ctx['title'])), 0, 60),
            'total_amount' => major((int) $order['total_minor']), 'trans_currency' => 'ETB', 'timeout_express' => '120m',
            'business_type' => 'BuyGoods', 'payee_identifier' => $this->cfg('merchant_code'), 'payee_identifier_type' => '04', 'payee_type' => '5000',
            'redirect_url' => $ctx['return_url'], 'callback_info' => (string) $order['ref'],
        ]);
        $prepay = trim((string) HttpClient::dig($res, 'biz_content.prepay_id', ''));
        if ($prepay === '') {
            throw new PaymentUnavailable('telebirr: no prepay id');
        }
        $raw = ['appid' => $this->cfg('merchant_app_id'), 'merch_code' => $this->cfg('merchant_code'), 'nonce_str' => token(16),
            'prepay_id' => $prepay, 'timestamp' => (string) time()];
        $query = implode('&', array_map(fn ($k, $v) => $k.'='.$v, array_keys($raw), $raw)).'&sign='.rawurlencode(RsaPss::sign(self::signString($raw), $this->cfg('private_key')))
            .'&sign_type=SHA256WithRSA';
        $base = $this->cfg('web_base_url');

        return ['url' => $base.(str_contains($base, '?') ? '' : '?').$query.'&version=1.0&trade_type=Checkout', 'session' => (string) $order['ref'], 'instructions' => null];
    }

    public function verifyWebhook(string $raw, array $headers, array $query): ?array
    {
        $b = json_in($raw);
        if (! is_string($b['sign'] ?? null) || ! RsaPss::verify(self::signString($b), $b['sign'], $this->cfg('public_key'))) {
            return null;
        }
        if ((string) ($b['merch_code'] ?? '') !== $this->cfg('merchant_code') || (string) ($b['appid'] ?? '') !== $this->cfg('merchant_app_id')) {
            return null;
        }
        $order = (string) ($b['merch_order_id'] ?? '');
        $status = strtolower((string) ($b['trade_status'] ?? ''));
        $trans = (string) ($b['trans_id'] ?? ($b['payment_order_id'] ?? ''));

        return ['key' => mb_substr('notify:'.($trans !== '' ? $trans : $order).':'.$status, 0, 190), 'type' => 'trade.'.($status !== '' ? $status : 'unknown'), 'ref' => $order];
    }

    public function fetch(array $order): ?array
    {
        $res = $this->request('/payment/v1/merchant/queryOrder', 'payment.queryorder', [
            'appid' => $this->cfg('merchant_app_id'), 'merch_code' => $this->cfg('merchant_code'), 'merch_order_id' => (string) $order['ref'],
        ]);
        $biz = (array) ($res['biz_content'] ?? []);
        if ((string) ($biz['merch_order_id'] ?? $order['ref']) !== (string) $order['ref']) {
            return null;
        }
        $trans = (string) ($biz['trans_id'] ?? ($biz['payment_order_id'] ?? ''));

        return [
            'status' => match (strtoupper((string) ($biz['order_status'] ?? ''))) {
                'PAY_SUCCESS', 'COMPLETED', 'SUCCESS' => 'succeeded', 'PAY_FAILED', 'FAILURE', 'FAILED' => 'failed',
                'ORDER_CLOSED', 'EXPIRED', 'CANCELLED' => 'cancelled', 'REFUNDED', 'REFUND_SUCCESS' => 'refunded', default => 'pending',
            },
            'amount_minor' => minor($biz['total_amount'] ?? null) ?? 0, 'currency' => strtoupper((string) ($biz['trans_currency'] ?? 'ETB')),
            'reference' => $trans !== '' ? mb_substr($trans, 0, 190) : null,
        ];
    }

    /** @param array<string, mixed> $fields */
    public static function signString(array $fields): string
    {
        $flat = $fields;
        if (is_array($fields['biz_content'] ?? null)) {
            $flat = array_merge($flat, $fields['biz_content']);
        }
        $flat = array_filter($flat, fn ($v, $k): bool => ! in_array((string) $k, self::UNSIGNED, true) && is_scalar($v) && (string) $v !== '', ARRAY_FILTER_USE_BOTH);
        ksort($flat, SORT_STRING);

        return implode('&', array_map(fn ($k, $v): string => $k.'='.(is_bool($v) ? ($v ? 'true' : 'false') : (string) $v), array_keys($flat), $flat));
    }

    /**
     * @param  array<string, mixed>  $biz
     * @return array<string, mixed>
     */
    private function request(string $path, string $method, array $biz): array
    {
        $body = ['timestamp' => (string) time(), 'nonce_str' => token(16), 'method' => $method, 'version' => '1.0', 'biz_content' => $biz];
        $body['sign'] = RsaPss::sign(self::signString($body), $this->cfg('private_key'));
        $body['sign_type'] = 'SHA256WithRSA';
        $res = HttpClient::postJson(rtrim($this->cfg('base_url'), '/').$path, $body, ['X-APP-Key' => $this->cfg('fabric_app_id'), 'Authorization' => $this->fabricToken()]);
        if ($res['status'] !== 200 || strtoupper((string) ($res['json']['result'] ?? '')) !== 'SUCCESS') {
            throw new PaymentUnavailable('telebirr '.$method.' HTTP '.$res['status']);
        }

        return $res['json'];
    }

    private function fabricToken(): string
    {
        $c = json_in(Guard::decrypt(Settings::get('telebirr.token_cache')));
        if (is_string($c['t'] ?? null) && (int) ($c['exp'] ?? 0) > time()) {
            return $c['t'];
        }
        $res = HttpClient::postJson(rtrim($this->cfg('base_url'), '/').'/payment/v1/token', ['appSecret' => $this->cfg('app_secret')], ['X-APP-Key' => $this->cfg('fabric_app_id')]);
        $t = trim((string) ($res['json']['token'] ?? ''));
        if ($res['status'] !== 200 || $t === '') {
            throw new PaymentUnavailable('telebirr token HTTP '.$res['status']);
        }
        Db::run('INSERT INTO settings (k, v, updated_at) VALUES (?, ?, UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE v = VALUES(v), updated_at = VALUES(updated_at)',
            ['telebirr.token_cache', Guard::encrypt(json_out(['t' => $t, 'exp' => time() + 3000]))]);
        Settings::flush();

        return $t;
    }

    private function cfg(string $k): string
    {
        return trim(Settings::get('telebirr.'.$k));
    }
}
