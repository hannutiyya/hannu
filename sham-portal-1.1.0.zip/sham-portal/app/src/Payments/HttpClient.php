<?php

declare(strict_types=1);

namespace Sham\Payments;

/** Small cURL client for the payment APIs: TLS verified, no redirects followed, short timeouts. */
final class HttpClient
{
    /** @var (callable(string, string, array<string, string>, string): array{status: int, body: string})|null test double */
    public static $fake = null;

    /**
     * @param  array<string, string>  $headers
     * @return array{status: int, body: string, json: array<mixed>}
     */
    public static function send(string $method, string $url, array $headers = [], string $body = '', int $timeout = 20): array
    {
        if (self::$fake !== null) {
            $r = (self::$fake)($method, $url, $headers, $body);

            return ['status' => $r['status'], 'body' => $r['body'], 'json' => json_in($r['body'])];
        }
        if (! str_starts_with($url, 'https://') && ! \Sham\Config::local()) {
            throw new PaymentUnavailable('refusing a non-HTTPS payment API address');
        }
        $ch = curl_init($url);
        $h = [];
        foreach ($headers as $k => $v) {
            $h[] = $k.': '.str_replace(["\r", "\n"], '', $v);
        }
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $h,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS | CURLPROTO_HTTP,
            CURLOPT_USERAGENT => 'ShamPortal/'.(defined('SHAM_VERSION') ? SHAM_VERSION : '1'),
        ]);
        if ($method !== 'GET' && $body !== '') {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $res = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if (! is_string($res)) {
            return ['status' => 0, 'body' => '', 'json' => []];
        }

        return ['status' => $status, 'body' => $res, 'json' => json_in($res)];
    }

    /**
     * @param  array<string, mixed>  $data
     * @param  array<string, string>  $headers
     * @return array{status: int, body: string, json: array<mixed>}
     */
    public static function postJson(string $url, array $data, array $headers = []): array
    {
        return self::send('POST', $url, ['Content-Type' => 'application/json', 'Accept' => 'application/json'] + $headers, json_out($data));
    }

    /**
     * @param  array<string, mixed>  $data
     * @param  array<string, string>  $headers
     * @return array{status: int, body: string, json: array<mixed>}
     */
    public static function postForm(string $url, array $data, array $headers = []): array
    {
        return self::send('POST', $url, ['Content-Type' => 'application/x-www-form-urlencoded', 'Accept' => 'application/json'] + $headers, http_build_query($data));
    }

    /**
     * @param  array<string, string>  $headers
     * @return array{status: int, body: string, json: array<mixed>}
     */
    public static function get(string $url, array $headers = []): array
    {
        return self::send('GET', $url, ['Accept' => 'application/json'] + $headers);
    }

    /** Dot path into decoded JSON. */
    public static function dig(array $a, string $path, mixed $default = null): mixed
    {
        foreach (explode('.', $path) as $k) {
            if (! is_array($a) || ! array_key_exists($k, $a)) {
                return $default;
            }
            $a = $a[$k];
        }

        return $a;
    }
}
