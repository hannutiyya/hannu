<?php

declare(strict_types=1);

namespace Sham\Payments;

/**
 * One payment rail. Card data never touches this server: gateways open the provider's hosted checkout, check webhook
 * signatures, and re-read the provider's API before anything is credited ({@see Ledger}).
 */
interface Gateway
{
    public function key(): string;

    public function label(): string;

    public function configured(): bool;

    /** @return list<string> */
    public function currencies(): array;

    public function testMode(): bool;

    /**
     * @param  array<string, mixed>  $order
     * @param  array{return_url: string, cancel_url: string, notify_url: string, title: string, phone?: string|null}  $ctx
     * @return array{url: string|null, session: string|null, instructions: array<string, string>|null}
     */
    public function start(array $order, array $ctx): array;

    /**
     * Signature / token check of a webhook. Returns the idempotency key, event type and the order lookup
     * (['ref' => tx ref] or ['session' => provider session id]), or null when not authentic.
     *
     * @param  array<string, string>  $headers  lower-cased
     * @param  array<string, mixed>  $query
     * @return array{key: string, type: string, ref?: string, session?: string}|null
     */
    public function verifyWebhook(string $raw, array $headers, array $query): ?array;

    /**
     * The charge as the provider's API reports it, or null when the provider does not know it.
     * status: succeeded | failed | cancelled | pending | refunded.
     *
     * @param  array<string, mixed>  $order
     * @return array{status: string, amount_minor: int, currency: string, reference: string|null}|null
     */
    public function fetch(array $order): ?array;
}
