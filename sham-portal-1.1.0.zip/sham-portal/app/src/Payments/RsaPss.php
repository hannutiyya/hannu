<?php

declare(strict_types=1);

namespace Sham\Payments;

/**
 * RSASSA-PSS with SHA-256, MGF1-SHA-256 and a 32-byte salt (RFC 8017 §8.1, §9.1), which is what Telebirr calls
 * "SHA256WithRSA". openssl_sign() only does PKCS#1 v1.5, so the PSS encoding is done here and the raw RSA operation with
 * OPENSSL_NO_PADDING. Keys: a PEM string (a literal "\n" is accepted) or bare base64.
 */
final class RsaPss
{
    private const HASH_LEN = 32;

    private const SALT_LEN = 32;

    public static function sign(string $message, string $privateKey): string
    {
        $key = openssl_pkey_get_private(self::pem($privateKey, 'PRIVATE KEY'));
        if ($key === false) {
            throw new \InvalidArgumentException('The RSA private key could not be read.');
        }
        $bits = (int) (openssl_pkey_get_details($key)['bits'] ?? 0);
        $k = intdiv($bits + 7, 8);
        $em = str_pad(self::encode($message, $bits - 1), $k, "\0", STR_PAD_LEFT);
        if (! openssl_private_encrypt($em, $signature, $key, OPENSSL_NO_PADDING)) {
            throw new \RuntimeException('RSA signing failed.');
        }

        return base64_encode((string) $signature);
    }

    public static function verify(string $message, string $signatureBase64, string $publicKey): bool
    {
        $key = openssl_pkey_get_public(self::pem($publicKey, 'PUBLIC KEY'));
        $signature = base64_decode($signatureBase64, true);
        if ($key === false || $signature === false) {
            return false;
        }
        $bits = (int) (openssl_pkey_get_details($key)['bits'] ?? 0);
        $k = intdiv($bits + 7, 8);
        if (strlen($signature) !== $k || ! openssl_public_decrypt($signature, $em, $key, OPENSSL_NO_PADDING)) {
            return false;
        }
        $emBits = $bits - 1;
        $emLen = intdiv($emBits + 7, 8);
        $em = str_pad((string) $em, $k, "\0", STR_PAD_LEFT);
        if ($k > $emLen && trim(substr($em, 0, $k - $emLen), "\0") !== '') {
            return false;
        }

        return self::check($message, substr($em, $k - $emLen), $emBits);
    }

    private static function encode(string $message, int $emBits): string
    {
        $emLen = intdiv($emBits + 7, 8);
        $salt = random_bytes(self::SALT_LEN);
        $h = hash('sha256', str_repeat("\0", 8).hash('sha256', $message, true).$salt, true);
        $db = str_repeat("\0", $emLen - self::SALT_LEN - self::HASH_LEN - 2)."\x01".$salt;
        $maskedDb = $db ^ self::mgf1($h, $emLen - self::HASH_LEN - 1);
        $maskedDb[0] = chr(ord($maskedDb[0]) & (0xFF >> (8 * $emLen - $emBits)));

        return $maskedDb.$h."\xbc";
    }

    private static function check(string $message, string $em, int $emBits): bool
    {
        $emLen = strlen($em);
        if ($emLen < self::HASH_LEN + self::SALT_LEN + 2 || $em[$emLen - 1] !== "\xbc") {
            return false;
        }
        $maskedDb = substr($em, 0, $emLen - self::HASH_LEN - 1);
        $h = substr($em, $emLen - self::HASH_LEN - 1, self::HASH_LEN);
        $topMask = 0xFF >> (8 * $emLen - $emBits);
        if ((ord($maskedDb[0]) & ~$topMask & 0xFF) !== 0) {
            return false;
        }
        $db = $maskedDb ^ self::mgf1($h, strlen($maskedDb));
        $db[0] = chr(ord($db[0]) & $topMask);
        $psLen = $emLen - self::HASH_LEN - self::SALT_LEN - 2;
        if (trim(substr($db, 0, $psLen), "\0") !== '' || $db[$psLen] !== "\x01") {
            return false;
        }
        $salt = substr($db, $psLen + 1);

        return hash_equals($h, hash('sha256', str_repeat("\0", 8).hash('sha256', $message, true).$salt, true));
    }

    private static function mgf1(string $seed, int $length): string
    {
        $out = '';
        for ($counter = 0; strlen($out) < $length; $counter++) {
            $out .= hash('sha256', $seed.pack('N', $counter), true);
        }

        return substr($out, 0, $length);
    }

    private static function pem(string $value, string $type): string
    {
        $value = trim(str_replace('\n', "\n", $value));
        if ($value === '' || str_contains($value, '-----BEGIN')) {
            return $value;
        }

        return "-----BEGIN {$type}-----\n".chunk_split((string) preg_replace('/\s+/', '', $value), 64, "\n")."-----END {$type}-----\n";
    }
}
