<?php

declare(strict_types=1);

namespace Sham\Payments;

use Sham\Config;
use Sham\Settings;

/**
 * ArifPay hosted checkout in ETB (telebirr, CBE, Awash, Amole, BOA, Kacha, HelloCash, M-Pesa). ArifPay does not sign
 * its notifications, so the notify URL carries a per-order HMAC token; a notice with the right token only triggers a
 * read of the session from ArifPay's API.
 */
final class ArifPay implements Gateway
{
    public const METHODS = ['TELEBIRR', 'CBE', 'AWASH', 'AMOLE', 'BOA', 'KACHA', 'HELLOCASH', 'MPESA'];

    public function key(): string
    {
        return 'arifpay';
    }

    public function label(): string
    {
        return 'ArifPay (telebirr, CBE, Awash, M-Pesa and more)';
    }

    public function configured(): bool
    {
        return Settings::bool('arifpay.enabled') && Settings::has('arifpay.api_key') && Settings::has('arifpay.beneficiary_account') && Settings::has('arifpay.beneficiary_bank');
    }

    public function currencies(): array
    {
        return ['ETB'];
    }

    public function testMode(): bool
    {
        return Settings::bool('arifpay.test_mode');
    }

    public static function notifyToken(string $ref): string
    {
        return substr(hash_hmac('sha256', 'arifpay|'.$ref, Config::key('notify')), 0, 40);
    }

    public static function phone(mixed $v): ?string
    {
        $d = (string) preg_replace('/\D+/', '', (string) $v);

        return preg_match('/^(?:251|0)?([79]\d{8})$/', $d, $m) === 1 ? '251'.$m[1] : null;
    }

    public function start(array $order, array $ctx): array
    {
        $phone = self::phone($ctx['phone'] ?? null);
        if ($phone === null) {
            throw new \InvalidArgumentException('Enter the mobile number you pay with (for example 0911 234 567).');
        }
        $amount = (float) major((int) $order['total_minor']);
        $name = mb_substr(trim((string) preg_replace('/[^\pL\pN \-_.]/u', '', $ctx['title'])), 0, 60);
        $res = HttpClient::postJson($this->base().'/api/checkout/session', [
            'cancelUrl' => $ctx['cancel_url'], 'errorUrl' => $ctx['cancel_url'], 'successUrl' => $ctx['return_url'],
            'notifyUrl' => $ctx['notify_url'].(str_contains($ctx['notify_url'], '?') ? '&' : '?').'token='.self::notifyToken((string) $order['ref']),
            'phone' => $phone, 'email' => $order['customer_email'], 'nonce' => $order['ref'], 'paymentMethods' => self::METHODS,
            'expireDate' => gmdate('Y-m-d\TH:i:s', time() + 7200),
            'items' => [['name' => $name, 'quantity' => 1, 'price' => $amount, 'description' => $name]],
            'beneficiaries' => [['accountNumber' => Settings::get('arifpay.beneficiary_account'), 'bank' => Settings::get('arifpay.beneficiary_bank'), 'amount' => $amount]],
            'lang' => 'EN',
        ], ['x-arifpay-key' => Settings::get('arifpay.api_key')]);
        $url = (string) HttpClient::dig($res['json'], 'data.paymentUrl', '');
        $session = (string) HttpClient::dig($res['json'], 'data.sessionId', '');
        if ($res['status'] !== 200 || ($res['json']['error'] ?? false) === true || $session === '' || ! str_starts_with($url, 'https://')) {
            throw new PaymentUnavailable('arifpay checkout HTTP '.$res['status']);
        }

        return ['url' => $url, 'session' => mb_substr($session, 0, 190), 'instructions' => null];
    }

    public function verifyWebhook(string $raw, array $headers, array $query): ?array
    {
        $b = json_in($raw);
        $ref = (string) ($b['nonce'] ?? '');
        $tok = is_string($query['token'] ?? null) ? $query['token'] : '';
        if ($ref === '' || $tok === '' || ! hash_equals(self::notifyToken($ref), $tok)) {
            return null;
        }
        $status = strtoupper((string) (HttpClient::dig($b, 'transaction.transactionStatus') ?? ($b['transactionStatus'] ?? 'UPDATE')));
        $session = (string) ($b['sessionId'] ?? ($b['uuid'] ?? ''));

        return ['key' => mb_substr('notify:'.($session !== '' ? $session : $ref).':'.$status, 0, 190), 'type' => 'transaction.'.strtolower($status), 'ref' => $ref];
    }

    public function fetch(array $order): ?array
    {
        $sid = (string) ($order['provider_session'] ?? '');
        if ($sid === '') {
            return null;
        }
        $res = HttpClient::get($this->base().'/api/checkout/session/'.rawurlencode($sid), ['x-arifpay-key' => Settings::get('arifpay.api_key')]);
        if ($res['status'] === 404) {
            return null;
        }
        if ($res['status'] !== 200) {
            throw new PaymentUnavailable('arifpay session HTTP '.$res['status']);
        }
        $d = (array) ($res['json']['data'] ?? []);
        if (isset($d['nonce']) && (string) $d['nonce'] !== (string) $order['ref']) {
            return null;
        }
        $state = strtoupper((string) (HttpClient::dig($d, 'transaction.transactionStatus') ?? ($d['transactionStatus'] ?? ($d['paymentStatus'] ?? ($d['status'] ?? '')))));
        $trans = (string) (HttpClient::dig($d, 'transaction.transactionId') ?? ($d['transactionId'] ?? ''));

        return [
            'status' => match ($state) {
                'SUCCESS', 'COMPLETED', 'PAID' => 'succeeded', 'FAILED', 'FAILURE' => 'failed', 'CANCELLED', 'CANCELED', 'EXPIRED' => 'cancelled',
                'REFUNDED' => 'refunded', default => 'pending',
            },
            'amount_minor' => minor($d['totalAmount'] ?? ($d['amount'] ?? null)) ?? 0, 'currency' => 'ETB',
            'reference' => $trans !== '' ? mb_substr($trans, 0, 190) : null,
        ];
    }

    private function base(): string
    {
        return rtrim(Settings::get('arifpay.base_url', 'https://gateway.arifpay.net'), '/');
    }
}
