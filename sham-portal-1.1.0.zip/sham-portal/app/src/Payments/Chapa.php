<?php

declare(strict_types=1);

namespace Sham\Payments;

use Sham\Settings;

/**
 * Chapa hosted checkout in ETB (telebirr, CBE Birr, M-Pesa, bank apps, cards). The callback and webhook only trigger a
 * server-side GET /transaction/verify/{tx_ref}, which is the single source of truth. Webhooks: x-chapa-signature =
 * HMAC-SHA256(secret, body) or chapa-signature = HMAC-SHA256(secret, secret).
 */
final class Chapa implements Gateway
{
    public function key(): string
    {
        return 'chapa';
    }

    public function label(): string
    {
        return 'Chapa (telebirr, CBE Birr, bank apps, cards)';
    }

    public function configured(): bool
    {
        return Settings::bool('chapa.enabled') && Settings::has('chapa.secret_key') && Settings::has('chapa.webhook_secret');
    }

    public function currencies(): array
    {
        return ['ETB'];
    }

    public function testMode(): bool
    {
        return str_starts_with(Settings::get('chapa.secret_key'), 'CHASECK_TEST');
    }

    public function start(array $order, array $ctx): array
    {
        $parts = preg_split('/\s+/u', trim((string) $order['customer_name']), 2) ?: [];
        $res = HttpClient::postJson($this->base().'/transaction/initialize', array_filter([
            'amount' => major((int) $order['total_minor']), 'currency' => $order['currency'], 'email' => $order['customer_email'],
            'first_name' => mb_substr($parts[0] ?? '', 0, 50), 'last_name' => mb_substr($parts[1] ?? '', 0, 50),
            'tx_ref' => $order['ref'], 'callback_url' => $ctx['notify_url'], 'return_url' => $ctx['return_url'],
            'customization' => ['title' => mb_substr(self::plain($ctx['title']), 0, 16), 'description' => mb_substr(self::plain($ctx['title']), 0, 50)],
        ], fn ($v) => $v !== ''), $this->auth());
        $url = (string) HttpClient::dig($res['json'], 'data.checkout_url', '');
        if ($res['status'] !== 200 || ($res['json']['status'] ?? '') !== 'success' || ! str_starts_with($url, 'https://')) {
            throw new PaymentUnavailable('chapa initialize HTTP '.$res['status']);
        }

        return ['url' => $url, 'session' => null, 'instructions' => null];
    }

    public function verifyWebhook(string $raw, array $headers, array $query): ?array
    {
        $secret = Settings::get('chapa.webhook_secret');
        if ($secret === '') {
            return null;
        }
        $payloadSig = strtolower(trim($headers['x-chapa-signature'] ?? ''));
        $secretSig = strtolower(trim($headers['chapa-signature'] ?? ''));
        if ($payloadSig !== '') {
            if (! hash_equals(hash_hmac('sha256', $raw, $secret), $payloadSig)) {
                return null;
            }
        } elseif ($secretSig === '' || ! hash_equals(hash_hmac('sha256', $secret, $secret), $secretSig)) {
            return null;
        }
        $d = json_in($raw);
        $ref = (string) ($d['tx_ref'] ?? '');
        if ($ref === '') {
            return null;
        }
        $event = mb_substr((string) ($d['event'] ?? 'unknown'), 0, 60);

        return ['key' => mb_substr($event.':'.$ref.':'.(string) ($d['status'] ?? ''), 0, 190), 'type' => $event, 'ref' => $ref];
    }

    public function fetch(array $order): ?array
    {
        $res = HttpClient::get($this->base().'/transaction/verify/'.rawurlencode((string) $order['ref']), $this->auth());
        if (in_array($res['status'], [400, 404], true)) {
            return null;
        }
        if ($res['status'] !== 200) {
            throw new PaymentUnavailable('chapa verify HTTP '.$res['status']);
        }
        $d = (array) ($res['json']['data'] ?? []);
        if ((string) ($d['tx_ref'] ?? $order['ref']) !== (string) $order['ref']) {
            return null;
        }

        return [
            'status' => match (strtolower((string) ($d['status'] ?? ''))) {
                'success', 'successful' => 'succeeded', 'failed' => 'failed', 'cancelled', 'canceled' => 'cancelled',
                'refunded', 'reversed' => 'refunded', default => 'pending',
            },
            'amount_minor' => minor($d['amount'] ?? null) ?? 0, 'currency' => strtoupper((string) ($d['currency'] ?? '')),
            'reference' => isset($d['reference']) ? mb_substr((string) $d['reference'], 0, 190) : null,
        ];
    }

    private function base(): string
    {
        return rtrim(Settings::get('chapa.base_url', 'https://api.chapa.co/v1'), '/');
    }

    /** @return array<string, string> */
    private function auth(): array
    {
        return ['Authorization' => 'Bearer '.Settings::get('chapa.secret_key')];
    }

    private static function plain(string $s): string
    {
        return trim((string) preg_replace('/[^A-Za-z0-9 ._-]+/', ' ', $s));
    }
}
