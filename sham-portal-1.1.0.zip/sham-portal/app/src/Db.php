<?php

declare(strict_types=1);

namespace Sham;

use PDO;
use PDOStatement;

/** PDO (MySQL / MariaDB) with prepared statements only, UTC sessions and strict mode. */
final class Db
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo === null) {
            $d = (array) Config::get('db');
            $dsn = ($d['socket'] ?? '') !== ''
                ? 'mysql:unix_socket='.$d['socket'].';dbname='.$d['name'].';charset=utf8mb4'
                : 'mysql:host='.$d['host'].';port='.(int) ($d['port'] ?? 3306).';dbname='.$d['name'].';charset=utf8mb4';
            self::$pdo = self::connect($dsn, (string) $d['user'], (string) $d['pass']);
        }

        return self::$pdo;
    }

    public static function connect(string $dsn, string $user, string $pass): PDO
    {
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false,
        ]);
        $pdo->exec("SET time_zone = '+00:00', SESSION sql_mode = 'STRICT_ALL_TABLES,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION,ERROR_FOR_DIVISION_BY_ZERO'");

        return $pdo;
    }

    public static function use(?PDO $pdo): void
    {
        self::$pdo = $pdo;
    }

    /** @param array<int|string, mixed> $p */
    public static function run(string $sql, array $p = []): PDOStatement
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($p);

        return $st;
    }

    /**
     * @param  array<int|string, mixed>  $p
     * @return array<string, mixed>|null
     */
    public static function one(string $sql, array $p = []): ?array
    {
        $r = self::run($sql, $p)->fetch();

        return $r === false ? null : $r;
    }

    /**
     * @param  array<int|string, mixed>  $p
     * @return list<array<string, mixed>>
     */
    public static function all(string $sql, array $p = []): array
    {
        /** @var list<array<string, mixed>> */
        return self::run($sql, $p)->fetchAll();
    }

    /** @param array<int|string, mixed> $p */
    public static function value(string $sql, array $p = []): mixed
    {
        $v = self::run($sql, $p)->fetchColumn();

        return $v === false ? null : $v;
    }

    /** @param array<string, mixed> $row */
    public static function insert(string $table, array $row): void
    {
        $cols = array_keys($row);
        foreach ($cols as $c) {
            self::ident($c);
        }
        self::run('INSERT INTO '.self::ident($table).' ('.implode(',', array_map(fn ($c) => '`'.$c.'`', $cols)).') VALUES ('
            .implode(',', array_fill(0, count($cols), '?')).')', array_values($row));
    }

    /**
     * @param  array<string, mixed>  $set
     * @param  array<string, mixed>  $where
     */
    public static function update(string $table, array $set, array $where): int
    {
        $sql = 'UPDATE '.self::ident($table).' SET '.implode(',', array_map(fn ($c) => '`'.self::ident($c).'` = ?', array_keys($set)))
            .' WHERE '.implode(' AND ', array_map(fn ($c) => '`'.self::ident($c).'` = ?', array_keys($where)));

        return self::run($sql, [...array_values($set), ...array_values($where)])->rowCount();
    }

    /**
     * @template T
     *
     * @param  callable(): T  $fn
     * @return T
     */
    public static function tx(callable $fn): mixed
    {
        $pdo = self::pdo();
        if ($pdo->inTransaction()) {
            return $fn();
        }
        $pdo->beginTransaction();
        try {
            $r = $fn();
            $pdo->commit();

            return $r;
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    private static function ident(string $name): string
    {
        if (preg_match('/^[a-z_][a-z0-9_]*$/', $name) !== 1) {
            throw new \InvalidArgumentException('Bad identifier');
        }

        return $name;
    }
}
