<?php

declare(strict_types=1);

namespace Sham;

use Sham\Http\Hosts;
use Sham\Http\Request;
use Sham\Http\Response;
use Sham\Security\Guard;
use Sham\Security\Session;

/** Front controller: picks the site by host name, then the route by method and path. */
final class App
{
    public static function handle(Request $r): Response
    {
        View::$nonce = b64url(random_bytes(16));
        try {
            if (preg_match('#^/_accent/([0-9a-f]{6})(-root)?\.css$#', $r->path, $m) === 1) {
                return self::accent($m[1], ($m[2] ?? '') !== '');
            }
            if (! Config::installed()) {
                return Controllers\Install::handle($r);
            }
            self::upgrade();
            $site = Hosts::resolve($r->host);
            if ($site === null) {
                return Response::redirect(Config::url('company'), 301);
            }
            if ($site['site'] === 'www') {
                return Response::redirect(Config::url('company', $r->path), 301);
            }
            if (preg_match('#^/media/([a-z0-9]{24})/[^/]+$#', $r->path, $m) === 1 && $r->method === 'GET') {
                return Media::serve($m[1]);
            }
            if ($site['site'] === 'licensing') {
                return Controllers\Licensing::handle($r);
            }
            // Webhooks are server-to-server: no session, no CSRF (each gateway checks its own signature).
            if ($site['site'] === 'store' && preg_match('#^/webhooks/([a-z]+)$#', $r->path, $m) === 1) {
                return Controllers\Webhooks::handle($r, $m[1]);
            }
            // One-click unsubscribe (RFC 8058) is POSTed by the mail program: the secret token in the address is the authority.
            if ($site['site'] === 'company' && $r->isPost() && preg_match('#^/unsubscribe/([a-f0-9]{32})/now$#', $r->path, $m) === 1) {
                return Controllers\Subscriptions::oneClick($r, $m[1]);
            }
            Session::start();
            if ($r->isPost() && ! Guard::checkCsrf($r->input('_csrf'))) {
                return self::error(419, 'This form has expired. Go back, reload the page and try again.');
            }

            return match ($site['site']) {
                'company' => Controllers\Site::company($r),
                'product' => Controllers\Site::product($r, (array) $site['product']),
                'store' => str_starts_with($r->path, '/admin') ? Controllers\Admin::handle($r) : Controllers\Store::handle($r),
                default => self::error(404),
            };
        } catch (\Throwable $e) {
            error_log('sham portal: '.get_class($e).': '.$e->getMessage().' @ '.$e->getFile().':'.$e->getLine());

            return self::error(500, Config::local() ? $e->getMessage() : null);
        }
    }

    /** The product colour as a stylesheet, darkened for text contrast on white. */
    private static function accent(string $hex, bool $root): Response
    {
        [$r, $g, $b] = array_map('hexdec', str_split($hex, 2));
        $lum = fn (int $c): float => ($c /= 255) <= 0.03928 ? $c / 12.92 : (($c + 0.055) / 1.055) ** 2.4;
        $f = 1.0;
        while ($f > 0.2 && 0.2126 * $lum((int) ($r * $f)) + 0.7152 * $lum((int) ($g * $f)) + 0.0722 * $lum((int) ($b * $f)) > 0.18) {
            $f -= 0.05;
        }
        $ink = sprintf('#%02x%02x%02x', (int) ($r * $f), (int) ($g * $f), (int) ($b * $f));
        $css = ($root ? ':root' : '.ac-'.$hex)."{--accent:#{$hex};--accent-ink:{$ink}}\n";

        return new Response($css, 200, ['Content-Type' => 'text/css; charset=utf-8', 'Cache-Control' => 'public, max-age=31536000, immutable']);
    }

    /** New files uploaded: apply their database changes before anything else runs. */
    private static function upgrade(): void
    {
        $sig = SHAM_VERSION.'/'.implode(',', Migrator::available());
        if (Settings::get('system.schema') !== $sig) {
            $done = Migrator::run(Db::pdo());
            Settings::set('system.schema', $sig);
            if ($done !== []) {
                Audit::log('system.upgraded', 'system', SHAM_VERSION, ['migrations' => $done]);
            }
        }
    }

    /** Runs after the page has gone to the visitor: scheduled work when no cron job has done it lately. */
    public static function afterResponse(): void
    {
        if (! Config::installed()) {
            return;
        }
        try {
            if (Cron::due()) {
                if (function_exists('fastcgi_finish_request')) {
                    fastcgi_finish_request();
                } elseif (function_exists('litespeed_finish_request')) {
                    litespeed_finish_request();
                }
                ignore_user_abort(true);
                @set_time_limit(120);
                Cron::run('web');
            }
        } catch (\Throwable $e) {
            error_log('sham web cron: '.$e->getMessage());
        }
    }

    public static function error(int $status, ?string $message = null): Response
    {
        $titles = [403 => 'Not allowed', 404 => 'Page not found', 405 => 'Not allowed', 419 => 'Form expired', 429 => 'Too many attempts', 500 => 'Something went wrong'];
        $msg = $message ?? match ($status) {
            404 => 'The page you asked for is not here. It may have moved.',
            429 => 'Please wait a few minutes and try again.',
            500 => 'We could not complete this request. Please try again in a moment; if it keeps happening, write to '.self::supportEmail().'.',
            default => 'This request cannot be completed.',
        };
        try {
            $html = View::render('error', ['title' => $titles[$status] ?? 'Error', 'message' => $msg, 'status' => $status, 'site' => 'company']);
        } catch (\Throwable) {
            $html = '<!doctype html><meta charset="utf-8"><title>'.e($titles[$status] ?? 'Error').'</title><p>'.e($msg).'</p>';
        }

        return Response::html($html, $status);
    }

    private static function supportEmail(): string
    {
        try {
            return Settings::get('company.support_email');
        } catch (\Throwable) {
            return 'support@sham.et';
        }
    }
}
