<?php

declare(strict_types=1);

namespace Sham;

use Sham\Store\Ledger;
use Sham\Store\Notifier;

/**
 * Scheduled work: confirm pending payments, close unpaid orders, expiry reminders, the mail queue (news to
 * subscribers), and housekeeping. Runs from app/cron.php when a cron job exists, and otherwise by itself after a page
 * has been sent to a visitor at most every 10 minutes ("web cron"), so a site without cron jobs still works.
 */
final class Cron
{
    public static function due(): bool
    {
        $last = (int) Settings::get('cron.last_run', '0');

        return time() - $last >= 600;
    }

    /** @return list<string> what happened, for the log */
    public static function run(string $via): array
    {
        @mkdir(SHAM_APP.'/storage', 0700, true);
        $lock = @fopen(SHAM_APP.'/storage/cron.lock', 'c');
        if ($lock === false || ! flock($lock, LOCK_EX | LOCK_NB)) {
            return [];
        }
        Settings::set('cron.last_run', (string) time());
        Settings::set('cron.via', $via);
        $log = [];
        try {
            Migrator::run(Db::pdo());

            // 1. Pending online payments.
            foreach (Db::all("SELECT id FROM orders WHERE status = 'pending' AND provider <> 'bank' AND created_at > UTC_TIMESTAMP() - INTERVAL 3 DAY
                AND (checked_at IS NULL OR checked_at < UTC_TIMESTAMP() - INTERVAL 10 MINUTE) ORDER BY created_at LIMIT 30") as $o) {
                try {
                    $st = Ledger::refresh((string) $o['id']);
                    if ($st !== 'pending') {
                        $log[] = "order {$o['id']} is now {$st}";
                    }
                } catch (\Throwable $e) {
                    error_log('sham cron refresh '.$o['id'].': '.$e->getMessage());
                }
            }

            // 2. Unpaid orders.
            $hours = max(1, (int) Settings::get('store.pending_hours', '48'));
            $bankHours = max($hours, 24 * 14);
            $n = Db::run("UPDATE orders SET status = 'cancelled', failure_reason = 'Not paid in time.' WHERE status = 'pending'
                AND ((provider <> 'bank' AND created_at < UTC_TIMESTAMP() - INTERVAL {$hours} HOUR) OR created_at < UTC_TIMESTAMP() - INTERVAL {$bankHours} HOUR)")->rowCount();
            if ($n > 0) {
                Audit::log('orders.closed_unpaid', 'cron', null, ['count' => $n]);
                $log[] = "closed {$n} unpaid orders";
            }

            // 3. Expiry reminders 30 and 7 days before.
            foreach ([30, 7] as $days) {
                foreach (Db::all("SELECT * FROM licences WHERE status = 'active' AND expires_at IS NOT NULL
                    AND expires_at BETWEEN UTC_TIMESTAMP() AND UTC_TIMESTAMP() + INTERVAL {$days} DAY
                    AND (reminded_at IS NULL OR reminded_at < expires_at - INTERVAL {$days} DAY) LIMIT 50") as $l) {
                    Db::update('licences', ['reminded_at' => now_utc()], ['id' => $l['id']]);
                    try {
                        Notifier::expiring($l, max(1, (int) ceil((strtotime($l['expires_at'].' UTC') - time()) / 86400)));
                        $log[] = "reminded {$l['id']} ({$days} days)";
                    } catch (\Throwable $e) {
                        error_log('sham cron reminder '.$l['id'].': '.$e->getMessage());
                    }
                }
            }

            // 4. Mail queue (news to subscribers): a small batch each run, so shared hosting mail limits are respected.
            $batch = max(1, min(200, (int) Settings::get('mail.batch_per_run', '40')));
            $sent = 0;
            foreach (Db::all('SELECT * FROM mail_queue WHERE sent_at IS NULL AND attempts < 3 ORDER BY id LIMIT '.$batch) as $m) {
                $ok = Mailer::send((string) $m['to_email'], (string) $m['subject'], (string) $m['body'], $m['reply_to'] !== null ? (string) $m['reply_to'] : null,
                    ($m['unsubscribe_url'] ?? null) !== null ? (string) $m['unsubscribe_url'] : null);
                Db::update('mail_queue', $ok ? ['sent_at' => now_utc(), 'attempts' => (int) $m['attempts'] + 1] : ['attempts' => (int) $m['attempts'] + 1], ['id' => $m['id']]);
                $sent += $ok ? 1 : 0;
            }
            if ($sent > 0) {
                $log[] = "{$sent} news e-mail".($sent === 1 ? '' : 's').' sent';
            }

            // 5. Housekeeping.
            Db::run('DELETE FROM sessions WHERE updated_at < UTC_TIMESTAMP() - INTERVAL 13 HOUR');
            Db::run('DELETE FROM rate_limits WHERE reset_at < UTC_TIMESTAMP()');
            Db::run('DELETE FROM login_tokens WHERE expires_at < UTC_TIMESTAMP() - INTERVAL 1 DAY');
            Db::run('DELETE FROM mail_log WHERE created_at < UTC_TIMESTAMP() - INTERVAL 180 DAY');
            Db::run('DELETE FROM mail_queue WHERE sent_at < UTC_TIMESTAMP() - INTERVAL 30 DAY');
        } finally {
            flock($lock, LOCK_UN);
        }

        return $log;
    }
}
