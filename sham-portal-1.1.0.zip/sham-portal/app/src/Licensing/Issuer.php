<?php

declare(strict_types=1);

namespace Sham\Licensing;

use Sham\Audit;
use Sham\Db;

/**
 * Issues and renews signed licences. The payload matches what Sham MediaOS verifies (LicenceCodec::licence()):
 * v, id, customer{name,email,country}, edition, domains, limits, features, issued_at, expires_at, updates_until, offline.
 */
final class Issuer
{
    /**
     * @param  array{name: string, email: string, country?: string|null}  $customer
     * @param  list<string>  $domains
     * @param  array<string, int|null>|null  $limits  null = the edition's limits
     * @return array<string, mixed> the licence row
     */
    public static function issue(int $productId, array $customer, string $editionKey, string $term, array $domains, ?int $months = null,
        int $updateMonths = 12, ?array $limits = null, bool $offline = false, ?string $actor = null, ?string $notes = null): array
    {
        $edition = Db::one('SELECT * FROM editions WHERE product_id = ? AND ekey = ?', [$productId, $editionKey]);
        if ($edition === null) {
            throw new \InvalidArgumentException('Unknown edition.');
        }
        $domains = self::normaliseDomains($domains);
        if ($domains === []) {
            throw new \InvalidArgumentException('Give at least one valid domain.');
        }
        $term = in_array($term, ['year', 'perpetual', 'custom'], true) ? $term : 'custom';
        $limits ??= json_in((string) $edition['limits_json']);
        $now = time();
        $months ??= $term === 'year' ? 12 : null;
        $expires = $term === 'perpetual' ? null : ($months !== null && $months > 0 ? self::addMonths($now, $months) : null);
        $updates = self::addMonths($now, max(1, $updateMonths));
        $id = 'LIC-'.ulid();
        $email = mb_strtolower(trim($customer['email']));
        $country = strtoupper(trim((string) ($customer['country'] ?? '')));
        $payload = [
            'v' => 1, 'id' => $id,
            'customer' => ['name' => $customer['name'], 'email' => $email, 'country' => $country],
            'edition' => $editionKey, 'domains' => $domains, 'limits' => $limits,
            'features' => json_in((string) $edition['features_json']),
            'issued_at' => self::iso($now), 'expires_at' => $expires !== null ? self::iso($expires) : null,
            'updates_until' => self::iso($updates), 'offline' => $offline,
        ];
        $row = [
            'id' => $id, 'product_id' => $productId, 'customer_name' => $customer['name'], 'customer_email' => $email,
            'customer_country' => $country !== '' ? $country : null, 'edition' => $editionKey, 'term' => $term,
            'domains_json' => json_out($domains), 'limits_json' => json_out($limits), 'offline' => $offline ? 1 : 0,
            'issued_at' => gmdate('Y-m-d H:i:s', $now), 'expires_at' => $expires !== null ? gmdate('Y-m-d H:i:s', $expires) : null,
            'updates_until' => gmdate('Y-m-d H:i:s', $updates), 'status' => 'active',
            'token' => Codec::sign(Codec::LICENCE, $payload), 'notes' => $notes !== null ? mb_substr($notes, 0, 500) : null, 'created_at' => now_utc(),
        ];
        Db::insert('licences', $row);
        Audit::log('licence.issued', $actor ?? 'system', $id, ['edition' => $editionKey, 'term' => $term, 'domains' => $domains, 'offline' => $offline]);

        return $row;
    }

    /** Re-sign with a later expiry (a renewal), keeping the ID; the installation picks it up at its next check-in. */
    public static function extend(string $licenceId, int $months, int $updateMonths = 12, ?string $actor = null): array
    {
        return Db::tx(function () use ($licenceId, $months, $updateMonths, $actor): array {
            $l = Db::one('SELECT * FROM licences WHERE id = ? FOR UPDATE', [$licenceId]) ?? throw new \InvalidArgumentException('Unknown licence.');
            $p = Codec::verify((string) $l['token'], Codec::LICENCE);
            if ($p === null) {
                throw new \RuntimeException('The stored licence no longer verifies with the signing key.');
            }
            $now = time();
            $exp = $l['expires_at'] !== null ? strtotime($l['expires_at'].' UTC') : null;
            $upd = $l['updates_until'] !== null ? strtotime($l['updates_until'].' UTC') : null;
            if ($l['term'] !== 'perpetual' && $months > 0) {
                $p['expires_at'] = self::iso(self::addMonths($exp !== null && $exp > $now ? $exp : $now, $months));
            }
            if ($updateMonths > 0) {
                $p['updates_until'] = self::iso(self::addMonths($upd !== null && $upd > $now ? $upd : $now, $updateMonths));
            }
            $p['issued_at'] = self::iso($now);
            Db::update('licences', [
                'token' => Codec::sign(Codec::LICENCE, $p), 'issued_at' => gmdate('Y-m-d H:i:s', $now),
                'expires_at' => isset($p['expires_at']) && $p['expires_at'] !== null ? gmdate('Y-m-d H:i:s', (int) strtotime((string) $p['expires_at'])) : null,
                'updates_until' => gmdate('Y-m-d H:i:s', (int) strtotime((string) $p['updates_until'])), 'reminded_at' => null,
            ], ['id' => $licenceId]);
            Audit::log('licence.extended', $actor ?? 'system', $licenceId, ['expires_at' => $p['expires_at'] ?? null, 'updates_until' => $p['updates_until']]);

            return (array) Db::one('SELECT * FROM licences WHERE id = ?', [$licenceId]);
        });
    }

    /**
     * @param  list<string>  $domains
     * @return list<string>
     */
    public static function normaliseDomains(array $domains): array
    {
        $out = [];
        foreach ($domains as $d) {
            $d = strtolower(trim((string) $d));
            $d = (string) preg_replace('#^https?://#', '', $d);
            $d = rtrim(explode('/', $d)[0], '.');
            if (strlen($d) <= 253 && preg_match('/^(\*\.)?([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $d) === 1) {
                $out[] = $d;
            }
        }

        return array_values(array_unique($out));
    }

    public static function iso(int $t): string
    {
        return gmdate('Y-m-d\TH:i:s\+00:00', $t);
    }

    public static function addMonths(int $t, int $months): int
    {
        return (int) (new \DateTimeImmutable('@'.$t))->modify('+'.$months.' months')->getTimestamp();
    }
}
