<?php

declare(strict_types=1);

namespace Sham\Licensing;

use Sham\Audit;
use Sham\Db;
use Sham\Settings;

/**
 * Answers an installation's daily check-in (POST /api/v1/licensing/check-in, the path Sham MediaOS calls): binds a
 * licence to the first installation that checks in, refuses a second one, reports revocation, and hands over a renewed
 * key. Every answer is signed (CHK1) so the installation can tell it came from Sham.
 */
final class CheckIn
{
    /**
     * @param  array<string, mixed>  $in  validated: licence_id, installation_id, hosts, version, usage
     */
    public static function answer(array $in): string
    {
        $support = Settings::get('company.support_email');
        [$status, $message, $token] = Db::tx(function () use ($in, $support): array {
            $l = Db::one('SELECT * FROM licences WHERE id = ? FOR UPDATE', [$in['licence_id']]);
            if ($l === null) {
                return ['revoked', 'This licence is unknown to the vendor. Contact '.$support.'.', null];
            }
            if ($l['status'] === 'revoked') {
                return ['revoked', $l['revoked_reason'] !== null && $l['revoked_reason'] !== '' ? (string) $l['revoked_reason'] : 'The vendor has withdrawn this licence.', null];
            }
            if ($l['installation_id'] !== null && $l['installation_id'] !== $in['installation_id']) {
                Audit::log('licence.bound_elsewhere', 'system', (string) $l['id'], ['bound' => $l['installation_id'], 'seen' => $in['installation_id'],
                    'hosts' => array_slice($in['hosts'], 0, 5)]);

                return ['bound_elsewhere', 'This licence is already in use on another installation. Moving servers? Ask '.$support.' to release it.', null];
            }
            Db::update('licences', [
                'installation_id' => $in['installation_id'], 'bound_at' => $l['bound_at'] ?? now_utc(), 'last_check_in_at' => now_utc(),
                'last_hosts_json' => json_out(array_slice($in['hosts'], 0, 10)), 'last_version' => $in['version'],
                'last_usage_json' => json_out($in['usage']), 'check_ins' => (int) $l['check_ins'] + 1,
            ], ['id' => $l['id']]);
            if ($l['installation_id'] === null) {
                Audit::log('licence.bound', 'system', (string) $l['id'], ['installation' => $in['installation_id'], 'hosts' => array_slice($in['hosts'], 0, 5)]);
            }

            return ['active', 'Licence confirmed.', (string) $l['token']];
        });

        return Codec::sign(Codec::CHECK_IN, array_filter([
            'licence_id' => $in['licence_id'], 'installation_id' => $in['installation_id'], 'status' => $status, 'message' => $message,
            'issued_at' => Issuer::iso(time()), 'licence' => $token,
        ], fn ($v) => $v !== null));
    }

    /**
     * Validates the check-in body; returns the clean input or an error message.
     *
     * @param  array<string, mixed>  $b
     * @return array<string, mixed>|string
     */
    public static function validate(array $b): array|string
    {
        $id = $b['licence_id'] ?? null;
        $inst = $b['installation_id'] ?? null;
        if (! is_string($id) || preg_match('/^LIC-[0-9A-Z]{26}$/', $id) !== 1) {
            return 'licence_id is invalid.';
        }
        if (! is_string($inst) || preg_match('/^[0-9a-hjkmnp-tv-z]{26}$/i', $inst) !== 1) {
            return 'installation_id is invalid.';
        }
        $hosts = [];
        foreach (array_slice(is_array($b['hosts'] ?? null) ? $b['hosts'] : [], 0, 10) as $h) {
            if (is_string($h) && strlen($h) <= 253) {
                $hosts[] = strtolower($h);
            }
        }
        $usage = [];
        foreach (array_slice(is_array($b['usage'] ?? null) ? $b['usage'] : [], 0, 10, true) as $k => $v) {
            if (is_string($k) && preg_match('/^[a-z_]{1,30}$/', $k) === 1 && is_int($v) && $v >= 0 && $v <= 100000000) {
                $usage[$k] = $v;
            }
        }
        $version = is_string($b['version'] ?? null) ? mb_substr($b['version'], 0, 30) : null;

        return ['licence_id' => $id, 'installation_id' => $inst, 'hosts' => $hosts, 'usage' => $usage, 'version' => $version];
    }
}
