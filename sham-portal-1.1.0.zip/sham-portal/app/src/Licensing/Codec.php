<?php

declare(strict_types=1);

namespace Sham\Licensing;

use Sham\Settings;

/**
 * The same signed-token format as Sham MediaOS (App\Domain\Licensing\LicenceCodec):
 * "<kind>.<base64url JSON payload>.<base64url Ed25519 signature over '<kind>.<payload>'>". LIC1 = licence, CHK1 =
 * check-in answer. The signing key is stored encrypted in settings and only ever used on this server.
 */
final class Codec
{
    public const LICENCE = 'LIC1';

    public const CHECK_IN = 'CHK1';

    /** @param array<string, mixed> $payload */
    public static function sign(string $kind, array $payload, ?string $secretKey = null): string
    {
        $sk = $secretKey ?? self::secretKey();
        if (strlen($sk) !== SODIUM_CRYPTO_SIGN_SECRETKEYBYTES) {
            throw new \RuntimeException('The licence signing key is not set. Import it in Admin → Signing key.');
        }
        $body = $kind.'.'.b64url((string) json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));

        return $body.'.'.b64url(sodium_crypto_sign_detached($body, $sk));
    }

    /**
     * @param  list<string>|null  $publicKeysB64
     * @return array<string, mixed>|null
     */
    public static function verify(string $token, string $kind, ?array $publicKeysB64 = null): ?array
    {
        $parts = explode('.', trim($token));
        if (count($parts) !== 3 || $parts[0] !== $kind || strlen($token) > 16384) {
            return null;
        }
        $sig = unb64url($parts[2]);
        $json = unb64url($parts[1]);
        if ($sig === null || $json === null || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) {
            return null;
        }
        $keys = $publicKeysB64 ?? self::publicKeys();
        if (($own = self::publicKey()) !== null) {
            $keys[] = base64_encode($own);
        }
        foreach (array_unique($keys) as $k) {
            $pk = base64_decode($k, true);
            if ($pk !== false && strlen($pk) === SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES
                && sodium_crypto_sign_verify_detached($sig, $parts[0].'.'.$parts[1], $pk)) {
                $p = json_decode($json, true);

                return is_array($p) ? $p : null;
            }
        }

        return null;
    }

    public static function available(): bool
    {
        return strlen(self::secretKey()) === SODIUM_CRYPTO_SIGN_SECRETKEYBYTES;
    }

    public static function publicKey(): ?string
    {
        $sk = self::secretKey();

        return strlen($sk) === SODIUM_CRYPTO_SIGN_SECRETKEYBYTES ? sodium_crypto_sign_publickey_from_secretkey($sk) : null;
    }

    /** @return list<string> */
    public static function publicKeys(): array
    {
        return array_values(array_filter(array_map('trim', explode(',', Settings::get('licence.public_keys')))));
    }

    /**
     * Turns the OpenSSL Ed25519 private key (PKCS#8 PEM, as made by `openssl genpkey -algorithm ed25519`) into the
     * sodium secret key, stores it encrypted, and returns the public key (base64).
     */
    public static function importPem(string $pem): string
    {
        if (preg_match('/-----BEGIN PRIVATE KEY-----(.+?)-----END PRIVATE KEY-----/s', $pem, $m) !== 1) {
            throw new \InvalidArgumentException('This is not a PEM private key.');
        }
        $der = base64_decode((string) preg_replace('/\s+/', '', $m[1]), true);
        // PKCS#8 for Ed25519: a fixed 16-byte header, then the 32-byte seed.
        if ($der === false || strlen($der) !== 48 || ! str_starts_with(bin2hex($der), '302e020100300506032b657004220420')) {
            throw new \InvalidArgumentException('This is not an Ed25519 private key.');
        }
        $kp = sodium_crypto_sign_seed_keypair(substr($der, 16, 32));
        Settings::set('licence.private_key', base64_encode(sodium_crypto_sign_secretkey($kp)));

        return base64_encode(sodium_crypto_sign_publickey($kp));
    }

    private static function secretKey(): string
    {
        $b64 = Settings::get('licence.private_key');
        $raw = $b64 === '' ? false : base64_decode($b64, true);

        return $raw === false ? '' : $raw;
    }
}
