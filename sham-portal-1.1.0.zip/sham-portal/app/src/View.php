<?php

declare(strict_types=1);

namespace Sham;

/** PHP templates in app/views. Templates escape with e(); the layout receives the page in $content. */
final class View
{
    public static string $nonce = '';

    /** @param array<string, mixed> $vars */
    public static function render(string $template, array $vars = [], ?string $layout = 'layout'): string
    {
        $content = self::partial($template, $vars);
        if ($layout === null) {
            return $content;
        }

        return self::partial($layout, $vars + ['content' => $content]);
    }

    /** @param array<string, mixed> $vars */
    public static function partial(string $template, array $vars = []): string
    {
        if (preg_match('#^[a-z0-9_/-]+$#', $template) !== 1) {
            throw new \InvalidArgumentException('Bad template name');
        }
        $file = SHAM_APP.'/views/'.$template.'.php';
        $vars['nonce'] = self::$nonce;
        ob_start();
        (static function (string $__file, array $__vars): void {
            extract($__vars, EXTR_SKIP);
            require $__file;
        })($file, $vars);

        return (string) ob_get_clean();
    }
}
