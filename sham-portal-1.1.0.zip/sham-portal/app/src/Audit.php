<?php

declare(strict_types=1);

namespace Sham;

/**
 * Append-only, hash-chained audit log: each row's hash covers its content and the previous row's hash, so a deleted or
 * edited row breaks the chain ({@see self::verify()}, shown in the admin).
 */
final class Audit
{
    /** @param array<string, mixed> $data */
    public static function log(string $action, ?string $actor = null, ?string $subject = null, array $data = []): void
    {
        Db::tx(function () use ($action, $actor, $subject, $data): void {
            $prev = (string) (Db::value('SELECT hash FROM audit_log ORDER BY id DESC LIMIT 1 FOR UPDATE') ?? str_repeat('0', 64));
            $at = now_utc();
            $json = json_out($data);
            $hash = hash('sha256', implode("\x1f", [$prev, $at, (string) $actor, $action, (string) $subject, $json]));
            Db::insert('audit_log', ['created_at' => $at, 'actor' => $actor, 'action' => $action, 'subject' => $subject, 'data' => $json,
                'prev_hash' => $prev, 'hash' => $hash]);
        });
    }

    /** @return array{ok: bool, rows: int, broken_at: int|null} */
    public static function verify(): array
    {
        $prev = str_repeat('0', 64);
        $n = 0;
        foreach (Db::run('SELECT * FROM audit_log ORDER BY id') as $r) {
            $n++;
            $hash = hash('sha256', implode("\x1f", [$prev, $r['created_at'], (string) $r['actor'], $r['action'], (string) $r['subject'], $r['data']]));
            if ($r['prev_hash'] !== $prev || ! hash_equals($hash, (string) $r['hash'])) {
                return ['ok' => false, 'rows' => $n, 'broken_at' => (int) $r['id']];
            }
            $prev = $r['hash'];
        }

        return ['ok' => true, 'rows' => $n, 'broken_at' => null];
    }
}
