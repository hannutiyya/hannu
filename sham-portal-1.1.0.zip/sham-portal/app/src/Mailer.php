<?php

declare(strict_types=1);

namespace Sham;

/**
 * Plain-text e-mail through the host's SMTP server (implicit TLS on 465 or STARTTLS on 587, AUTH LOGIN), falling back
 * to PHP mail() when no SMTP host is set. With config mail_to_files the messages are written to storage/mail instead
 * (local testing). Every attempt is logged in mail_log without the body.
 */
final class Mailer
{
    /** @param string|null $unsubscribe a https unsubscribe address for news e-mails (List-Unsubscribe, RFC 8058 one-click) */
    public static function send(string $to, string $subject, string $body, ?string $replyTo = null, ?string $unsubscribe = null): bool
    {
        $to = trim($to);
        if (! filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return false;
        }
        $subject = str_replace(["\r", "\n"], ' ', $subject);
        $from = Settings::get('smtp.from', 'no-reply@sham.et');
        $fromName = str_replace(['"', "\r", "\n"], '', Settings::get('smtp.from_name', 'Sham'));
        $domain = substr(strrchr($from, '@') ?: '@sham.et', 1);
        $headers = [
            'Date' => gmdate('D, d M Y H:i:s').' +0000',
            'From' => '"'.self::encodeHeader($fromName).'" <'.$from.'>',
            'To' => '<'.$to.'>',
            'Subject' => self::encodeHeader($subject),
            'Message-ID' => '<'.token(12).'@'.$domain.'>',
            'MIME-Version' => '1.0',
            'Content-Type' => 'text/plain; charset=UTF-8',
            'Content-Transfer-Encoding' => 'base64',
            'Auto-Submitted' => 'auto-generated',
        ];
        if ($unsubscribe !== null && preg_match('#^https?://[^\s<>]+$#', $unsubscribe) === 1) {
            $headers['List-Unsubscribe'] = '<'.$unsubscribe.'>';
            $headers['List-Unsubscribe-Post'] = 'List-Unsubscribe=One-Click';
            $headers['Precedence'] = 'bulk';
        }
        if ($replyTo !== null && filter_var($replyTo, FILTER_VALIDATE_EMAIL)) {
            $headers['Reply-To'] = '<'.$replyTo.'>';
        }
        $encoded = rtrim(chunk_split(base64_encode(str_replace("\r\n", "\n", $body)), 76, "\r\n"));
        $error = null;
        try {
            if (Config::get('mail_to_files')) {
                $dir = SHAM_APP.'/storage/mail';
                if (! is_dir($dir)) {
                    mkdir($dir, 0700, true);
                }
                $msg = '';
                foreach ($headers as $k => $v) {
                    $msg .= $k.': '.$v."\r\n";
                }
                file_put_contents($dir.'/'.gmdate('Ymd-His').'-'.token(4).'.eml', $msg."\r\n".$encoded."\r\n");
            } elseif (Settings::get('smtp.host') !== '') {
                self::smtp($from, $to, $headers, $encoded);
            } else {
                $h = $headers;
                unset($h['To'], $h['Subject']);
                $lines = [];
                foreach ($h as $k => $v) {
                    $lines[] = $k.': '.$v;
                }
                if (! mail($to, $headers['Subject'], $encoded, implode("\r\n", $lines), '-f'.$from)) {
                    throw new \RuntimeException('mail() refused the message');
                }
            }
        } catch (\Throwable $e) {
            $error = mb_substr($e->getMessage(), 0, 250);
            error_log('sham mail failed: '.$error);
        }
        try {
            Db::insert('mail_log', ['to_email' => $to, 'subject' => mb_substr($subject, 0, 250), 'ok' => $error === null ? 1 : 0, 'error' => $error, 'created_at' => now_utc()]);
        } catch (\Throwable) {
        }

        return $error === null;
    }

    /** @param array<string, string> $headers */
    private static function smtp(string $from, string $to, array $headers, string $body): void
    {
        $host = Settings::get('smtp.host');
        $port = (int) Settings::get('smtp.port', '465');
        $secure = Settings::get('smtp.secure', 'ssl');
        $ctx = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'peer_name' => $host]]);
        $fp = @stream_socket_client(($secure === 'ssl' ? 'ssl://' : 'tcp://').$host.':'.$port, $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
        if ($fp === false) {
            throw new \RuntimeException('SMTP connect failed: '.$errstr);
        }
        stream_set_timeout($fp, 20);
        $read = function () use ($fp): string {
            $data = '';
            while (($line = fgets($fp, 1024)) !== false) {
                $data .= $line;
                if (strlen($line) < 4 || $line[3] === ' ') {
                    break;
                }
            }

            return $data;
        };
        $cmd = function (string $c, array $ok) use ($fp, $read): string {
            if ($c !== '') {
                fwrite($fp, $c."\r\n");
            }
            $r = $read();
            if (! in_array((int) substr($r, 0, 3), $ok, true)) {
                throw new \RuntimeException('SMTP: '.trim(substr($r, 0, 120)));
            }

            return $r;
        };
        $me = Config::host('company') ?: 'localhost';
        $cmd('', [220]);
        $cmd('EHLO '.$me, [250]);
        if ($secure === 'tls') {
            $cmd('STARTTLS', [220]);
            if (! stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT)) {
                throw new \RuntimeException('SMTP STARTTLS failed');
            }
            $cmd('EHLO '.$me, [250]);
        }
        if (Settings::get('smtp.user') !== '') {
            $cmd('AUTH LOGIN', [334]);
            $cmd(base64_encode(Settings::get('smtp.user')), [334]);
            $cmd(base64_encode(Settings::get('smtp.pass')), [235]);
        }
        $cmd('MAIL FROM:<'.$from.'>', [250]);
        $cmd('RCPT TO:<'.$to.'>', [250, 251]);
        $cmd('DATA', [354]);
        $msg = '';
        foreach ($headers as $k => $v) {
            $msg .= $k.': '.$v."\r\n";
        }
        $msg .= "\r\n".$body;
        $msg = (string) preg_replace('/^\./m', '..', $msg);
        $cmd($msg."\r\n.", [250]);
        $cmd('QUIT', [221]);
        fclose($fp);
    }

    private static function encodeHeader(string $s): string
    {
        return preg_match('/[^\x20-\x7E]/', $s) === 1 ? '=?UTF-8?B?'.base64_encode($s).'?=' : $s;
    }
}
