<?php

declare(strict_types=1);

namespace Sham;

use Sham\Http\Response;

/**
 * Uploaded images and files. Stored outside the web root (app/storage/media) and served by /media/{uid}/{name}.
 * Images (JPEG, PNG, WebP, GIF) are decoded and re-encoded with GD, which drops metadata and anything hidden in the
 * file; SVG and HTML are never accepted. Other files (PDF, ZIP) are served as downloads only.
 */
final class Media
{
    public const MAX_IMAGE = 8 * 1024 * 1024;

    private const IMAGE_TYPES = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];

    private const FILE_TYPES = ['application/pdf' => 'pdf', 'application/zip' => 'zip'];

    public static function dir(): string
    {
        $d = SHAM_APP.'/storage/media';
        if (! is_dir($d)) {
            @mkdir($d, 0700, true);
        }

        return $d;
    }

    /**
     * @param  array{name?: string, tmp_name?: string, error?: int, size?: int}  $upload  one entry of $_FILES
     * @return array<string, mixed> the stored row
     *
     * @throws \InvalidArgumentException with a message for the person uploading
     */
    public static function store(array $upload, string $alt, string $actor, int $maxBytes = self::MAX_IMAGE): array
    {
        if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || ! is_string($upload['tmp_name'] ?? null) || ! is_uploaded_file($upload['tmp_name'])) {
            throw new \InvalidArgumentException(match ($upload['error'] ?? UPLOAD_ERR_NO_FILE) {
                UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'The file is larger than this server accepts ('.ini_get('upload_max_filesize').').',
                UPLOAD_ERR_NO_FILE => 'Choose a file.',
                default => 'The upload did not complete. Try again.',
            });
        }

        return self::storePath($upload['tmp_name'], (string) ($upload['name'] ?? 'file'), $alt, $actor, $maxBytes);
    }

    /** @return array<string, mixed> */
    public static function storePath(string $tmp, string $originalName, string $alt, string $actor, int $maxBytes = self::MAX_IMAGE): array
    {
        $size = (int) filesize($tmp);
        if ($size <= 0 || $size > $maxBytes) {
            throw new \InvalidArgumentException('Files may be up to '.round($maxBytes / 1048576).' MB.');
        }
        $mime = (string) (new \finfo(FILEINFO_MIME_TYPE))->file($tmp);
        $uid = strtolower(substr(ulid(), 0, 24));
        $base = self::cleanName($originalName);
        $width = $height = null;
        if (isset(self::IMAGE_TYPES[$mime])) {
            $info = @getimagesize($tmp);
            if ($info === false || $info[0] < 1 || $info[1] < 1 || $info[0] * $info[1] > 40_000_000) {
                throw new \InvalidArgumentException('That image cannot be read, or it is too large (40 megapixels at most).');
            }
            $ext = self::IMAGE_TYPES[$mime];
            $dest = self::dir().'/'.$uid.'.'.$ext;
            if (! self::reencode($tmp, $dest, $mime)) {
                throw new \InvalidArgumentException('That image cannot be read.');
            }
            [$width, $height] = [$info[0], $info[1]];
            $kind = 'image';
        } elseif (isset(self::FILE_TYPES[$mime])) {
            $ext = self::FILE_TYPES[$mime];
            $dest = self::dir().'/'.$uid.'.'.$ext;
            if (! @copy($tmp, $dest)) {
                throw new \InvalidArgumentException('The file could not be saved. Check that app/storage is writable.');
            }
            $kind = 'file';
        } else {
            throw new \InvalidArgumentException('Only JPEG, PNG, WebP, GIF, PDF and ZIP files are accepted.');
        }
        @chmod($dest, 0600);
        $name = preg_replace('/\.[a-z0-9]+$/i', '', $base).'.'.$ext;
        $row = ['uid' => $uid, 'filename' => $name, 'mime' => $mime, 'bytes' => (int) filesize($dest), 'width' => $width, 'height' => $height,
            'alt' => str_limit($alt, 255), 'kind' => $kind, 'sha256' => hash_file('sha256', $dest), 'created_by' => $actor, 'created_at' => now_utc()];
        Db::insert('media', $row);
        $row['id'] = (int) Db::pdo()->lastInsertId();
        Audit::log('media.uploaded', $actor, $uid, ['name' => $name, 'bytes' => $row['bytes']]);

        return $row;
    }

    public static function url(array $m): string
    {
        return '/media/'.$m['uid'].'/'.rawurlencode((string) $m['filename']);
    }

    public static function path(array $m): string
    {
        return self::dir().'/'.$m['uid'].'.'.pathinfo((string) $m['filename'], PATHINFO_EXTENSION);
    }

    /** GET /media/{uid}/{name} on any host. */
    public static function serve(string $uid): Response
    {
        $m = Db::one('SELECT * FROM media WHERE uid = ?', [$uid]);
        $file = $m !== null ? self::path($m) : '';
        if ($m === null || ! is_file($file)) {
            return App::error(404);
        }
        $headers = ['Content-Type' => (string) $m['mime'], 'Cache-Control' => 'public, max-age=31536000, immutable', 'X-Content-Type-Options' => 'nosniff',
            'Content-Security-Policy' => "default-src 'none'; sandbox", 'Content-Length' => (string) filesize($file)];
        if ($m['kind'] !== 'image') {
            $headers['Content-Disposition'] = 'attachment; filename="'.str_replace('"', '', (string) $m['filename']).'"';
        }

        return Response::file($file, $headers);
    }

    public static function delete(array $m, string $actor): void
    {
        @unlink(self::path($m));
        Db::run('DELETE FROM media WHERE id = ?', [$m['id']]);
        Db::run('UPDATE posts SET cover_media_id = NULL WHERE cover_media_id = ?', [$m['id']]);
        Db::run('UPDATE products SET logo_media_id = NULL WHERE logo_media_id = ?', [$m['id']]);
        Audit::log('media.deleted', $actor, (string) $m['uid'], ['name' => $m['filename']]);
    }

    public static function cleanName(string $n): string
    {
        $n = basename(str_replace('\\', '/', $n));
        $n = (string) preg_replace('/[^A-Za-z0-9._-]+/', '-', $n);
        $n = trim($n, '.-');

        return $n === '' ? 'file' : mb_substr($n, 0, 120);
    }

    private static function reencode(string $src, string $dest, string $mime): bool
    {
        if (! function_exists('imagecreatefromstring')) {
            return false;
        }
        $img = @imagecreatefromstring((string) file_get_contents($src));
        if ($img === false) {
            return false;
        }
        $ok = match ($mime) {
            'image/png' => (imagesavealpha($img, true) && imagepng($img, $dest, 7)),
            'image/webp' => function_exists('imagewebp') && imagewebp($img, $dest, 85),
            'image/gif' => imagegif($img, $dest),
            default => imagejpeg($img, $dest, 86),
        };
        imagedestroy($img);

        return $ok;
    }
}
