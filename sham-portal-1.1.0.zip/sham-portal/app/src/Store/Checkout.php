<?php

declare(strict_types=1);

namespace Sham\Store;

use Sham\Audit;
use Sham\Config;
use Sham\Db;
use Sham\Licensing\Issuer;
use Sham\Payments\Gateway;
use Sham\Payments\PaymentUnavailable;
use Sham\Payments\Registry;
use Sham\Security\Guard;

/** Creates an order from the buy form and opens the payment provider's checkout. */
final class Checkout
{
    /**
     * @param  array<string, mixed>  $in  edition, term, currency, provider, domains (list), name, email, country, tax_id, phone, renews, accept_terms
     * @return array{order: array<string, mixed>, url: string|null}
     *
     * @throws CheckoutError
     */
    public static function create(array $product, array $in, string $ip): array
    {
        $errors = [];
        $renews = null;
        $email = mb_strtolower(trim((string) ($in['email'] ?? '')));
        if (! filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
            $errors['email'] = 'Enter a valid e-mail address.';
        }
        $name = str_limit((string) preg_replace('/\s+/u', ' ', strip_tags((string) ($in['name'] ?? ''))), 160);
        if (mb_strlen($name) < 2) {
            $errors['name'] = 'Enter the licensee name (your organisation).';
        }
        if (! empty($in['renews'])) {
            $renews = Db::one('SELECT * FROM licences WHERE id = ? AND product_id = ?', [(string) $in['renews'], (int) $product['id']]);
            if ($renews === null || $renews['customer_email'] !== $email || $renews['status'] !== 'active') {
                throw new CheckoutError(['renews' => 'That licence cannot be renewed with this e-mail address.']);
            }
        }
        $editionKey = $renews !== null ? (string) $renews['edition'] : (string) ($in['edition'] ?? '');
        $edition = Catalogue::edition((int) $product['id'], $editionKey);
        if ($edition === null || ! Catalogue::sellable($edition)) {
            throw new CheckoutError(['edition' => 'Choose an edition that is sold online. Larger editions are sold on quotation.']);
        }
        $term = $renews !== null ? ($renews['term'] === 'perpetual' ? 'perpetual' : 'year') : (string) ($in['term'] ?? 'year');
        if (! in_array($term, ['year', 'perpetual'], true)) {
            $errors['term'] = 'Choose yearly or perpetual.';
        }
        $currency = strtoupper((string) ($in['currency'] ?? 'USD'));
        if (! in_array($currency, Catalogue::currencies(), true)) {
            $errors['currency'] = 'That currency is not available.';
        }
        $domains = $renews !== null ? json_in((string) $renews['domains_json']) : Issuer::normaliseDomains((array) ($in['domains'] ?? []));
        $max = max(1, (int) $edition['max_domains']);
        if ($domains === [] || count($domains) > $max) {
            $errors['domains'] = "Give between 1 and {$max} domain names (for example news.example.com).";
        }
        $country = strtoupper(trim((string) ($in['country'] ?? '')));
        $country = preg_match('/^[A-Z]{2}$/', $country) === 1 ? $country : null;
        if (empty($in['accept_terms'])) {
            $errors['accept_terms'] = 'Please accept the licence agreement and the terms of sale.';
        }
        $providerKey = (string) ($in['provider'] ?? '');
        $rails = array_map(fn (Gateway $g) => $g->key(), Registry::forCurrency($currency));
        if ($providerKey === '' && count($rails) > 0) {
            $providerKey = $rails[0];
        }
        if (! in_array($providerKey, $rails, true)) {
            $errors['provider'] = "Choose a payment method available for {$currency}.";
        }
        if ($errors !== []) {
            throw new CheckoutError($errors);
        }
        $net = Catalogue::price($edition, $term, $currency, $renews !== null && $term === 'perpetual');
        if ($net === null || $net <= 0) {
            throw new CheckoutError(['currency' => 'This edition has no price in '.$currency.'.']);
        }
        $vat = Catalogue::vat($net, $country);
        $gateway = Registry::get($providerKey);
        $order = [
            'id' => ulid(), 'ref' => token(16), 'product_id' => (int) $product['id'], 'edition' => $editionKey, 'term' => $term,
            'domains_json' => json_out($domains), 'customer_name' => $name, 'customer_email' => $email, 'customer_country' => $country,
            'company_tax_id' => ($t = str_limit((string) ($in['tax_id'] ?? ''), 40)) !== '' ? $t : null,
            'currency' => $currency, 'net_minor' => $net, 'vat_minor' => $vat, 'total_minor' => $net + $vat, 'provider' => $providerKey,
            'status' => 'pending', 'test_mode' => $gateway->testMode() ? 1 : 0, 'renews_licence_id' => $renews['id'] ?? null,
            'ip_hash' => Guard::ipHash($ip), 'created_at' => now_utc(),
        ];
        Db::insert('orders', $order);
        Audit::log('order.created', 'buyer', $order['id'], ['product' => $product['slug'], 'edition' => $editionKey, 'term' => $term, 'currency' => $currency,
            'total' => $order['total_minor'], 'provider' => $providerKey, 'renews' => $order['renews_licence_id']]);

        $store = Config::url('store');
        $title = $product['name'].' '.$edition['label'].' ('.($term === 'perpetual' ? ($renews !== null ? 'update year' : 'perpetual') : '1 year').')';
        try {
            $start = $gateway->start($order, [
                'return_url' => $store.'/order/'.$order['ref'], 'cancel_url' => $store.'/order/'.$order['ref'].'?cancelled=1',
                'notify_url' => $store.'/webhooks/'.$providerKey, 'title' => $title, 'phone' => isset($in['phone']) ? (string) $in['phone'] : null,
            ]);
        } catch (\InvalidArgumentException $e) {
            Db::update('orders', ['status' => 'failed', 'failure_reason' => mb_substr($e->getMessage(), 0, 250)], ['id' => $order['id']]);
            throw new CheckoutError(['phone' => $e->getMessage()]);
        } catch (PaymentUnavailable|\Throwable $e) {
            error_log('sham checkout '.$providerKey.': '.$e->getMessage());
            Db::update('orders', ['status' => 'failed', 'failure_reason' => 'Checkout could not be started.'], ['id' => $order['id']]);
            throw new CheckoutError(['provider' => 'The payment page could not be opened. Please try again, or choose another payment method.']);
        }
        Db::update('orders', ['provider_session' => $start['session'], 'checkout_url' => $start['url']], ['id' => $order['id']]);
        $order['provider_session'] = $start['session'];
        $order['checkout_url'] = $start['url'];
        if ($start['instructions'] !== null) {
            Notifier::bankInstructions($order, $product, $edition);
        }

        return ['order' => $order, 'url' => $start['url']];
    }
}
