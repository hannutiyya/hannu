<?php

declare(strict_types=1);

namespace Sham\Store;

use Sham\Audit;
use Sham\Config;
use Sham\Db;
use Sham\Mailer;
use Sham\Settings;

/** The e-mails the store sends. Plain text, in English. */
final class Notifier
{
    public static function fulfilled(string $orderId): void
    {
        $o = Db::one('SELECT * FROM orders WHERE id = ?', [$orderId]);
        if ($o === null) {
            return;
        }
        $p = (array) Db::one('SELECT * FROM products WHERE id = ?', [(int) $o['product_id']]);
        $e = Db::one('SELECT * FROM editions WHERE product_id = ? AND ekey = ?', [(int) $o['product_id'], (string) $o['edition']]);
        $label = (string) ($e['label'] ?? $o['edition']);
        $support = Settings::get('company.support_email');
        $company = Settings::get('company.name');
        $orderUrl = Config::url('store', '/order/'.$o['ref']);
        $receipt = "Receipt: {$o['receipt_number']}\nAmount paid: ".money((int) $o['total_minor'], (string) $o['currency'])
            .((int) $o['vat_minor'] > 0 ? ' (including VAT '.money((int) $o['vat_minor'], (string) $o['currency']).')' : '')."\n";
        if ($o['licence_id'] !== null) {
            $l = (array) Db::one('SELECT * FROM licences WHERE id = ?', [$o['licence_id']]);
            $body = "Dear {$o['customer_name']},\n\nThank you for choosing {$p['name']}. Your {$label} licence is "
                .($o['renews_licence_id'] !== null ? 'renewed' : 'ready').".\n\n"
                ."Licence ID: {$l['id']}\nDomains: ".implode(', ', json_in((string) $l['domains_json']))."\n"
                .'Valid until: '.($l['expires_at'] !== null ? date_human((string) $l['expires_at']) : 'perpetual')."\n"
                .'Updates until: '.date_human((string) $l['updates_until'])."\n".$receipt
                .($o['renews_licence_id'] !== null
                    ? "\nYour installation picks up the renewed key at its next daily check-in. You can also paste the key below in Administration → Licence.\n"
                    : "\nPaste this licence key in the installer, or in Administration → Licence:\n")
                ."\n{$l['token']}\n\n"
                ."Keep this e-mail. The key works on the domains above and on one installation at a time. To move servers, write to {$support}.\n"
                ."Your order and receipt: {$orderUrl}\n\n— {$company}\n".Config::url('company')." · {$support}\n";
            $subject = "Your {$p['name']} {$label} licence key";
        } else {
            $body = "Dear {$o['customer_name']},\n\nThank you for your order of {$p['name']} {$label}. We have received your payment and our team "
                ."will contact you within one working day to deliver it.\n\n{$receipt}Your order and receipt: {$orderUrl}\n\n— {$company}\n{$support}\n";
            $subject = "Your {$p['name']} order";
        }
        Mailer::send((string) $o['customer_email'], $subject, $body, $support);
        Audit::log('order.delivered', 'system', $orderId, ['licence' => $o['licence_id']]);
        self::staff('New sale: '.$p['name'].' '.$label, "Order {$o['id']} from {$o['customer_name']} <{$o['customer_email']}>, "
            .money((int) $o['total_minor'], (string) $o['currency'])." via {$o['provider']}. Receipt {$o['receipt_number']}.");
    }

    public static function bankInstructions(array $order, array $product, array $edition): void
    {
        $lines = '';
        foreach (\Sham\Payments\BankTransfer::instructions($order) as $k => $v) {
            $lines .= "{$k}: {$v}\n";
        }
        $body = "Dear {$order['customer_name']},\n\nThank you for ordering {$product['name']} {$edition['label']}. Please pay by bank transfer:\n\n{$lines}\n"
            ."Use the payment reference so we can match your transfer. Your licence key is e-mailed as soon as the money arrives (usually one working day).\n"
            .'Order status: '.Config::url('store', '/order/'.$order['ref'])."\n\n— ".Settings::get('company.name')."\n";
        Mailer::send((string) $order['customer_email'], "Bank details for your {$product['name']} order", $body, Settings::get('company.sales_email'));
        self::staff('Bank transfer expected', "Order {$order['id']} ({$order['customer_name']}) will pay ".money((int) $order['total_minor'], (string) $order['currency'])
            .' by bank transfer, reference '.strtoupper(substr((string) $order['ref'], 0, 12)).'. Confirm it in the admin when it arrives.');
    }

    public static function staff(string $subject, string $text): void
    {
        $to = Settings::get('company.notify_email');
        if ($to !== '') {
            Mailer::send($to, '[Sham store] '.$subject, $text."\n\n".Config::url('store', '/admin')."\n");
        }
    }

    public static function expiring(array $l, int $days): void
    {
        $p = (array) Db::one('SELECT * FROM products WHERE id = ?', [(int) $l['product_id']]);
        $body = "Dear {$l['customer_name']},\n\nYour {$p['name']} licence {$l['id']} ends on ".date_human((string) $l['expires_at'])." ({$days} days from now).\n\n"
            .'Renew it here: '.Config::url('store', '/renew?licence='.rawurlencode((string) $l['id']))."\n"
            ."If it ends, your newsroom becomes read-only after a short grace period, while your public website and apps keep running.\n\n— "
            .Settings::get('company.name')."\n".Settings::get('company.sales_email')."\n";
        Mailer::send((string) $l['customer_email'], "Your {$p['name']} licence ends in {$days} days", $body, Settings::get('company.sales_email'));
    }
}
