<?php

declare(strict_types=1);

namespace Sham\Store;

use Sham\Db;
use Sham\Payments\Registry;
use Sham\Settings;

/** Products, editions and prices. Prices are kept in US dollars per year; birr prices use the configured rate. */
final class Catalogue
{
    /** @return list<array<string, mixed>> */
    public static function products(bool $publishedOnly = true): array
    {
        return Db::all('SELECT * FROM products'.($publishedOnly ? " WHERE status = 'published'" : '').' ORDER BY sort, name');
    }

    /** @return array<string, mixed>|null */
    public static function product(string $slug): ?array
    {
        return Db::one("SELECT * FROM products WHERE slug = ? AND status = 'published'", [$slug]);
    }

    /** @return list<array<string, mixed>> */
    public static function editions(int $productId, bool $activeOnly = true): array
    {
        return Db::all('SELECT * FROM editions WHERE product_id = ?'.($activeOnly ? ' AND active = 1' : '').' ORDER BY sort, id', [$productId]);
    }

    /** @return array<string, mixed>|null */
    public static function edition(int $productId, string $key): ?array
    {
        return Db::one('SELECT * FROM editions WHERE product_id = ? AND ekey = ? AND active = 1', [$productId, $key]);
    }

    public static function sellable(array $edition): bool
    {
        return ! (bool) $edition['quote_only'] && (int) $edition['price_usd_year'] > 0;
    }

    /** Net price in minor units, before VAT. Null when not sold in that currency. */
    public static function price(array $edition, string $term, string $currency, bool $updatesOnly = false): ?int
    {
        if (! self::sellable($edition)) {
            return null;
        }
        $usd = (int) $edition['price_usd_year'];
        $amount = $term === 'perpetual' ? $usd * max(1, (int) $edition['perpetual_multiple']) : $usd;
        if ($updatesOnly) {
            $amount = $amount * max(0, (int) Settings::get('store.update_renewal_percent', '20')) / 100;
        }
        if ($currency === 'USD') {
            return (int) round($amount * 100);
        }
        if ($currency === 'ETB') {
            $rate = Settings::float('store.etb_per_usd');

            return $rate > 0 ? (int) round($amount * $rate) * 100 : null;
        }

        return null;
    }

    public static function vat(int $net, ?string $country): int
    {
        $countries = array_map('trim', explode(',', strtoupper(Settings::get('store.vat_countries'))));

        return $country !== null && in_array($country, $countries, true) ? (int) round($net * Settings::float('store.vat_percent') / 100) : 0;
    }

    /** @return list<string> */
    public static function currencies(): array
    {
        $c = Registry::currencies();
        if (Settings::float('store.etb_per_usd') <= 0) {
            $c = array_values(array_diff($c, ['ETB']));
        }

        return $c;
    }
}
