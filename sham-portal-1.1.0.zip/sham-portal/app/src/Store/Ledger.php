<?php

declare(strict_types=1);

namespace Sham\Store;

use Sham\Audit;
use Sham\Db;
use Sham\Licensing\Issuer;
use Sham\Payments\Registry;

/**
 * Applies a charge, as the provider's API reported it, to an order: credits it only when amount and currency match
 * exactly, then fulfils it once (licence issued or renewed and e-mailed). Idempotent: concurrent webhooks, return pages
 * and the cron all go through the row lock.
 */
final class Ledger
{
    /** Re-read the order at its provider and apply the result. Returns the order's new status. */
    public static function refresh(string $orderId): string
    {
        $order = Db::one('SELECT * FROM orders WHERE id = ?', [$orderId]);
        if ($order === null) {
            return 'missing';
        }
        if (! in_array($order['status'], ['pending', 'failed', 'cancelled', 'paid', 'fulfilled'], true)) {
            return (string) $order['status'];
        }
        $g = Registry::get((string) $order['provider']);
        if ($g === null) {
            return (string) $order['status'];
        }
        try {
            $charge = $g->fetch($order);
        } catch (\Throwable $e) {
            error_log('sham ledger fetch '.$order['provider'].': '.$e->getMessage());

            return (string) $order['status'];
        }
        Db::update('orders', ['checked_at' => now_utc()], ['id' => $orderId]);
        if ($charge === null) {
            return (string) $order['status'];
        }

        return self::apply($orderId, $charge, 'provider:'.$order['provider']);
    }

    /** @param array{status: string, amount_minor: int, currency: string, reference: string|null} $charge */
    public static function apply(string $orderId, array $charge, string $actor): string
    {
        $mail = null;
        $status = Db::tx(function () use ($orderId, $charge, $actor, &$mail): string {
            $o = Db::one('SELECT * FROM orders WHERE id = ? FOR UPDATE', [$orderId]) ?? throw new \RuntimeException('order missing');
            $st = (string) $o['status'];
            switch ($charge['status']) {
                case 'succeeded':
                    if (in_array($st, ['paid', 'fulfilled', 'refunded', 'review'], true)) {
                        return $st;
                    }
                    if ($charge['amount_minor'] !== (int) $o['total_minor'] || strtoupper($charge['currency']) !== $o['currency']) {
                        Db::update('orders', ['status' => 'review', 'failure_reason' => 'Paid '.money($charge['amount_minor'], strtoupper($charge['currency'])).' but the order is '
                            .money((int) $o['total_minor'], (string) $o['currency']).'.', 'provider_reference' => $charge['reference']], ['id' => $orderId]);
                        Audit::log('order.amount_mismatch', $actor, $orderId, ['paid' => $charge['amount_minor'], 'currency' => $charge['currency']]);
                        $mail = ['review', $orderId];

                        return 'review';
                    }
                    Db::update('orders', ['status' => 'paid', 'paid_at' => now_utc(), 'provider_reference' => $charge['reference'],
                        'receipt_number' => self::receiptNumber(), 'failure_reason' => null], ['id' => $orderId]);
                    Audit::log('order.paid', $actor, $orderId, ['reference' => $charge['reference']]);
                    $licenceId = self::fulfil($orderId);
                    $mail = ['fulfilled', $orderId, $licenceId];

                    return 'fulfilled';
                case 'failed':
                case 'cancelled':
                    if ($st === 'pending') {
                        Db::update('orders', ['status' => $charge['status'] === 'failed' ? 'failed' : 'cancelled'], ['id' => $orderId]);

                        return $charge['status'] === 'failed' ? 'failed' : 'cancelled';
                    }

                    return $st;
                case 'refunded':
                    if (in_array($st, ['paid', 'fulfilled'], true)) {
                        Db::update('orders', ['status' => 'refunded'], ['id' => $orderId]);
                        if ($o['licence_id'] !== null && $o['renews_licence_id'] === null) {
                            Db::update('licences', ['status' => 'revoked', 'revoked_reason' => 'The payment for this licence was refunded.'], ['id' => $o['licence_id']]);
                        }
                        Audit::log('order.refunded', $actor, $orderId, ['licence' => $o['licence_id']]);

                        return 'refunded';
                    }

                    return $st;
                default:
                    return $st;
            }
        });
        if ($mail !== null && $mail[0] === 'fulfilled') {
            Notifier::fulfilled($mail[1]);
        } elseif ($mail !== null && $mail[0] === 'review') {
            Notifier::staff('Order needs review', "Order {$mail[1]} was paid with a different amount or currency. Check it in the admin.");
        }

        return $status;
    }

    /** Staff confirmed a bank transfer (or another manual credit). */
    public static function markPaidByStaff(string $orderId, string $reference, string $staff): string
    {
        $o = Db::one('SELECT * FROM orders WHERE id = ?', [$orderId]);
        if ($o === null) {
            return 'missing';
        }

        return self::apply($orderId, ['status' => 'succeeded', 'amount_minor' => (int) $o['total_minor'], 'currency' => (string) $o['currency'],
            'reference' => mb_substr($reference, 0, 190)], 'admin:'.$staff);
    }

    /** Inside the order lock: issue or renew the licence (licence products) and mark the order fulfilled. */
    private static function fulfil(string $orderId): ?string
    {
        $o = (array) Db::one('SELECT * FROM orders WHERE id = ?', [$orderId]);
        $product = (array) Db::one('SELECT * FROM products WHERE id = ?', [(int) $o['product_id']]);
        $licenceId = null;
        if ($product['licence_kind'] === 'mediaos') {
            if ($o['renews_licence_id'] !== null) {
                $l = Issuer::extend((string) $o['renews_licence_id'], $o['term'] === 'perpetual' ? 0 : 12, 12, 'order:'.$orderId);
                $licenceId = (string) $l['id'];
            } else {
                $l = Issuer::issue((int) $o['product_id'], ['name' => (string) $o['customer_name'], 'email' => (string) $o['customer_email'],
                    'country' => $o['customer_country']], (string) $o['edition'], (string) $o['term'], json_in((string) $o['domains_json']), notes: 'Store order '.$orderId,
                    actor: 'order:'.$orderId);
                $licenceId = (string) $l['id'];
            }
        }
        Db::update('orders', ['status' => 'fulfilled', 'fulfilled_at' => now_utc(), 'licence_id' => $licenceId], ['id' => $orderId]);

        return $licenceId;
    }

    private static function receiptNumber(): string
    {
        Db::run('INSERT INTO counters (name, value) VALUES (?, 1) ON DUPLICATE KEY UPDATE value = LAST_INSERT_ID(value + 1)', ['receipt.'.gmdate('Y')]);
        $n = (int) Db::value('SELECT value FROM counters WHERE name = ?', ['receipt.'.gmdate('Y')]);

        return 'SH-'.gmdate('Y').'-'.str_pad((string) $n, 5, '0', STR_PAD_LEFT);
    }
}
