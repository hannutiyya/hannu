<?php

declare(strict_types=1);

namespace Sham;

use PDO;

/**
 * Database upgrades. app/schema.sql is the first version ("001"); every later change is a file in app/migrations
 * named NNN_name.php that returns function (PDO $pdo): void. Applied versions are recorded in schema_migrations, so an
 * upgrade is: upload the new files, and the next request (or the installer, or the cron job) applies what is missing.
 * Steps are written to be safe to repeat (they check before they add), because MySQL cannot roll back table changes.
 */
final class Migrator
{
    /** @return list<string> versions in app/migrations, in order */
    public static function available(): array
    {
        $v = ['001'];
        foreach (glob(SHAM_APP.'/migrations/*.php') ?: [] as $f) {
            if (preg_match('/^(\d{3})_[a-z0-9_]+\.php$/', basename($f), $m) === 1) {
                $v[] = $m[1];
            }
        }
        sort($v);

        return array_values(array_unique($v));
    }

    /** @return list<string> */
    public static function applied(PDO $pdo): array
    {
        self::ensureTable($pdo);

        return array_map('strval', $pdo->query('SELECT version FROM schema_migrations ORDER BY version')->fetchAll(PDO::FETCH_COLUMN));
    }

    /** @return list<string> */
    public static function pending(PDO $pdo): array
    {
        return array_values(array_diff(self::available(), self::applied($pdo)));
    }

    /**
     * Applies everything that is missing. A named lock stops two requests from upgrading at once.
     *
     * @return list<string> the versions applied now
     */
    public static function run(PDO $pdo): array
    {
        self::ensureTable($pdo);
        if ((int) $pdo->query("SELECT GET_LOCK('sham_portal_migrate', 30)")->fetchColumn() !== 1) {
            return [];
        }
        $done = [];
        try {
            foreach (self::pending($pdo) as $version) {
                if ($version === '001') {
                    self::base($pdo);
                } else {
                    $files = glob(SHAM_APP.'/migrations/'.$version.'_*.php') ?: [];
                    $step = require $files[0];
                    $step($pdo);
                }
                $st = $pdo->prepare('INSERT INTO schema_migrations (version, applied_at) VALUES (?, UTC_TIMESTAMP())');
                $st->execute([$version]);
                $done[] = $version;
            }
        } finally {
            $pdo->query("SELECT RELEASE_LOCK('sham_portal_migrate')");
        }

        return $done;
    }

    /** True when the code expects tables the database does not have yet (an upload of new files). */
    public static function behind(PDO $pdo): bool
    {
        return self::pending($pdo) !== [];
    }

    private static function ensureTable(PDO $pdo): void
    {
        $pdo->exec('CREATE TABLE IF NOT EXISTS schema_migrations (version VARCHAR(20) NOT NULL PRIMARY KEY, applied_at DATETIME NOT NULL)
            ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }

    private static function base(PDO $pdo): void
    {
        $sql = (string) file_get_contents(SHAM_APP.'/schema.sql');
        $sql = (string) preg_replace('/^--.*$/m', '', $sql);
        foreach (array_filter(array_map('trim', explode(";\n", $sql))) as $stmt) {
            $pdo->exec($stmt);
        }
    }

    // Helpers for migration files ----------------------------------------------------------------------------------

    public static function hasColumn(PDO $pdo, string $table, string $column): bool
    {
        $st = $pdo->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?');
        $st->execute([$table, $column]);

        return (int) $st->fetchColumn() > 0;
    }

    public static function addColumn(PDO $pdo, string $table, string $column, string $definition): void
    {
        if (preg_match('/^[a-z_]+$/', $table.$column) !== 1) {
            throw new \InvalidArgumentException('bad identifier');
        }
        if (! self::hasColumn($pdo, $table, $column)) {
            $pdo->exec("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
        }
    }

    public static function hasIndex(PDO $pdo, string $table, string $index): bool
    {
        $st = $pdo->prepare('SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?');
        $st->execute([$table, $index]);

        return (int) $st->fetchColumn() > 0;
    }
}
