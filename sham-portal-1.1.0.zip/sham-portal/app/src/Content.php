<?php

declare(strict_types=1);

namespace Sham;

/** Queries for news, product sub-pages and releases, shared by the public sites, the store account and the update API. */
final class Content
{
    public const POST_KINDS = ['news' => 'News', 'update' => 'Product update', 'announcement' => 'Announcement', 'story' => 'Customer story', 'event' => 'Event'];

    private const LIVE = "p.status = 'published' AND p.published_at <= UTC_TIMESTAMP()";

    /** @return array{rows: list<array<string, mixed>>, pages: int} */
    public static function posts(?int $productId, int $page = 1, int $per = 12, ?string $kind = null): array
    {
        $where = [self::LIVE];
        $args = [];
        if ($productId !== null) {
            $where[] = 'p.product_id = ?';
            $args[] = $productId;
        }
        if ($kind !== null && isset(self::POST_KINDS[$kind])) {
            $where[] = 'p.kind = ?';
            $args[] = $kind;
        }
        $w = implode(' AND ', $where);
        $total = (int) Db::value("SELECT COUNT(*) FROM posts p WHERE {$w}", $args);
        $page = max(1, $page);
        $off = ($page - 1) * $per;
        $rows = Db::all("SELECT p.*, pr.name AS product_name, pr.slug AS product_slug, pr.host AS product_host, pr.accent AS product_accent,
            m.uid AS cover_uid, m.filename AS cover_filename, m.alt AS cover_alt
            FROM posts p LEFT JOIN products pr ON pr.id = p.product_id LEFT JOIN media m ON m.id = p.cover_media_id
            WHERE {$w} ORDER BY p.published_at DESC, p.id DESC LIMIT {$per} OFFSET {$off}", $args);

        return ['rows' => $rows, 'pages' => max(1, (int) ceil($total / $per))];
    }

    /** @return array<string, mixed>|null */
    public static function post(string $slug, ?int $productId = null): ?array
    {
        $p = Db::one('SELECT p.*, pr.name AS product_name, pr.slug AS product_slug, pr.host AS product_host, m.uid AS cover_uid, m.filename AS cover_filename, m.alt AS cover_alt
            FROM posts p LEFT JOIN products pr ON pr.id = p.product_id LEFT JOIN media m ON m.id = p.cover_media_id WHERE p.slug = ? AND '.self::LIVE, [$slug]);
        if ($p === null || ($productId !== null && (int) $p['product_id'] !== $productId)) {
            return null;
        }

        return $p;
    }

    /** @return list<array<string, mixed>> */
    public static function productPages(int $productId, bool $navOnly = false): array
    {
        return Db::all("SELECT id, slug, title, in_nav, sort FROM product_pages WHERE product_id = ? AND status = 'published'".($navOnly ? ' AND in_nav = 1' : '').' ORDER BY sort, title', [$productId]);
    }

    /** @return array<string, mixed>|null */
    public static function productPage(int $productId, string $slug): ?array
    {
        return Db::one("SELECT * FROM product_pages WHERE product_id = ? AND slug = ? AND status = 'published'", [$productId, $slug]);
    }

    /** @return list<array<string, mixed>> published releases, newest first */
    public static function releases(int $productId, ?string $channel = null, int $limit = 50): array
    {
        $args = [$productId];
        $ch = '';
        if ($channel !== null) {
            $ch = ' AND channel = ?';
            $args[] = $channel;
        }

        return Db::all("SELECT * FROM releases WHERE product_id = ? AND status = 'published' AND released_at <= UTC_TIMESTAMP(){$ch} ORDER BY released_at DESC, id DESC LIMIT ".max(1, $limit), $args);
    }

    /** @return array<string, mixed>|null */
    public static function latest(int $productId, string $channel = 'stable'): ?array
    {
        $channels = $channel === 'beta' ? ['stable', 'beta'] : ['stable'];
        $rows = array_filter(self::releases($productId), fn ($r) => in_array($r['channel'], $channels, true));
        usort($rows, fn ($a, $b) => version_compare((string) $b['version'], (string) $a['version']));

        return $rows[0] ?? null;
    }

    /** Whether a licence may download a release: active, same product, not expired, and the release within its update period. */
    public static function entitled(array $release, ?array $licence): bool
    {
        if ($release['status'] !== 'published') {
            return false;
        }
        if ($release['access'] === 'public') {
            return true;
        }
        if ($licence === null || $licence['status'] !== 'active' || (int) $licence['product_id'] !== (int) $release['product_id']) {
            return false;
        }
        $now = time();
        if ($licence['expires_at'] !== null && strtotime($licence['expires_at'].' UTC') < $now) {
            return false;
        }

        return $licence['updates_until'] === null || strtotime((string) $release['released_at'].' UTC') <= strtotime($licence['updates_until'].' UTC');
    }

    /** A signed, short-lived download link for one release and licence. */
    public static function downloadToken(int $releaseId, ?string $licenceId, int $ttl = 3600): string
    {
        $p = b64url(json_out(['r' => $releaseId, 'l' => $licenceId, 'e' => time() + $ttl]));

        return $p.'.'.b64url(substr(hash_hmac('sha256', $p, Config::key('download'), true), 0, 20));
    }

    /** @return array{r: int, l: ?string}|null */
    public static function readDownloadToken(string $t): ?array
    {
        [$p, $sig] = array_pad(explode('.', $t, 2), 2, '');
        if ($p === '' || ! hash_equals(b64url(substr(hash_hmac('sha256', $p, Config::key('download'), true), 0, 20)), $sig)) {
            return null;
        }
        $d = json_in(unb64url($p));
        if (! is_int($d['r'] ?? null) || ! is_int($d['e'] ?? null) || $d['e'] < time()) {
            return null;
        }

        return ['r' => $d['r'], 'l' => is_string($d['l'] ?? null) ? $d['l'] : null];
    }

    public static function productUrl(array $p, string $path = '/'): string
    {
        return ($p['host'] ?? '') !== '' ? Config::get('scheme', 'https').'://'.$p['host'].$path : Config::url('company', '/products/'.$p['slug'].($path === '/' ? '' : $path));
    }

    public static function postUrl(array $post): string
    {
        if (($post['product_host'] ?? '') !== '') {
            return Config::get('scheme', 'https').'://'.$post['product_host'].'/news/'.$post['slug'];
        }

        return Config::url('company', '/news/'.$post['slug']);
    }

    public static function slugify(string $s): string
    {
        $s = mb_strtolower(trim($s));
        $s = (string) preg_replace('/[^\p{L}\p{N}]+/u', '-', $s);
        $s = trim($s, '-');
        $s = (string) preg_replace('/[^a-z0-9-]/', '', (string) (function_exists('transliterator_transliterate') ? transliterator_transliterate('Any-Latin; Latin-ASCII', $s) : $s));

        return $s !== '' ? mb_substr(trim((string) preg_replace('/-+/', '-', $s), '-'), 0, 100) : 'post-'.date('Ymd-His');
    }
}
