<?php

declare(strict_types=1);

namespace Sham;

/**
 * A small, safe Markdown subset for pages edited in the admin: #–#### headings, paragraphs, - / * and 1. lists,
 * > quotes, ---, **bold**, *italic*, `code`, [links](https://…) and ![images](/media/…) from the media library. All text is escaped first; raw HTML is never passed
 * through, and links accept only http(s), mailto and site-relative targets.
 */
final class Markdown
{
    public static function render(string $md): string
    {
        $lines = preg_split('/\r\n|\r|\n/', $md) ?: [];
        $html = '';
        $para = [];
        $list = null;
        $flushPara = function () use (&$para, &$html): void {
            if ($para !== []) {
                $html .= '<p>'.self::inline(implode(' ', $para)).'</p>';
                $para = [];
            }
        };
        $closeList = function () use (&$list, &$html): void {
            if ($list !== null) {
                $html .= "</{$list}>";
                $list = null;
            }
        };
        foreach ($lines as $line) {
            $t = rtrim($line);
            if (trim($t) === '') {
                $flushPara();
                $closeList();

                continue;
            }
            if (preg_match('/^(#{1,4})\s+(.*)$/', $t, $m) === 1) {
                $flushPara();
                $closeList();
                $lvl = strlen($m[1]) + 1;
                $lvl = min($lvl, 5);
                $html .= "<h{$lvl} id=\"".e(self::slug($m[2])).'">'.self::inline($m[2])."</h{$lvl}>";

                continue;
            }
            if (preg_match('/^\s*(-{3,}|\*{3,})\s*$/', $t) === 1) {
                $flushPara();
                $closeList();
                $html .= '<hr>';

                continue;
            }
            $type = null;
            if (preg_match('/^\s*[-*]\s+(.*)$/', $t, $m) === 1) {
                $type = 'ul';
            } elseif (preg_match('/^\s*\d+[.)]\s+(.*)$/', $t, $m) === 1) {
                $type = 'ol';
            }
            if ($type !== null) {
                $flushPara();
                $text = $m[1];
                if ($list !== $type) {
                    $closeList();
                    $html .= "<{$type}>";
                    $list = $type;
                }
                $html .= '<li>'.self::inline($text).'</li>';

                continue;
            }
            if (preg_match('/^>\s?(.*)$/', $t, $m) === 1) {
                $flushPara();
                $closeList();
                $html .= '<blockquote><p>'.self::inline($m[1]).'</p></blockquote>';

                continue;
            }
            if ($list !== null && preg_match('/^\s{2,}(.*)$/', $line, $m) === 1) {
                // continuation of a list item
                $html = (string) preg_replace('/<\/li>$/', ' '.self::inline($m[1]).'</li>', $html);

                continue;
            }
            $closeList();
            $para[] = trim($t);
        }
        $flushPara();
        $closeList();

        return $html;
    }

    public static function inline(string $s): string
    {
        $s = e($s);
        // Code, images and links are set aside first, so that emphasis never reaches inside an address.
        $keep = [];
        $hold = function (string $html) use (&$keep): string {
            $keep[] = $html;

            return "\x01".(count($keep) - 1)."\x01";
        };
        $s = (string) preg_replace_callback('/`([^`]+)`/', fn ($m) => $hold('<code>'.$m[1].'</code>'), $s);
        // Images only from this site's media library (/media/…) or the site's own assets.
        $s = (string) preg_replace_callback('/!\[([^\]]*)\]\(([^)\s]+)\)/', function ($m) use ($hold) {
            $src = html_entity_decode($m[2], ENT_QUOTES | ENT_HTML5);
            if (preg_match('#^/(media|assets)/[A-Za-z0-9._/-]+$#', $src) !== 1 || str_contains($src, '..')) {
                return $m[1];
            }

            return $hold('<img src="'.e($src).'" alt="'.$m[1].'" loading="lazy" decoding="async">');
        }, $s);
        $s = (string) preg_replace_callback('/\[([^\]]+)\]\(([^)\s]+)\)/', function ($m) use ($hold) {
            $href = html_entity_decode($m[2], ENT_QUOTES | ENT_HTML5);
            if (preg_match('#^(https?://|mailto:|/(?!/)|\#)#i', $href) !== 1) {
                return $m[1];
            }
            $ext = preg_match('#^https?://#i', $href) === 1;

            return $hold('<a href="'.e($href).'"'.($ext ? ' rel="noopener noreferrer"' : '').'>'.self::emphasis($m[1]).'</a>');
        }, $s);
        $s = self::emphasis($s);

        return (string) preg_replace_callback("/\x01(\\d+)\x01/", fn ($m) => $keep[(int) $m[1]] ?? '', $s);
    }

    private static function emphasis(string $s): string
    {
        $s = (string) preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $s);
        $s = (string) preg_replace('/(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])/', '<em>$1</em>', $s);

        return (string) preg_replace('/(?<![\w])_(?!\s)(.+?)(?<!\s)_(?![\w])/', '<em>$1</em>', $s);
    }

    public static function slug(string $s): string
    {
        return trim((string) preg_replace('/[^a-z0-9]+/', '-', strtolower(strip_tags($s))), '-');
    }
}
