<?php

declare(strict_types=1);

namespace Sham\Security;

use Sham\Config;
use Sham\Db;

/**
 * Sessions stored in MySQL (not the shared host's /tmp), keyed by a hash of the session id. Cookie: HttpOnly, Secure,
 * SameSite=Lax, host-only (__Host- prefix in production). Idle timeout 30 minutes for admins, 2 hours otherwise;
 * absolute lifetime 12 hours. The id is regenerated at sign-in and at every privilege change.
 */
final class Session implements \SessionHandlerInterface
{
    private static bool $started = false;

    public static function start(): void
    {
        if (self::$started || PHP_SAPI === 'cli') {
            self::$started = true;
            if (PHP_SAPI === 'cli' && ! isset($_SESSION)) {
                $_SESSION = [];
            }

            return;
        }
        $secure = (bool) Config::get('secure_cookies', true);
        session_set_save_handler(new self(), true);
        session_name($secure ? '__Host-sham' : 'sham_session');
        session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.sid_length', '48');
        ini_set('session.sid_bits_per_character', '6');
        ini_set('session.gc_maxlifetime', '43200');
        session_start();
        self::$started = true;
        $now = time();
        $created = (int) ($_SESSION['_created'] ?? 0);
        $seen = (int) ($_SESSION['_seen'] ?? 0);
        $idle = isset($_SESSION['admin_id']) ? 1800 : 7200;
        if ($created === 0 || $now - $created > 43200 || ($seen > 0 && $now - $seen > $idle)) {
            $_SESSION = ['_created' => $now];
            session_regenerate_id(true);
        }
        $_SESSION['_seen'] = $now;
    }

    public static function regenerate(): void
    {
        if (PHP_SAPI !== 'cli' && session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
        $_SESSION['_created'] = time();
        unset($_SESSION['_csrf']);
    }

    public static function forget(): void
    {
        $_SESSION = [];
        if (PHP_SAPI !== 'cli' && session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
    }

    public static function flash(string $msg, string $kind = 'ok'): void
    {
        $_SESSION['_flash'][] = ['kind' => $kind, 'msg' => $msg];
    }

    /** @return list<array{kind: string, msg: string}> */
    public static function takeFlash(): array
    {
        $f = $_SESSION['_flash'] ?? [];
        unset($_SESSION['_flash']);

        return is_array($f) ? array_values($f) : [];
    }

    // SessionHandlerInterface -------------------------------------------------------------------------------------

    public function open(string $path, string $name): bool
    {
        return true;
    }

    public function close(): bool
    {
        return true;
    }

    public function read(string $id): string|false
    {
        $row = Db::one('SELECT data FROM sessions WHERE id = ? AND updated_at > (UTC_TIMESTAMP() - INTERVAL 12 HOUR)', [hash('sha256', $id)]);

        return $row === null ? '' : (string) $row['data'];
    }

    public function write(string $id, string $data): bool
    {
        Db::run('INSERT INTO sessions (id, data, updated_at) VALUES (?, ?, UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE data = VALUES(data), updated_at = VALUES(updated_at)',
            [hash('sha256', $id), $data]);

        return true;
    }

    public function destroy(string $id): bool
    {
        Db::run('DELETE FROM sessions WHERE id = ?', [hash('sha256', $id)]);

        return true;
    }

    public function gc(int $max_lifetime): int|false
    {
        return Db::run('DELETE FROM sessions WHERE updated_at < (UTC_TIMESTAMP() - INTERVAL 12 HOUR)')->rowCount();
    }
}
