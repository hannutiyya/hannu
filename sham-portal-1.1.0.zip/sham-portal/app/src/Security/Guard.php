<?php

declare(strict_types=1);

namespace Sham\Security;

use Sham\Config;
use Sham\Db;

/** CSRF tokens, rate limits, secret encryption and password hashing. */
final class Guard
{
    // CSRF ----------------------------------------------------------------------------------------------------------

    public static function csrf(): string
    {
        if (! is_string($_SESSION['_csrf'] ?? null)) {
            $_SESSION['_csrf'] = bin2hex(random_bytes(32));
        }

        return $_SESSION['_csrf'];
    }

    public static function csrfField(): string
    {
        return '<input type="hidden" name="_csrf" value="'.e(self::csrf()).'">';
    }

    public static function checkCsrf(string $given): bool
    {
        $t = $_SESSION['_csrf'] ?? null;

        return is_string($t) && $given !== '' && hash_equals($t, $given);
    }

    // Rate limits (fixed window in MySQL) ---------------------------------------------------------------------------

    /** True while under the limit; counts this hit. */
    public static function hit(string $bucket, string $who, int $max, int $windowSeconds): bool
    {
        $k = hash('sha256', $bucket.'|'.$who);
        return Db::tx(function () use ($k, $max, $windowSeconds): bool {
            $row = Db::one('SELECT hits, reset_at FROM rate_limits WHERE k = ? FOR UPDATE', [$k]);
            if ($row === null || strtotime($row['reset_at'].' UTC') <= time()) {
                Db::run('REPLACE INTO rate_limits (k, hits, reset_at) VALUES (?, 1, ?)', [$k, gmdate('Y-m-d H:i:s', time() + $windowSeconds)]);

                return true;
            }
            Db::run('UPDATE rate_limits SET hits = hits + 1 WHERE k = ?', [$k]);

            return (int) $row['hits'] < $max;
        });
    }

    public static function clear(string $bucket, string $who): void
    {
        Db::run('DELETE FROM rate_limits WHERE k = ?', [hash('sha256', $bucket.'|'.$who)]);
    }

    // Secrets at rest (payment keys, SMTP password, licence signing key, TOTP secrets) ------------------------------

    public static function encrypt(string $plain): string
    {
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);

        return 'v1:'.base64_encode($nonce.sodium_crypto_secretbox($plain, $nonce, Config::key('secrets')));
    }

    public static function decrypt(?string $stored): string
    {
        if ($stored === null || $stored === '') {
            return '';
        }
        if (! str_starts_with($stored, 'v1:')) {
            return '';
        }
        $raw = base64_decode(substr($stored, 3), true);
        if ($raw === false || strlen($raw) < SODIUM_CRYPTO_SECRETBOX_NONCEBYTES + SODIUM_CRYPTO_SECRETBOX_MACBYTES) {
            return '';
        }
        $plain = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), Config::key('secrets'));

        return $plain === false ? '' : $plain;
    }

    // Passwords ------------------------------------------------------------------------------------------------------

    public static function hashPassword(string $password): string
    {
        return defined('PASSWORD_ARGON2ID') ? password_hash($password, PASSWORD_ARGON2ID) : password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    /** At least 12 characters, not all one class, and not an obvious pattern. Returns an error or null. */
    public static function weakPassword(string $password, string $email = ''): ?string
    {
        if (mb_strlen($password) < 12) {
            return 'Use at least 12 characters.';
        }
        if (mb_strlen($password) > 200) {
            return 'Use at most 200 characters.';
        }
        $classes = (int) preg_match('/[a-z]/', $password) + (int) preg_match('/[A-Z]/', $password) + (int) preg_match('/\d/', $password) + (int) preg_match('/[^A-Za-z0-9]/', $password);
        if ($classes < 3 && mb_strlen($password) < 20) {
            return 'Mix upper and lower case letters, digits and symbols, or use a passphrase of 20 characters or more.';
        }
        $lower = strtolower($password);
        foreach (['password', 'qwerty', '123456', 'sham', 'admin', 'letmein'] as $bad) {
            if (str_contains($lower, $bad)) {
                return 'Avoid common words such as "'.$bad.'".';
            }
        }
        $local = strtolower(explode('@', $email)[0] ?? '');
        if ($local !== '' && strlen($local) >= 4 && str_contains($lower, $local)) {
            return 'Do not use your e-mail address in the password.';
        }

        return null;
    }

    /** Keyed hash of an IP address for logs (never the raw address). */
    public static function ipHash(string $ip): string
    {
        return substr(hash_hmac('sha256', $ip, Config::key('ip')), 0, 32);
    }
}
