<?php

declare(strict_types=1);

namespace Sham\Security;

/** RFC 6238 TOTP (SHA-1, 6 digits, 30 s), the format every authenticator app reads. */
final class Totp
{
    private const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public static function newSecret(): string
    {
        return self::base32(random_bytes(20));
    }

    public static function uri(string $secret, string $account, string $issuer = 'Sham'): string
    {
        return 'otpauth://totp/'.rawurlencode($issuer.':'.$account).'?secret='.$secret.'&issuer='.rawurlencode($issuer).'&algorithm=SHA1&digits=6&period=30';
    }

    /**
     * Returns the matched time step (to refuse its reuse), or null. Accepts one step either side for clock drift.
     */
    public static function verify(string $secret, string $code, int $lastUsedStep = 0, ?int $now = null): ?int
    {
        $code = (string) preg_replace('/\s+/', '', $code);
        if (preg_match('/^\d{6}$/', $code) !== 1) {
            return null;
        }
        $key = self::unbase32($secret);
        if ($key === '') {
            return null;
        }
        $step = intdiv($now ?? time(), 30);
        foreach ([$step - 1, $step, $step + 1] as $s) {
            if ($s > $lastUsedStep && hash_equals(self::at($key, $s), $code)) {
                return $s;
            }
        }

        return null;
    }

    public static function at(string $key, int $step): string
    {
        $h = hash_hmac('sha1', pack('J', $step), $key, true);
        $o = ord($h[19]) & 0x0F;
        $n = ((ord($h[$o]) & 0x7F) << 24) | (ord($h[$o + 1]) << 16) | (ord($h[$o + 2]) << 8) | ord($h[$o + 3]);

        return str_pad((string) ($n % 1000000), 6, '0', STR_PAD_LEFT);
    }

    public static function base32(string $raw): string
    {
        $bits = '';
        foreach (str_split($raw) as $c) {
            $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 5) as $chunk) {
            $out .= self::ALPHABET[bindec(str_pad($chunk, 5, '0'))];
        }

        return $out;
    }

    public static function unbase32(string $s): string
    {
        $s = strtoupper((string) preg_replace('/[\s=]/', '', $s));
        $bits = '';
        foreach (str_split($s) as $c) {
            $i = strpos(self::ALPHABET, $c);
            if ($i === false) {
                return '';
            }
            $bits .= str_pad(decbin($i), 5, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 8) as $byte) {
            if (strlen($byte) === 8) {
                $out .= chr(bindec($byte));
            }
        }

        return $out;
    }
}
