title: About Sham
---
Sham Software Systems Development General Trading PLC builds and sells software for organisations in Ethiopia and beyond.

## What we make

- **Sham MediaOS**, the newsroom, website, apps and broadcast platform for media of every size, installed on the customer's own server under the customer's own name.
- **Taligaa**, our digital health products.

## How we work

We build software that runs where our customers need it: on their own servers, on slow connections, in their languages and with the payment methods their customers already use. Every product is supported by the team that built it.

## Contact

Write to sales@sham.et, or use the contact form on this site.
