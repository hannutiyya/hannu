title: Data Processing Note
---
Last updated: 7 November 2026

Sham Software Systems Development General Trading PLC

This note explains who is responsible for personal data when a customer runs Sham MediaOS. It forms part of the Sham MediaOS Software Licence Agreement.

## 1. The customer is the controller

1.1 Sham MediaOS is self-hosted. The customer installs it on servers that the customer controls or rents.

1.2 All data in an installation stays on the customer's servers. This includes readers' accounts, subscriptions, comments, newsletter lists, payments, analytics, staff accounts, sources, investigations and published content.

1.3 The customer decides why and how that data is used. The customer is therefore the controller of it, and is responsible for:

(a) having a legal basis for each use;

(b) its privacy notice and cookie notice to readers and staff;

(c) answering data subject requests (the software provides export and deletion tools for reader accounts);

(d) security of its servers, backups and encryption keys;

(e) contracts with its own service providers, such as hosting, e-mail, payment, AI or analytics services it connects; and

(f) any registration, notification or cross-border transfer requirements that apply to it.

## 2. Sham does not process that data

2.1 The software does not send the customer's content, reader data or staff data to Sham.

2.2 Sham has no access to an installation unless the customer gives it access.

2.3 Sham is therefore not a processor of the customer's readers' or staff's personal data in the normal operation of the software, and no separate data processing agreement is needed for it.

## 3. What Sham does receive: check-in metadata

3.1 Each installation checks in with licensing.sham.et once a day. A check-in contains only the licence ID, a random installation ID, the host names the installation answers on, the software version and usage counts (staff, publication editions, languages and studios). The licence server also sees the IP address of the server that checks in.

3.2 Sham uses this metadata as an independent controller, only to verify the licence, bind it to one installation, provide updates and support, and protect the software against unlicensed use. Our Privacy Policy describes how we handle it.

3.3 An air-gapped site can ask for an offline licence, which needs no check-ins.

## 4. When the customer gives Sham access for support

4.1 If the customer gives Sham access to an installation, a server, logs or a database copy so that we can provide support, Sham may see personal data. In that case Sham acts as the customer's processor, and:

(a) uses the access only to provide the support requested, following the customer's instructions;

(b) limits access to the staff who need it, under a duty of confidentiality;

(c) does not copy data from the installation unless needed for the support request, and deletes any copy when the request is closed;

(d) tells the customer without undue delay if it becomes aware of a personal data breach affecting that data; and

(e) does not use sub-processors for that data without the customer's consent.

4.2 Customers that need a signed data processing agreement for support access can ask sales@sham.et.

4.3 We recommend giving support access to a test copy with anonymised data where possible.

## 5. Contact

Sham Software Systems Development General Trading PLC, [REGISTERED ADDRESS], Addis Ababa, Ethiopia. E-mail: [PRIVACY E-MAIL] or sales@sham.et.
