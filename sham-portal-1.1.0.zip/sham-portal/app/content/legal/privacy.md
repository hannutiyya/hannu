title: Privacy Policy
---
Last updated: 7 November 2026

Sham Software Systems Development General Trading PLC

This policy explains how Sham Software Systems Development General Trading PLC ("Sham", "we", "us") handles personal data on our websites sham.et and store.sham.et and on our licence server licensing.sham.et.

It does not cover the websites, newsrooms and apps that our customers run with Sham MediaOS on their own servers. Each customer is responsible for its own readers' and staff's data. See our Data Processing Note.

## 1. Who we are

1.1 The controller of the personal data described here is Sham Software Systems Development General Trading PLC, commercial registration number [COMMERCIAL REGISTRATION NO.], TIN [TIN], [REGISTERED ADDRESS], Addis Ababa, Ethiopia.

1.2 For privacy questions, contact us at [PRIVACY E-MAIL] or sales@sham.et.

## 2. What we collect

2.1 Buyer and contact details. When you buy, ask for a quotation or contact us: your name, your organisation's name, your e-mail address, your phone number if you give it, and the content of your messages.

2.2 Billing details. Your billing country, your tax identification number (TIN or VAT number) if you give it, and your billing address if needed for an invoice.

2.3 Order details. The Product Edition, term, domains you want licensed, prices, taxes, invoices, receipts, licence IDs, renewal and refund history.

2.4 Payment references. The payment provider's transaction ID, the payment method type (for example, "card" or "telebirr"), the amount, currency, status and date. For bank transfers, the reference and the confirmation recorded by our finance team. We do not receive or store card numbers, security codes or wallet PINs. Those are handled by the payment providers.

2.5 Licence check-in data. Each installation of Sham MediaOS contacts licensing.sham.et once a day and sends only:

(a) the licence ID;

(b) a random installation ID;

(c) the host names the installation answers on;

(d) the software version; and

(e) usage counts (number of staff, publication editions, languages and studios).

A check-in does not contain articles, media, reader data or the names or e-mail addresses of our customers' staff or readers. The check-in data is mostly about the customer's organisation. We treat it as personal data where it can be linked to an individual, for example a sole trader.

2.6 Server logs. Our servers record technical data for each request: IP address, date and time, requested address, response code, and browser or client type. The licence server also records the IP address that a check-in comes from.

2.7 Cookies. Our websites use only cookies that are strictly necessary:

(a) a session cookie that keeps you signed in or keeps your order in progress; and

(b) a security (CSRF) cookie that protects forms against forgery.

We do not use advertising, tracking or third-party analytics cookies. Because these cookies are strictly necessary, we do not ask for consent to them. Payment providers may set their own cookies on their pages.

2.8 We do not knowingly collect data about children. Our services are intended for businesses.

## 3. Why we use it, and on what legal basis

3.1 To take and fulfil orders, issue and deliver Licence Keys, process renewals, upgrades and refunds, and provide support. Legal basis: performance of a contract with you, or steps you asked for before a contract.

3.2 To verify licences, bind each licence to one installation, detect use on unlisted domains or several installations, and send signed replies to check-ins. Legal basis: performance of the licence agreement, and our legitimate interest in protecting our software against unlicensed use.

3.3 To issue invoices, keep accounting and tax records and meet our legal obligations. Legal basis: compliance with legal obligations.

3.4 To keep our websites and licence server secure, prevent fraud and abuse, and investigate incidents. Legal basis: our legitimate interest in running secure services.

3.5 To send service messages, such as delivery of keys, renewal reminders, security notices and important changes. Legal basis: performance of a contract and our legitimate interest in informing customers about their licences.

3.6 To send news about our products, only if you have agreed to receive it. Legal basis: consent. You can withdraw consent at any time with the link in each message or by e-mailing us.

3.7 To use aggregated usage counts (for example, the number of installations on each version) to plan development. Legal basis: our legitimate interest. We use these figures in a form that does not identify anyone.

3.8 To establish, exercise or defend legal claims. Legal basis: our legitimate interest and legal obligation.

## 4. How long we keep it

4.1 Orders, invoices, receipts and payment references: for 10 years after the end of the financial year in which the transaction took place, or longer if the law requires.

4.2 Licence records (licence ID, customer, edition, domains, binding to an installation): for as long as the licence exists and then for 5 years, so that we can handle renewals, disputes and support.

4.3 Check-in data: the latest check-in for each installation is kept with the licence record. We do not keep a history of individual check-ins; only the latest one is stored.

4.4 Server logs: 90 days, unless needed longer to investigate a specific security incident.

4.5 Support and sales correspondence: for 3 years after the last contact, unless it forms part of an order record.

4.6 Marketing consent records: until you withdraw consent, plus 2 years as proof.

4.7 When the retention period ends, we delete the data or make it anonymous.

## 5. Who we share it with

5.1 We do not sell personal data. We share it only with the following service providers, for the purposes above:

(a) Stripe, for card payments in USD;

(b) PayPal, for PayPal payments in USD;

(c) Chapa, for payments in ETB;

(d) Ethio telecom, for telebirr payments in ETB;

(e) ArifPay, for payments in ETB;

(f) our bank, [BANK NAME], for bank transfers and refunds;

(g) our e-mail provider, [E-MAIL HOST], for sending keys, receipts and messages;

(h) our hosting provider, [HOSTING PROVIDER], which hosts our websites and licence server; and

(i) our accountants, auditors and legal advisers, when needed.

5.2 Payment providers process payment data under their own terms and privacy policies and may act as separate controllers for their own legal and fraud-prevention purposes.

5.3 We may disclose data to tax authorities, courts, regulators or law enforcement when the law requires it. We will tell you about such a request where the law allows.

5.4 If our business, or part of it, is sold or merged, customer data may pass to the new owner, who must respect this policy.

## 6. Transfers outside Ethiopia

6.1 Our websites and licence server are hosted in [COUNTRY OF HOSTING].

6.2 Some providers, including Stripe, PayPal and our e-mail provider, process data outside Ethiopia, for example in the European Union or the United States.

6.3 When personal data is transferred outside Ethiopia, we do so only as the laws of the Federal Democratic Republic of Ethiopia allow. We use providers that offer appropriate safeguards, such as contractual data protection commitments, and transfer only the data needed for the purpose.

6.4 You can ask us for more information about the safeguards used.

## 7. Security

7.1 We protect personal data with appropriate measures, including encrypted connections (HTTPS), access controls for our staff, multi-factor authentication for administrative access, and audit logs.

7.2 Licence Keys are signed with a private key that is kept only on Sham's own systems.

7.3 If a personal data breach is likely to put your rights at risk, we will notify you and the competent authority as the law requires.

## 8. Your rights

8.1 Subject to the conditions in the law, you have the right to:

(a) be informed about how we use your data;

(b) access your personal data and receive a copy;

(c) have inaccurate data corrected;

(d) have data erased when we no longer need it or have no legal basis to keep it;

(e) restrict or object to processing based on our legitimate interests;

(f) receive data you gave us in a structured, machine-readable form;

(g) withdraw consent at any time, without affecting earlier processing; and

(h) not be subject to decisions based only on automated processing that have legal or similarly significant effects. We do not make such decisions. The licence server applies the licence's rules automatically (for example, read-only mode after expiry), and our support team will review any such outcome on request.

8.2 Some data cannot be erased while we must keep it by law, for example invoices.

8.3 To use your rights, e-mail [PRIVACY E-MAIL]. We may ask you to confirm your identity. We will answer within 30 days, or within the shorter period the law sets.

8.4 You may complain to the competent data protection authority in Ethiopia. We would appreciate the chance to resolve your concern first.

## 9. Changes

We may update this policy. We will post the new version on sham.et with a new "Last updated" date, and we will tell customers by e-mail about important changes.

## 10. Contact

Sham Software Systems Development General Trading PLC, [REGISTERED ADDRESS], Addis Ababa, Ethiopia. E-mail: [PRIVACY E-MAIL] or sales@sham.et.
