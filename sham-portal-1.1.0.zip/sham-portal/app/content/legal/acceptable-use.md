title: Acceptable Use Policy
---
Last updated: 7 November 2026

Sham Software Systems Development General Trading PLC

This policy applies to everyone who uses Sham MediaOS, our websites sham.et and store.sham.et, and our licence server licensing.sham.et. It forms part of the Sham MediaOS Software Licence Agreement.

## 1. Use of the software

1.1 Customers choose and are responsible for what they publish with Sham MediaOS. Sham does not monitor or edit customers' content.

1.2 You must not use the software:

(a) for any purpose that is unlawful in the country where you operate or publish;

(b) to publish content that a court or competent authority has lawfully ordered removed, or that incites violence, or that sexually exploits children;

(c) to distribute malware, run phishing pages, or send unsolicited bulk messages without the recipients' consent;

(d) to collect or use personal data without a legal basis; or

(e) to infringe others' copyright, trademarks or other rights.

1.3 You are responsible for complying with the media, broadcasting, advertising, elections, consumer and data protection laws that apply to you.

## 2. Licence protection

2.1 You must not remove, bypass or interfere with licence checks or check-ins, forge or share Licence Keys, or run a key on more installations or domains than licensed.

2.2 You must not reinstall the software or reset its data to obtain repeated trials.

## 3. Our websites and licence server

3.1 You must not:

(a) attack, overload, probe or scan our websites or licence server, except under a security test that we have agreed in writing;

(b) send automated or excessive requests, other than the normal daily check-in;

(c) place orders with false details or payment methods you are not authorised to use; or

(d) try to access accounts, orders or licences that are not yours.

3.2 If you find a security vulnerability, please report it to [SECURITY E-MAIL, e.g. security@sham.et]. We will not take action against good-faith reports that follow this policy.

## 4. What happens if this policy is broken

4.1 We may refuse orders, withhold updates and support, or suspend or revoke a licence, as set out in the Licence Agreement.

4.2 We may report unlawful activity to the competent authorities.

4.3 Where possible, we will contact you first and give you a chance to fix the problem.

## 5. Contact

Report misuse to sales@sham.et.
