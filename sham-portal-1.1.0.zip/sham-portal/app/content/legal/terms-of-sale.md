title: Sham MediaOS Store Terms of Sale
---
Last updated: 7 November 2026

Sham Software Systems Development General Trading PLC

These Terms of Sale apply to every purchase of Sham MediaOS licences, renewals, upgrades and update extensions from the store at store.sham.et, and to purchases made on a quotation from Sham. The seller is Sham Software Systems Development General Trading PLC, commercial registration number [COMMERCIAL REGISTRATION NO.], TIN [TIN], VAT registration number [VAT NO.], [REGISTERED ADDRESS], Addis Ababa, Ethiopia ("Sham", "we", "us"). The buyer is the person or organisation named in the order ("you").

Use of the software is governed by the Sham MediaOS Software Licence Agreement (the "Licence Agreement"). Words defined there have the same meaning here.

## 1. Who may buy

1.1 The store is intended for businesses and organisations, mainly media outlets. If you buy for an organisation, you confirm that you have authority to do so.

1.2 You must give accurate details in your order: your name or organisation's name, a contact e-mail address, your billing country, your tax identification number where you have one, and the domains you want licensed.

1.3 We may decline an order, for example if the details are incomplete, the payment cannot be verified, or the sale would breach sanctions or export laws.

## 2. How a contract is made

2.1 The store shows the Product Editions, terms, features and prices available. This is an invitation to order, not a binding offer.

2.2 You place an order by choosing a Product Edition and term, entering your details and domains, accepting these Terms and the Licence Agreement, and confirming payment.

2.3 The contract is made when we confirm that your payment has been received and verified, and issue your Licence Key. Until then, we may cancel the order and refund any amount received.

2.4 Orders, acceptances, invoices and receipts may be made and kept in electronic form. Our electronic records of your order are evidence of the transaction.

## 3. Prices

3.1 Prices are shown in the store for each Product Edition. Yearly licences are priced per year. A perpetual licence costs three times the yearly price of the same Product Edition and includes one year of updates.

3.2 Update extensions for a perpetual licence cost 20% of the perpetual licence price then shown in the store, per year.

3.3 An upgrade to a higher Product Edition is charged at the difference in price shown in the store at the time of the upgrade.

3.4 The price that applies to your order is the price shown when you confirm the order. We may change prices at any time for future orders and renewals.

3.5 The Global Product Edition, and any custom scope, are sold on quotation under clause 9.

3.6 If a price is shown in obvious error, we may cancel the order and refund any amount paid, or offer you the correct price.

## 4. Currencies

4.1 Prices are set in US dollars (USD).

4.2 Where we offer prices in Ethiopian birr (ETB), the store converts the USD price at the exchange rate we set and shows the ETB amount before you pay. The amount shown at checkout is the amount you pay. Later changes in exchange rates do not change a confirmed order.

4.3 You pay in the currency of the payment method you choose. Your bank or payment provider may charge conversion or transfer fees. Those fees are yours.

## 5. VAT and other taxes

5.1 If your billing country is Ethiopia, Ethiopian value added tax (VAT) at the applicable rate, currently 15%, is added to the price. The store shows the VAT amount before you pay.

5.2 For buyers outside Ethiopia, the store does not add Ethiopian VAT. You are responsible for any VAT, goods and services tax, import duty or similar tax that applies in your country, including any reverse-charge obligation.

5.3 If the law requires you to withhold tax from a payment to us, you must give us the official withholding receipt promptly. For buyers outside Ethiopia, you must pay the amount needed so that we receive the full price, unless we agree otherwise in writing.

5.4 You must give us a correct billing country and tax identification number. If incorrect details cause us to charge the wrong tax, you must pay any tax, interest or penalty that results.

## 6. Payment methods

6.1 You may pay:

(a) in USD, by card through Stripe or through PayPal; or

(b) in ETB, through Chapa, telebirr or ArifPay, or by bank transfer to Sham's account, when ETB pricing is offered.

6.2 Card and wallet payments are made on the payment provider's own page. Sham does not receive or store your card number or wallet credentials. The provider's own terms and privacy policy apply to the payment.

6.3 For bank transfers, the store shows our bank details and a payment reference. Include the reference with your transfer. We issue your Licence Key when our finance team confirms that the full amount has arrived. Please allow two business days.

6.4 Payment must be made in full before we issue a Licence Key, unless a signed quotation sets other payment terms.

6.5 If a payment is reversed, charged back or found to be fraudulent, we may revoke the Licence Key. The newsroom then becomes read-only at the next check-in, as described in the Licence Agreement. Please contact us before starting a chargeback, so that we can try to resolve the issue.

## 7. Delivery of Licence Keys

7.1 The software and Licence Keys are delivered electronically. Nothing is shipped.

7.2 When your payment is verified, we issue your Licence Key once, e-mail it to the address in your order and show it on your order page in the store.

7.3 You install the key in your Installation under Administration, Licence, or in the installer. The software can be downloaded from [DOWNLOAD LOCATION].

7.4 Keep your Licence Key safe. Anyone who has it could try to claim it for their own server. If you lose the key, contact us and we will resend it to the e-mail address in your order.

7.5 If you have not received your key within [24 hours] after a card or wallet payment, check your spam folder and then contact sales@sham.et.

7.6 Delivery is complete when the Licence Key is e-mailed to you or shown on your order page, whichever is first.

## 8. Renewals

8.1 A yearly licence ends at the end of its term. Renewals are not charged automatically. We send reminder e-mails before the end date. You can renew in the store from your order page.

8.2 If you renew before the end date, or within the 14-day grace period after it, the new term runs on from the old end date. Your Installation picks up the renewal at its next check-in. You do not need a new key.

8.3 If you do not renew by the end of the grace period, the newsroom becomes read-only. Your public website, apps and feeds keep running, and no content is deleted. You can renew at any time to restore full use.

8.4 For a perpetual licence, you may buy one-year update extensions under clause 3.2. If you let the update period lapse and buy an extension later, the new update year runs from the date of purchase.

8.5 Renewals are charged at the price shown in the store when you renew.

## 9. Quotation editions

9.1 The Global Product Edition, and any order with custom limits, services or payment terms, are sold on quotation. Contact sales@sham.et.

9.2 A quotation states the scope, price, currency, taxes, payment terms and any services. It is valid for 30 days unless it says otherwise.

9.3 The contract is made when both parties sign the quotation or order form, or when you accept it in writing and we confirm. The signed quotation prevails over these Terms where they conflict.

## 10. Refunds

10.1 First purchase, key not used. You may cancel your first purchase of a Sham MediaOS licence and receive a full refund if you ask within 14 days after delivery of the Licence Key, and the key has not yet been bound to an Installation (that is, no Installation has checked in with it).

10.2 Installation failure. If the key has already been bound to an Installation, you may still receive a full refund if you ask within 14 days after delivery, the software cannot be installed or run on a supported server configuration, and our support team could not resolve the problem after you gave it reasonable information and access.

10.3 When we accept a refund, we revoke the Licence Key. You must stop using the software and remove it from your servers, except for the trial if it is still running.

10.4 Except under clauses 10.1 and 10.2, under the warranty in the Licence Agreement, or where the law requires otherwise, payments are not refundable. In particular, renewals, update extensions, upgrades, quotation editions and services already performed are not refundable unless the quotation says so.

10.5 We refund to the original payment method and in the currency paid, normally within 14 days after accepting the refund. Bank transfers are refunded to the account that made the payment. We do not refund bank charges or currency conversion costs charged by your bank or provider.

10.6 To ask for a refund, e-mail sales@sham.et with your order number and the reason.

10.7 The 14-day trial lets you evaluate the software before buying. We encourage you to use it.

## 11. Invoices and receipts

11.1 We issue an electronic receipt for every payment and show it on your order page.

11.2 Buyers in Ethiopia receive a VAT invoice that shows Sham's TIN and VAT registration number, your TIN if given, the price, the VAT amount and the total. If you need your organisation's name or TIN on the invoice, enter them before paying.

11.3 Buyers outside Ethiopia receive a commercial invoice in the currency paid.

11.4 If an invoice contains an error, tell us within 30 days and we will issue a corrected invoice or credit note, as the law allows.

## 12. Domains and transfers

12.1 Each Product Edition allows a set number of Licensed Domains, shown in the store. Domain changes are made through support.

12.2 Moving your Installation to a new server is free. Ask support to release the licence.

12.3 A licence cannot be transferred to another organisation without our written consent.

## 13. Liability

The warranty, limitation of liability and other terms of the Licence Agreement apply to every purchase under these Terms. Nothing in these Terms limits any right that the law gives you and that cannot be excluded by contract.

## 14. Governing law and disputes

These Terms are governed by the laws of the Federal Democratic Republic of Ethiopia. Disputes are handled as set out in the Licence Agreement: negotiation first, then the competent courts in Addis Ababa, unless the parties agree otherwise in writing.

## 15. Changes and contact

15.1 We may change these Terms for future orders. The version shown when you place an order applies to that order.

15.2 Contact: Sham Software Systems Development General Trading PLC, [REGISTERED ADDRESS], Addis Ababa, Ethiopia. E-mail: sales@sham.et. Phone: [PHONE]. Store: store.sham.et.
