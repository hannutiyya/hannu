title: Sham MediaOS Software Licence Agreement
---
Last updated: 7 November 2026

Sham Software Systems Development General Trading PLC

This Software Licence Agreement (the "Agreement") is between Sham Software Systems Development General Trading PLC, a private limited company registered in Ethiopia under commercial registration number [COMMERCIAL REGISTRATION NO.] and TIN [TIN], with its address at [REGISTERED ADDRESS], Addis Ababa, Ethiopia ("Sham", "we", "us"), and the person or organisation that buys, installs or uses Sham MediaOS (the "Customer", "you").

You accept this Agreement when you tick the acceptance box in the store, sign an order form that refers to it, or install or use the Software, whichever comes first. If you accept for an organisation, you confirm that you have authority to bind it. If you do not accept this Agreement, do not install or use the Software.

## 1. Definitions

1.1 "Software" means Sham MediaOS: the server application, newsroom, website, installer, mobile app templates, documentation, and any update we supply under this Agreement.

1.2 "Product Edition" means the commercial tier you buy: Starter, Professional, Broadcast, Enterprise or Global.

1.3 "Publication Edition" means an edition of your publication inside the Software (for example, a country or language edition). Each Product Edition allows a number of Publication Editions.

1.4 "Licence Key" means the digitally signed key we issue to you. It records your name, Product Edition, domains, limits, features, issue date, expiry date (if any), end of updates and whether it is an offline licence.

1.5 "Installation" means one running deployment of the Software with its own database, identified by the random installation ID that the Software creates.

1.6 "Licensed Domains" means the domain names listed in your Licence Key.

1.7 "Term" means the period for which you bought the licence: one year for a yearly licence, or without end date for a perpetual licence.

1.8 "Update Period" means the period during which you are entitled to updates and support.

1.9 "Order" means your purchase in the store at store.sham.et, or an order form or quotation that you and Sham have accepted.

1.10 "Your Content" means everything you or your staff, contributors or readers put into or create with the Software, including articles, media, reader accounts and personal data.

## 2. Licence grant

2.1 Subject to this Agreement and to payment of the fees, Sham grants you a non-exclusive, non-transferable, non-sublicensable licence to install and use the Software in object form and in any source form we supply:

(a) on one Installation at a time;

(b) on the Licensed Domains only;

(c) within the features and limits of your Product Edition; and

(d) for the Term.

2.2 You may use the Software to run your own media operations, including publishing to the public through your websites, apps, feeds and newsletters.

2.3 Your staff and contractors may use the Software on your behalf. You are responsible for their compliance with this Agreement.

2.4 You may make a reasonable number of backup copies of the Software and of your database. A backup copy may not be run as a second live Installation.

2.5 You may change the configuration, themes and templates of the Software and build your own extensions and integrations using the documented interfaces. You may modify other parts of the source code that we supply in readable form for your own use, but not the licensing components described in clause 7. We do not support or warrant modified code.

2.6 Sham keeps all rights not expressly granted. The Software is licensed, not sold.

2.7 The Software includes open-source components. Each one is licensed under its own licence, listed in the notices file supplied with the Software. Nothing in this Agreement limits your rights under those licences.

## 3. Product Editions and limits

3.1 Each Product Edition includes the features and limits shown in the store at the time of your Order and recorded in your Licence Key. The limits cover staff seats, Publication Editions, interface and content languages, studios and Licensed Domains. Schedule 1 shows the values at the date of this Agreement.

3.2 The Licence Key is the authoritative record of your features and limits. If the store and the Licence Key differ, tell us within 30 days of delivery and we will correct the key.

3.3 The Software enforces limits when a staff role is granted, a Publication Edition or studio is created, or a feature is used. Reaching a limit does not affect existing content or the public website.

3.4 You may upgrade to a higher Product Edition at any time by paying the difference in price shown in the store. We then issue a new Licence Key. You do not need to reinstall the Software.

3.5 If you move to a lower Product Edition, features outside that edition stop working in the newsroom. Your Content is not deleted. Releasing a legal hold remains possible on every Product Edition.

3.6 The Global Product Edition, and any custom terms, are sold on quotation. The signed quotation or order form sets its scope.

## 4. Domains and installation binding

4.1 Your Licence Key is bound to the Licensed Domains. If the Software answers on a domain that is not listed, the newsroom becomes read-only.

4.2 The number of Licensed Domains depends on your Product Edition. To add or change a domain, contact sales@sham.et. Extra domains may be charged.

4.3 Each Licence Key is bound to the first Installation that checks in with it. The same key may not be used on a second Installation at the same time.

4.4 To move the Software to a new server, ask our support team to release the licence. The new Installation claims it at its next check-in.

4.5 A test, staging or development Installation needs its own licence or our written permission, unless it runs in trial mode under clause 6.

## 5. Licence checks and check-ins

5.1 The Software contacts our licence server at licensing.sham.et once a day. A check-in sends only:

(a) the licence ID;

(b) the random installation ID;

(c) the host names the Installation answers on;

(d) the Software version; and

(e) usage counts (staff, Publication Editions, languages and studios).

5.2 A check-in does not send Your Content, reader data or personal data about your staff or readers. Our Privacy Policy describes how we handle check-in data.

5.3 If the Software cannot complete a check-in, the newsroom keeps working, with a warning banner, for up to 30 days. After 30 days without a successful check-in, the newsroom becomes read-only until a check-in succeeds.

5.4 If your site cannot connect to the internet for long periods (for example, an air-gapped site), you may ask for an offline licence. An offline licence needs no check-ins and is issued at our discretion.

5.5 You must not block, fake or interfere with check-ins, except by using an offline licence that we have issued.

## 6. Trial

6.1 A new Installation without a Licence Key runs as a trial of the Professional Product Edition for 14 days from installation.

6.2 The trial is for evaluation only. It is provided "as is", without any warranty, support commitment or liability on our part, to the extent the law allows.

6.3 When the trial ends, the newsroom becomes read-only until you install a Licence Key. The public website keeps running.

6.4 You may not reinstall the Software, reset the database or take any other step to start a new trial on the same site. One trial is allowed per organisation, unless we agree otherwise in writing.

## 7. Restrictions

7.1 You must not, and must not allow anyone else to:

(a) remove, disable, bypass, modify or work around the licence checks, the check-in, the Licence Key signature or any other technical protection in the Software;

(b) create, edit, forge or share Licence Keys, or use a key that we did not issue to you;

(c) decode, decompile or reverse-engineer any part of the Software that we supply in encoded or compiled form, except to the extent the law expressly allows despite this restriction;

(d) run one Licence Key on more than one Installation at a time, or on domains that are not listed in it;

(e) sell, rent, lease, lend, sublicense, distribute or transfer the Software or a Licence Key to anyone, except under a written partner or reseller agreement with Sham;

(f) provide the Software to third parties as a hosted service (for example, by running newsrooms for other publishers on your licence), unless your Order or a written agreement allows it;

(g) remove or change copyright notices, licence files or open-source notices in the source code or documentation;

(h) use the Software to build a competing product, or publish benchmarks of the licensing mechanism; or

(i) use the Software in breach of our Acceptable Use Policy or of applicable law.

7.2 Circumventing the licence checks, forging a key, or running a key on more installations than licensed is a material breach. It entitles Sham to terminate under clause 14.3 and to claim damages, in addition to any other remedy the law allows.

7.3 Each copy of the Software may carry an invisible identifier linked to your licence ID. You must not remove it.

## 8. White-label rights

8.1 You may present the Software to your staff, readers and the public under your own brand. You may set your own name, short name, tagline, legal name, contact details, colours and logos, and you may remove the names "Sham", "Sham MediaOS", "Jirra Media Network" and "JMN" from user-facing screens, e-mails, feeds, metadata and apps.

8.2 You are not required to show "Powered by Sham MediaOS" or any similar credit.

8.3 White-labelling changes how the Software looks. It does not transfer ownership of the Software. You must not claim to own the Software, register it as your own work, or resell it as your own product.

8.4 Technical identifiers in the code (for example, header names and settings keys) may keep their original names.

8.5 You are responsible for having the rights to the names, logos and other brand material you add.

## 9. Customer-built apps and extensions

9.1 You may use the Software to build and publish your own branded mobile and web apps, themes, extensions and integrations ("Customer Apps").

9.2 You own the code you write yourself. Sham owns the Software and any Sham code included in a Customer App, such as app templates and client libraries.

9.3 You may distribute Customer Apps to the public, including through app stores, under your own name, as long as they connect to your licensed Installation. The Sham code inside them is licensed to you on the same terms as the Software and only for use with that Installation.

9.4 You are the publisher of your Customer Apps. You are responsible for app store accounts, app store rules, privacy notices for your readers and the content of your apps.

9.5 Customer Apps keep working for readers when your licence lapses, as described in clause 14.6.

## 10. Updates

10.1 During the Update Period, you may download and install updates, new versions and security fixes that we make generally available for your Product Edition.

10.2 For a yearly licence, the Update Period is the Term.

10.3 For a perpetual licence, the Update Period is one year from the issue date. You may extend it one year at a time by paying 20% of the perpetual licence price then shown in the store for each year. After the Update Period ends, you may keep using the last version released before it ended, without time limit, but you will not receive further updates or support.

10.4 We decide the content and timing of updates. We may change, add or remove features in new versions, but we will not remove a major feature of your Product Edition from the version you already have.

10.5 Some services depend on a valid licence and an active Update Period, including updates, security fixes, the app build service and support.

10.6 We recommend installing security fixes promptly. We are not responsible for problems that a released fix would have prevented.

## 11. Support

11.1 During the Update Period, we provide support for the unmodified Software on supported server configurations through the channels and with the response targets described in the store for your Product Edition: [SUPPORT CHANNELS AND RESPONSE TIMES].

11.2 Support covers installation questions, help with features and correction of reproducible defects. It does not cover your own server, network, hosting provider, third-party services, modified code or Customer Apps.

11.3 If you give us access to your Installation for support, you decide what access to give. We use it only to provide the support you asked for, as described in our Data Processing Note.

11.4 Training, custom development, migration and on-site work are available under a separate quotation.

## 12. Your Content and your responsibilities

12.1 Your Content belongs to you. The Software stores it on your own servers. Sham does not receive it through the Software and has no rights to it.

12.2 You are the controller of the personal data in your Installation and are responsible for complying with the data protection, media, advertising, consumer and other laws that apply to you. See our Data Processing Note.

12.3 You are responsible for your servers, hosting, security configuration, backups, encryption keys and passwords. If you lose your application key, encrypted data cannot be recovered by us.

12.4 You are responsible for third-party services you connect to the Software (for example, payment providers, e-mail services, AI services, analytics or streaming services) and for their terms and fees.

12.5 You are solely responsible for what you publish.

## 13. Warranty and disclaimers

13.1 For 30 days from delivery of your first Licence Key for a paid licence, we warrant that the unmodified Software, installed on a supported configuration, will perform materially as described in its documentation. If it does not, and you tell us within that period, we will, at our choice, fix the defect, provide a workaround, or end the licence and refund the fees paid for it. This is your only remedy under this warranty.

13.2 Except as stated in clause 13.1, and to the extent the law allows, the Software is provided "as is" and "as available". Sham gives no other warranties, express or implied, including warranties of fitness for a particular purpose, merchantability or uninterrupted or error-free operation.

13.3 We do not warrant that the Software will meet every legal requirement that applies to your publication, or that third-party services will remain available.

13.4 No software that runs on a server you control can be made impossible to tamper with. The licence protections exist to protect Sham. They are not a security feature for you.

## 14. Term, termination and read-only behaviour

14.1 This Agreement starts when you accept it and continues for the Term, unless ended earlier under this clause.

14.2 You may stop using the Software at any time. Fees already paid are refundable only as set out in the Store Terms of Sale.

14.3 Sham may terminate your licence by written notice:

(a) at once, if you breach clause 7.1(a), (b) or (d), or if a payment for the licence is reversed, charged back or not received;

(b) if you commit any other material breach and do not remedy it within 30 days after our notice; or

(c) if we are required to do so by law, a court order or applicable sanctions.

14.4 When a licence expires, a 14-day grace period applies. During it, the newsroom keeps working with a banner, so that you can renew.

14.5 The newsroom becomes read-only when the licence has expired and the grace period has passed, when the trial has ended, when a check-in is overdue under clause 5.3, when the Software runs on an unlisted domain, when the key is missing, or when we revoke the key.

14.6 In read-only mode:

(a) your public website, apps and feeds keep running for your readers;

(b) staff can view, but not create or change, content in the newsroom;

(c) the licence administration pages stay open, so you can install a new Licence Key at any time; and

(d) no content is deleted by the Software or by Sham.

14.7 After a licence lapses for any reason other than termination under clause 14.3(a), you keep a limited, non-exclusive right to run the Software in read-only mode under clause 14.6, so that your readers keep access and you can export your data. If we terminate under clause 14.3(a), this right also ends and you must stop using the Software, but you may export Your Content within 30 days.

14.8 Clauses 7, 8.3, 12, 13, 15, 16, 18 and 19, and any accrued rights, survive the end of this Agreement.

## 15. Limitation of liability

15.1 Nothing in this Agreement limits liability that cannot be limited by law, including liability for fraud, wilful misconduct or gross negligence, or for death or personal injury caused by negligence.

15.2 Subject to clause 15.1, Sham is not liable for loss of profits, revenue, business, advertising income, readers, goodwill or data, or for any indirect, special or consequential loss, even if Sham was told it might occur.

15.3 Subject to clause 15.1, Sham's total liability under or in connection with this Agreement, in any year, is limited to the fees you paid for the licence concerned in the 12 months before the event that gave rise to the claim. For a trial, Sham's liability is limited to zero to the extent the law allows.

15.4 Sham is not liable for failure or delay caused by events beyond its reasonable control, including internet shutdowns, power outages, war, civil unrest, natural disasters, government action or failures of payment providers or hosting providers.

15.5 You will compensate Sham for losses caused by your breach of clause 7, by Your Content, or by your use of the Software in breach of law.

## 16. Intellectual property

16.1 Sham and its licensors own all copyright and other rights in the Software, its documentation and the Sham, Sham MediaOS and related names and logos.

16.2 If you send us suggestions or feedback, we may use them freely.

16.3 If a third party claims that the unmodified Software infringes its rights, we will, at our choice and cost, obtain a right for you to keep using it, modify it to avoid infringement, or end the licence and refund the unused part of the fees. This does not apply to claims caused by your modifications, Your Content or Customer Apps.

## 17. Export control and sanctions

17.1 The Software contains cryptography. You must comply with all export control, import and sanctions laws that apply to you and to the Software.

17.2 You confirm that you are not a person or organisation targeted by sanctions that apply to Sham or to our payment providers, and that you will not use the Software in, or provide it to anyone in, a country or territory where this is prohibited.

17.3 We may refuse an Order, decline to deliver updates or terminate a licence where this is needed to comply with sanctions or export laws, including rules imposed by our payment providers.

## 18. Governing law and disputes

18.1 This Agreement is governed by the laws of the Federal Democratic Republic of Ethiopia.

18.2 The parties will first try to settle any dispute by good-faith negotiation between senior representatives. Either party may start this by written notice.

18.3 If the dispute is not settled within 30 days after that notice, it will be decided by the competent courts in Addis Ababa, Ethiopia, which have exclusive jurisdiction, unless the parties agree in writing on arbitration or on another forum.

18.4 Either party may ask any competent court for urgent interim relief, for example to stop circumvention of the licence checks or misuse of confidential information.

18.5 The United Nations Convention on Contracts for the International Sale of Goods does not apply.

## 19. General

19.1 Order of precedence. If documents conflict, the following order applies: a signed order form or agreement with Sham; this Agreement; the Store Terms of Sale; information shown on the store.

19.2 Entire agreement. This Agreement and the documents named in clause 19.1 form the whole agreement about the Software and replace earlier statements about it.

19.3 Changes. We may update this Agreement for future Orders and renewals. The version accepted with an Order applies to that Order until its next renewal.

19.4 Assignment. You may not transfer this Agreement without our written consent, which we will not refuse unreasonably for a transfer to the buyer of your publication. We may transfer it to a successor of our business.

19.5 Electronic form. This Agreement may be accepted, signed and kept electronically. Notices to you may be sent to the e-mail address in your Order. Notices to us must be sent to sales@sham.et.

19.6 Severability. If a court finds any part of this Agreement invalid, the rest remains in force.

19.7 No waiver. A delay in enforcing a right is not a waiver of it.

19.8 Language. This Agreement is written in English. If it is translated, the English version prevails, to the extent the law allows.

19.9 Independent parties. Nothing in this Agreement creates a partnership, agency or employment relationship.

## Schedule 1: Product Edition limits at the date of this Agreement

The store and your Licence Key are authoritative. "Unlimited" means no limit is enforced by the Software.

Starter: 1 Publication Edition, 3 languages, 5 staff seats, no studios, up to 2 Licensed Domains. Features: newsroom and CMS, website and PWA, newsletters, local payments, advertising.

Professional: 3 Publication Editions, 10 languages, 25 staff seats, no studios, up to 3 Licensed Domains. Adds: memberships and paywall, branded mobile apps, AI desk, analytics, podcasts, elections and polls.

Broadcast: 5 Publication Editions, 15 languages, 75 staff seats, 3 studios, up to 5 Licensed Domains. Adds: broadcast (rundowns, studios, schedule, graphics), live streaming and relays, Interaction Centre, syndication and Content Credentials.

Enterprise: unlimited Publication Editions and languages, 500 staff seats, 20 studios, up to 20 Licensed Domains. Adds: staff single sign-on, several brands, archive tiers and legal holds, audit export.

Global: unlimited, as set out in the quotation. Adds: deployment across several data centres, sold on quotation.

Contact: Sham Software Systems Development General Trading PLC, [REGISTERED ADDRESS], Addis Ababa, Ethiopia. E-mail: sales@sham.et. Website: sham.et.
