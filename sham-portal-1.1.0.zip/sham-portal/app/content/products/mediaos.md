title: Sham MediaOS
tagline: The newsroom, website, apps and broadcast desk for media of every size
summary: Sham MediaOS runs a whole news organisation on your own server: newsroom and CMS, a fast multilingual website, newsletters, reader payments, branded apps and, for broadcasters, rundowns, studios and live streaming. Under your own name.
accent: #C8102E
host: media.sham.et
---
## One platform for the whole newsroom

Reporters file, editors review, the desk publishes and the website, newsletters, apps and feeds update together. Sham MediaOS replaces the patchwork of a CMS, a newsletter tool, a paywall plugin and a separate broadcast system with one installation that you own.

- **Newsroom and CMS** with desks, roles, review steps, scheduling and a full revision history.
- **Fast multilingual website** that works on slow connections and installs as an app (PWA).
- **33 interface languages**, including Amharic, Afaan Oromo, Tigrinya, Somali, Kiswahili and Arabic, with Ethiopian calendar dates.
- **Newsletters** written and sent from the newsroom.
- **Branded mobile apps** for Android and iOS, built under your own name and store accounts.
- **AI desk** for translation drafts, summaries, transcripts and captions, always reviewed by a person.
- **Analytics**, podcasts, elections results and polls.

## Your brand from the first screen

Name, short name, tagline, colour and logo go in at installation and can be changed later. The website, e-mails, newsletters, the newsroom itself and your apps all follow. Readers and staff never see our name.

## Readers pay the way they already pay

Visa and Mastercard through Stripe, PayPal, Chapa, telebirr, ArifPay and bank transfer, each paying into your own merchant account. Memberships, a paywall, one-off support, advertising and sponsored newsletters.

## Built for broadcasters

The Broadcast edition adds rundowns, up to three studios, the programme schedule, on-air graphics, live streaming and relays, an interaction centre for calls and messages, and syndication with Content Credentials.

## Installed on your server

One command on Ubuntu 24.04, or Docker, Kubernetes, or a browser installer for shared hosting. Backups, health checks and a go-live checklist are built in. Your content and your readers' data stay where you put them.

## Secure by default

Two-step sign-in, passkeys and single sign-on (Google Workspace, Microsoft Entra ID and SAML 2.0 on Enterprise). Roles per desk, a tamper-evident audit log with signed exports, and signed licences.

## Readers never lose access

If a licence lapses, the newsroom becomes read-only while the website, apps and feeds keep running. The daily licence check sends counts only, never your content.

## Try it free for 14 days

Every new installation starts on the Professional edition for 14 days, no key needed. Buy a licence in the store when you are ready and paste the key in Administration → Licence; nothing is reinstalled.
