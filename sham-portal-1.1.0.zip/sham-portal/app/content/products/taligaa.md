title: Taligaa
tagline: Digital health products from Sham
summary: Taligaa is Sham's family of digital health products for clinics, hospitals and health programmes in Ethiopia. Tell us what you need and our team will show you the products that fit.
accent: #0B7A61
host: taligaa.sham.et
---
## Health software made in Ethiopia

Taligaa brings together Sham's digital health products, built in Ethiopia for the way care is delivered here.

## Talk to our health team

Each Taligaa product is set up together with your team. Use the contact form and tell us about your facility or programme; we will reply with the products that fit, how they are deployed, and their regulatory status.
